-------------------------------------------------------------------------------
--  SoLAchievements: the progress journal and progress toasts.
--  Each check pass compares an achievement's progress with the last one
--  seen; a step up goes in the journal (per character, the last 50), steps
--  of one achievement within ten minutes merged into one line (300 -> 317,
--  not seventeen lines). The history pass (quiet) only sets the baseline.
--  A toast for progress (Settings, Progress toasts): Off, Pinned (the
--  tracker's), Watch list (and pinned), or Milestones (25, 50, 75, 90 %).
-------------------------------------------------------------------------------
local _, ns = ...
local FA = ns.FA
local MERGE = 600
local MILESTONES = { 0.25, 0.5, 0.75, 0.9 }

local function CharacterEarned(key) return FA.DB().done[key] end

local function Journal()
    local d = FA.DB()
    d.journal = d.journal or {}
    d.lastProg = d.lastProg or {}
    return d.journal, d.lastProg
end

local function Toast(a, cur, need)
    local mode = FA.Settings().progressToasts or "off"
    if mode == "off" then return end
    local pinned = FA.DB().tracked[a.key]
    local watched = ns.IsWatched and ns.IsWatched(a.key)
    if mode == "pinned" and not pinned then return end
    if mode == "watch" and not (pinned or watched) then return end
    if mode == "milestones" then
        if not (pinned or watched) then return end
        local before = (cur - 1) / need
        local now = cur / need
        local crossed = false
        for _, m in ipairs(MILESTONES) do if before < m and now >= m then crossed = true end end
        if not crossed then return end
    end
    local K = FA.Kit
    if K and K.Toast then
        K.Toast(a.name:upper(), ns.ProgressText(a, cur, need), nil, a.icon or ns.ICONS[a.id] or 236376)
    end
end

-- From the check pass: a, its evaluation, quiet (the history pass).
function ns.NoteProgress(a, ev, quiet)
    if ev.required <= 1 then return end
    local journal, last = Journal()
    local before = last[a.key]
    last[a.key] = ev.current
    if quiet or not before or ev.current <= before then return end
    if ns.FireAPI then ns.FireAPI("ACHIEVEMENT_PROGRESS_CHANGED", a.key, ev.current, ev.required, before) end
    if a.money and a.series and ns.SeriesTiers(a.series, CharacterEarned) ~= a then return end
    local now = time()
    local top = journal[1]
    if top and top.key == a.key and now - top.t < MERGE then
        top.to, top.t = ev.current, now
    else
        table.insert(journal, 1, { key = a.key, from = before, to = ev.current, need = ev.required, t = now })
        while #journal > 50 do table.remove(journal) end
    end
    Toast(a, ev.current, ev.required)
end

-- The latest steps: { a, from, to, need, t }.
function ns.RecentProgress(n, achievement)
    local journal = Journal()
    local out, seen = {}, {}
    for _, e in ipairs(journal) do
        local a = FA.BY_KEY[e.key]
        if a and (not achievement or a == achievement) and not seen[e.key] and not FA.Earned(e.key)
            and not ns.IsExcluded(e.key) and (not (a.money and a.series) or ns.SeriesTiers(a.series) == a) then
            out[#out + 1] = { a = a, from = e.from, to = e.to, need = e.need, t = e.t }
            seen[e.key] = true
        end
        if #out >= (n or 5) then break end
    end
    return out
end
