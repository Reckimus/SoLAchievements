local _, ns = ...
local FA = ns.FA
local secret = FA.secret
if not (C_NamePlate and C_NamePlate.GetNamePlateForUnit and C_Timer and C_Timer.NewTicker) then return end

local visible = {}
local nextLookup
local namesOnlyCVar = "nameplateShowOnlyNameForFriendlyPlayerUnits"

local function Readable(value)
    return not secret(value) and (not canaccessvalue or canaccessvalue(value))
end

local function IsPlateToken(unit)
    return Readable(unit) and type(unit) == "string" and unit:match("^nameplate%d+$") ~= nil
end

function FA.ApplyFriendlyNameplateStyle()
    if not (C_CVar and C_CVar.GetCVar and C_CVar.SetCVar) then return end
    if InCombatLockdown and InCombatLockdown() then return end
    local settings = FA.Settings()
    local current = C_CVar.GetCVar(namesOnlyCVar)
    if not Readable(current) or current == nil then return end
    if settings.nameplateTitles ~= false and settings.friendlyTitleNamesOnly ~= false then
        if current ~= "1" then
            if pcall(C_CVar.SetCVar, namesOnlyCVar, "1") and C_CVar.GetCVar(namesOnlyCVar) == "1" then
                settings.previousFriendlyTitleStyle = current
            end
        end
    elseif settings.previousFriendlyTitleStyle ~= nil then
        if current ~= "1" or pcall(C_CVar.SetCVar, namesOnlyCVar, settings.previousFriendlyTitleStyle) then
            settings.previousFriendlyTitleStyle = nil
        end
    end
end

local function Restore(state)
    local label = state.label
    if label and (not label.IsForbidden or not label:IsForbidden()) then
        local text = label:GetText()
        if Readable(text) and text == state.rendered then label:SetText(state.original) end
    end
    state.label, state.original, state.rendered = nil, nil, nil
end

local function CanMeasure(region)
    return region and (not region.IsForbidden or not region:IsForbidden())
        and region.IsAnchoringRestricted and not region:IsAnchoringRestricted()
        and (not region.IsAnchoringSecret or not region:IsAnchoringSecret())
end

local function RestoreWidth(state)
    local label = state.wideLabel
    if not label then return end
    if not (CanMeasure(state.widePlate) and CanMeasure(state.wideParent) and CanMeasure(label)) then return end
    local numPoints = label:GetNumPoints()
    if not Readable(numPoints) then return end
    if numPoints == 1 then
        local point, parent, relativePoint, x, y = label:GetPoint()
        if not (Readable(point) and Readable(parent) and Readable(relativePoint) and Readable(x) and Readable(y)) then return end
        if point == "CENTER" and parent == state.wideParent and relativePoint == "CENTER"
            and x == state.wideX and y == state.wideY then
            label:ClearAllPoints()
            label:SetWidth(state.originalWidth)
            for _, anchor in ipairs(state.originalPoints) do label:SetPoint(unpack(anchor, 1, 5)) end
        end
    end
    state.wideLabel, state.widePlate, state.wideParent, state.originalPoints = nil, nil, nil, nil
end

local function FitName(state, plate, frame, label)
    RestoreWidth(state)
    -- Restricted nameplates can still allow text changes, but querying their
    -- positions can trigger a blocked action even when the label is not forbidden.
    if state.wideLabel or not (CanMeasure(plate) and CanMeasure(frame) and CanMeasure(label)) then return end
    if not (C_CVar and C_CVar.GetCVar and C_CVar.GetCVar(namesOnlyCVar) == "1" and label.IsTruncated) then return end
    local truncated = label:IsTruncated()
    if not Readable(truncated) or not truncated then return end
    local x, y = label:GetCenter()
    local frameX, frameY = frame:GetCenter()
    if not (Readable(x) and Readable(y) and Readable(frameX) and Readable(frameY)
        and x and y and frameX and frameY) then return end
    local width = label:GetWidth()
    local textWidth = label.GetUnboundedStringWidth and label:GetUnboundedStringWidth() or label:GetStringWidth()
    if not Readable(width) or not Readable(textWidth) or not width or not textWidth or textWidth <= width then return end
    local numPoints = label:GetNumPoints()
    if not Readable(numPoints) or not numPoints or numPoints == 0 then return end
    local points = {}
    for i = 1, numPoints do
        local point, parent, relativePoint, offsetX, offsetY = label:GetPoint(i)
        if not (Readable(point) and Readable(parent) and Readable(relativePoint)
            and Readable(offsetX) and Readable(offsetY)) then return end
        points[i] = { point, parent, relativePoint, offsetX, offsetY }
    end
    state.originalWidth, state.originalPoints = width, points
    state.wideLabel, state.widePlate, state.wideParent = label, plate, frame
    state.wideX, state.wideY = x - frameX, y - frameY
    label:ClearAllPoints()
    label:SetPoint("CENTER", frame, "CENTER", state.wideX, state.wideY)
    label:SetWidth(math.ceil(textWidth) + 2)
end

local function Update(unit, state, lookup)
    local player, friendly = UnitIsPlayer(unit), UnitIsFriend("player", unit)
    if FA.Settings().nameplateTitles == false or IsInInstance()
        or not Readable(player) or not player or not Readable(friendly) or not friendly then
        Restore(state)
        RestoreWidth(state)
        return
    end
    local plate = C_NamePlate.GetNamePlateForUnit(unit)
    local frame = plate and not plate:IsForbidden() and plate.UnitFrame
    local label = frame and not frame:IsForbidden() and frame.name
    if not label or (label.IsForbidden and label:IsForbidden()) or not label:IsShown() then
        Restore(state)
        RestoreWidth(state)
        return
    end
    local text = label:GetText()
    local name = FA.FullName(unit)
    if not Readable(text) or not name then
        Restore(state)
        RestoreWidth(state)
        return
    end
    local sent = lookup and FA.RequestNearbyTitle(name)
    local title = FA.NearbyTitle(name)
    if type(title) ~= "string" or not title:find("%s", 1, true) or title:find("|", 1, true) then
        Restore(state)
        FitName(state, plate, frame, label)
        return sent
    end
    local ok, rendered = pcall(string.format, title, (name:gsub("-", " ")))
    if not ok then Restore(state); FitName(state, plate, frame, label); return sent end
    if state.label ~= label then Restore(state) end
    if text ~= state.rendered then state.original = text end
    state.label, state.rendered = label, rendered
    if text ~= rendered then label:SetText(rendered) end
    FitName(state, plate, frame, label)
    return sent
end

function FA.RefreshNameplateTitles()
    for unit, state in pairs(visible) do Update(unit, state) end
end

local function Track(unit)
    if not IsPlateToken(unit) then return end
    if not visible[unit] then visible[unit] = {} end
    Update(unit, visible[unit])
end

local function DiscoverPlates()
    if not C_NamePlate.GetNamePlates then return end
    for _, plate in pairs(C_NamePlate.GetNamePlates()) do
        if not plate:IsForbidden() then
            local frame = plate.UnitFrame
            local unit = frame and not frame:IsForbidden() and frame.unit
            if not IsPlateToken(unit) then unit = plate.unitToken end
            Track(unit)
        end
    end
end

local hooked, hookedDriver
local function HookNameUpdates()
    if not hooked and CompactUnitFrame_UpdateName then
        hooksecurefunc("CompactUnitFrame_UpdateName", function(frame)
            if frame:IsForbidden() then return end
            local unit = frame.unit
            if not IsPlateToken(unit) then return end
            local plate = C_NamePlate.GetNamePlateForUnit(unit)
            if plate and not plate:IsForbidden() and plate.UnitFrame == frame then Track(unit) end
        end)
        hooked = true
    end
    local driver = NamePlateDriverFrame
    if driver and driver ~= hookedDriver and type(driver.OnNamePlateAdded) == "function" then
        -- This runs after Blizzard has attached the pooled UnitFrame.
        hooksecurefunc(driver, "OnNamePlateAdded", function(_, unit) Track(unit) end)
        hookedDriver = driver
    end
end

local events = CreateFrame("Frame")
events:RegisterEvent("NAME_PLATE_UNIT_ADDED")
events:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:SetScript("OnEvent", function(_, event, unit)
    if event == "PLAYER_ENTERING_WORLD" then
        HookNameUpdates()
        FA.ApplyFriendlyNameplateStyle()
        DiscoverPlates()
        FA.RefreshNameplateTitles()
    elseif event == "PLAYER_REGEN_ENABLED" then
        FA.ApplyFriendlyNameplateStyle()
        FA.RefreshNameplateTitles()
    elseif not IsPlateToken(unit) then
        return
    elseif event == "NAME_PLATE_UNIT_ADDED" then
        Track(unit)
    else
        if visible[unit] then
            Restore(visible[unit])
            RestoreWidth(visible[unit])
        end
        if nextLookup == unit then nextLookup = next(visible, unit) end
        visible[unit] = nil
    end
end)
HookNameUpdates()
C_Timer.NewTicker(1, function()
    if FA.Settings().nameplateTitles == false or IsInInstance() then return end
    local unit = nextLookup or next(visible)
    for _ = 1, 12 do
        if not unit then break end
        nextLookup = next(visible, unit)
        if Update(unit, visible[unit], true) then break end
        unit = nextLookup
    end
end)
