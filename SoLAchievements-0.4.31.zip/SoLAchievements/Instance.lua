-------------------------------------------------------------------------------
--  SoLAchievements: the instance you are in. Its achievements
--  (the dungeon's or raid's own, by its name, and any whose boss list names
--  a boss of it) go on the tracker as context for as long as you are inside
--  (your pinned ones stay as they are), and once per entry a chat line says
--  what is here (Settings: Instance hint). The Current Zone page lists them.
-------------------------------------------------------------------------------
local _, ns = ...
local FA = ns.FA
local TAG = FA.TAG

-- The achievements of the instance named name, not earned.
function ns.InstanceAchievements(name)
    local out, seen = {}, {}
    if not name or name == "" then return out end
    for _, a in ipairs(FA.ALL) do
        if not seen[a.key] and FA.Available(a) and not (ns.IsExcluded and ns.IsExcluded(a.key)) then
            local hit = a.name == name or a.instance == name
            if not hit and type(a.desc) == "string" and a.desc:find(name, 1, true) then hit = true end
            if hit then seen[a.key] = true; out[#out + 1] = a end
        end
    end
    return out
end

-- In an instance now: its name (nil outside).
function ns.CurrentInstance()
    if not GetInstanceInfo then return nil end
    local name, kind = GetInstanceInfo()
    if FA.secret(name) or FA.secret(kind) then return nil end
    if kind == "party" or kind == "raid" then return name, kind end
    return nil
end

local lastInstance
local function Enter()
    wipe(ns.contextKeys)
    local name = ns.CurrentInstance()
    if not name then
        lastInstance = nil
        if FA.UpdateTracker then FA.UpdateTracker() end
        return
    end
    local list = ns.InstanceAchievements(name)
    local open = {}
    for _, a in ipairs(list) do
        if not FA.Earned(a.key) then
            open[#open + 1] = a
            if FA.Settings().instanceTrack ~= false then ns.contextKeys[a.key] = true end
        end
    end
    if FA.UpdateTracker then FA.UpdateTracker() end
    -- (once per entry, not on every loading screen inside)
    if name ~= lastInstance and #open > 0 and FA.Settings().instanceHint == true then
        local names = {}
        for i = 1, math.min(3, #open) do names[i] = FA.LINK.fn(open[i]) end
        print(("%s %s: %d %s here: %s%s"):format(TAG, name, #open, #open == 1 and "achievement" or "achievements",
            table.concat(names, ", "), #open > 3 and (" +" .. (#open - 3)) or ""))
    end
    lastInstance = name
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("ZONE_CHANGED_NEW_AREA")
f:SetScript("OnEvent", function() C_Timer.After(2, Enter) end)
