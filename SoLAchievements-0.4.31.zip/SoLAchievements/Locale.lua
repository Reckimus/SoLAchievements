-------------------------------------------------------------------------------
--  Translations. The interface is written in English and every text is its
--  own key: L["Send all"] is "Send all" until a translation sets it. A
--  language adds its block below (keys copied from the English text).
--      if GetLocale() == "deDE" then
--          L["Send all"] = "Alle senden"
--      end
--  A text without a translation stays English (never a blank or a key).
-------------------------------------------------------------------------------
local _, ns = ...
local L = setmetatable({}, { __index = function(_, key) return key end })
ns.L = L
