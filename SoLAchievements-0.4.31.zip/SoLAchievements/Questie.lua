-------------------------------------------------------------------------------
--  Questie (third-party, optional): the one place that knows how its
--  database is reached. The rest of Achievements asks this adapter only.
--    ns.Questie.State()          "READY" | "LOADING" | "PARTIAL" | "MISSING"
--    ns.Questie.QuestZone(id)    a quest's zone or sort id (nil: unknown)
--    ns.Questie.Describe()       the state in words
--  READY: QuestieDB's QuestDB answers. LOADING: the addon is loaded but its
--  database is not there yet. PARTIAL: something of it is there but not
--  the calls we use. MISSING: neither Questie nor QuestieDB.
--  Every call is guarded: a change on Questie's side gives "unknown", never
--  an error in Achievements.
-------------------------------------------------------------------------------
local _, ns = ...
local Q = {}
ns.Questie = Q

local function Loaded(name)
    local fn = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    if not fn then return false end
    local ok, yes = pcall(fn, name)
    return ok and yes and true or false
end

local function DB()
    local q = rawget(_G, "QuestDB")
    return type(q) == "table" and q or nil
end

function Q.State()
    local q = DB()
    if q then
        if type(q.Exists) == "function" and type(q.Get) == "function" then return "READY" end
        return "PARTIAL"
    end
    if Loaded("QuestieDB") or Loaded("Questie") or rawget(_G, "QuestieLoader") then return "LOADING" end
    return "MISSING"
end

function Q.Ready() return Q.State() == "READY" end

function Q.QuestZone(id)
    local q = DB()
    if not (q and type(q.Exists) == "function" and type(q.Get) == "function") then return nil end
    local ok, exists = pcall(q.Exists, id)
    if not (ok and exists) then return nil end
    local ok2, z = pcall(q.Get, id, "zoneOrSort")
    if ok2 and type(z) == "number" then return z end
    return nil
end

local WORDS = { READY = "ready", LOADING = "loading", PARTIAL = "partial (an unknown version)", MISSING = "missing" }
function Q.Describe() return WORDS[Q.State()] or "unknown" end
