-- If the old SavedVariables files were copied to the new filename,
-- WoW loads those legacy globals before executing this file.
if type(SoLAchievementsDB) ~= "table" and type(ForeverAchievementsDB) == "table" then
    SoLAchievementsDB = ForeverAchievementsDB
end
if type(SoLAchievementsCharDB) ~= "table" and type(ForeverAchievementsCharDB) == "table" then
    SoLAchievementsCharDB = ForeverAchievementsCharDB
end
ForeverAchievementsDB = nil
ForeverAchievementsCharDB = nil
