-------------------------------------------------------------------------------
--  SoLAchievements: the developer commands.
--    /fach explore    where you stand for the exploration achievements
--    /fach target     what your target means to the achievements
--    /fach perf       how long a full check pass takes, memory
--    /fach resetpos   the window back to the centre
-------------------------------------------------------------------------------
local _, ns = ...
local FA = ns.FA
local TAG = FA.TAG
local secret = FA.secret

local function Say(text) print(TAG .. " " .. text) end

FA.SLASH.explore = function()
    local mapID = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    local zone, sub = GetRealZoneText(), GetSubZoneText()
    if secret(zone) then zone = "?" end
    if secret(sub) then sub = "?" end
    local pos = mapID and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(mapID, "player")
    local x, y
    if pos and pos.GetXY then x, y = pos:GetXY() end
    Say(("map %s  ·  %s / %s  ·  %s"):format(tostring(mapID), tostring(zone), tostring(sub),
        (x and y and not secret(x)) and ("%.1f, %.1f"):format(x * 100, y * 100) or "no position"))
    local found
    for _, z in ipairs(ns.EXPLORE or {}) do
        if (mapID and z.map == mapID) or z.zone == zone then
            found = z
            break
        end
    end
    if not found then Say("no exploration achievement knows this zone (" .. tostring(zone) .. ").") return end
    local key = found.key or ("explore" .. tostring(found.id))
    local a = FA.BY_KEY[key]
    Say(("zone data: %s (map %s)  ·  achievement %s%s"):format(found.zone, tostring(found.map), a and a.name or key,
        a and FA.Earned(a.key) and " (earned)" or ""))
    local match, nearest, nearD
    for _, area in ipairs(found.areas or {}) do
        if area[1] == sub then match = area end
        local known = area[2] and area[3] and not (area[2] == 0 and area[3] == 0)
        if known and x and y and not secret(x) then
            -- (offsets are in the map's texture pixels, about 1002 by 668)
            local dx, dy = x * 1002 - area[2], y * 668 - area[3]
            local d = dx * dx + dy * dy
            if not nearD or d < nearD then nearest, nearD = area, d end
        end
    end
    if match then
        Say(("subzone matches the criterion %s%s"):format(match[1],
            (match[2] == 0 and match[3] == 0) and " (no map offset known: counts by this name)" or ""))
    else
        Say("this subzone is no criterion" .. (sub ~= "" and (" (" .. sub .. ")") or ""))
    end
    if nearest then Say(("nearest known criterion: %s"):format(nearest[1])) end
    local explored = 0
    if C_MapExplorationInfo and C_MapExplorationInfo.GetExploredMapTextures and mapID then
        explored = #(C_MapExplorationInfo.GetExploredMapTextures(mapID) or {})
    end
    Say(("the map shows %d explored overlays here"):format(explored))
end

FA.SLASH.target = function()
    if not UnitExists("target") then Say("no target.") return end
    local name = UnitName("target")
    if secret(name) then name = "?" end
    local guid = UnitGUID("target")
    local id = (guid and not secret(guid) and FA.NpcID) and FA.NpcID(guid) or nil
    local class = UnitClassification and UnitClassification("target")
    if secret(class) then class = "?" end
    Say(("%s  ·  npc %s  ·  %s  ·  %s"):format(tostring(name), tostring(id), tostring(class),
        UnitIsDead("target") and "dead" or "alive"))
    local api = rawget(_G, "SoLAchievementsAPI")
    local list = (api and id) and api.GetRelevantForNPC(id) or {}
    if #list == 0 then Say("needed for no achievement (or already done).") end
    for _, r in ipairs(list) do Say(("needed for %s: %s"):format(r.name or "?", r.criterion or "?")) end
    local isPest = FA.PEST_NAMES and FA.PEST_NAMES[name]
    local isBoss = (id and FA.BOSS_IDS and FA.BOSS_IDS[id]) or (FA.BOSS_BY_NAME and FA.BOSS_BY_NAME[name])
    Say(("pest %s  ·  boss %s  ·  critter %s"):format(isPest and "yes" or "no", isBoss and "yes" or "no",
        (FA.CritterHere and pcall(FA.CritterHere, name)) and "known" or "no"))
end

FA.SLASH.perf = function()
    local t0 = debugprofilestop and debugprofilestop() or 0
    if ns.ClearEvaluations then ns.ClearEvaluations() end
    local n, blocked = 0, 0
    for _, a in ipairs(FA.ALL) do
        n = n + 1
        if ns.Evaluate and ns.Evaluate(a).blocked then blocked = blocked + 1 end
    end
    local t1 = debugprofilestop and debugprofilestop() or 0
    if UpdateAddOnMemoryUsage then UpdateAddOnMemoryUsage() end
    local mem = GetAddOnMemoryUsage and GetAddOnMemoryUsage("SoLAchievements") or 0
    Say(("%d achievements evaluated in %.1f ms (%d blocked)  ·  memory %.0f KB"):format(n, t1 - t0, blocked, mem))
end

FA.SLASH.resetpos = function()
    FA.Settings().winPos = nil
    local w = _G.SoLAchievementsWindow
    if w then w:ClearAllPoints(); w:SetPoint("CENTER") end
    Say("window back in the centre.")
end
