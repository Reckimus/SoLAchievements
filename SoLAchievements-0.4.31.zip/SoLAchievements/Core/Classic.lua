-------------------------------------------------------------------------------
--  SoLAchievements: five WotLK achievements of the classic world
--
--  Classic Dungeonmaster and Classic Raider are metas over the dungeon and
--  raid achievements the addon already tracks (no kills of their own).
--  Shave and a Haircut and Safe Deposit read the game's own statistics,
--  backed by the barber and bank events. Leeeeeeeeeeeeeroy! counts Rookery
--  Whelp deaths from the death lines in chat (the combat log is closed to
--  addons on this client), in a rolling 15 second window.
--
--  Loaded after Professions.lua (the dungeon sections) and before
--  WorldEvents.lua, which builds the list of every achievement.
-------------------------------------------------------------------------------

local ADDON, ns = ...
local FAC = ns.Split_SoLAchievements
local DB, TAG, secret = FAC.DB, FAC.TAG, FAC.secret

local function SectionOf(sections, title)
    for _, sec in ipairs(sections) do if sec.title == title then return sec end end
end

-------------------------------------------------------------------------------
--  Metas: Classic Dungeonmaster (1283) and Classic Raider (1285)
-------------------------------------------------------------------------------
-- The children by achievement ID, in the WotLK criteria order. Each is the
-- addon's own dungeon or raid achievement (key "dungeon<ID>").
local DUNGEONMASTER = { 629, 628, 630, 631, 632, 633, 634, 635, 637, 636, 638, 639, 640, 641, 642, 643, 644, 645, 646 }
local RAIDER = { 686, 685, 688, 689, 687 }

-- pts: the achievement's own WotLK points (Classic Dungeonmaster 10,
-- Classic Raider 20).
local function MetaAch(key, id, name, desc, icon, ids, sections, title, pts)
    local byID = {}
    for _, sec in ipairs(sections) do
        for _, a in ipairs(sec.list) do if a.id then byID[a.id] = a end end
    end
    local children, names, keyOf = {}, {}, {}
    for _, cid in ipairs(ids) do
        local child = byID[cid]
        if child then
            children[#children + 1] = child
            names[#names + 1] = child.name
            keyOf[child.name] = child.key
        end
    end
    local a = { key = key, id = id, icon = icon, name = name, desc = desc, pts = pts or 10, list = names, meta = true,
                -- checked in combat too: a boss kill earns the child, then this in the same pass
                kill = true,
                tracking = "Earned when every dungeon or raid achievement listed is earned on this character.",
                has = function(n) return DB().done[keyOf[n]] and true or false end,
                progress = function()
                    local c = 0
                    for _, child in ipairs(children) do if DB().done[child.key] then c = c + 1 end end
                    return c, #children
                end }
    -- After its children: one pass earns the last child, then the meta.
    local sec = SectionOf(sections, title)
    if sec then sec.list[#sec.list + 1] = a end
    return a
end

local DUNGEON_SECTIONS = FAC.DUNGEON_SECTIONS
FAC.classicDungeonmaster = MetaAch("classicDungeonmaster", 1283, "Classic Dungeonmaster",
    "Complete the classic dungeon achievements listed below.",
    "Interface\\Icons\\Achievement_Dungeon_ClassicDungeonMaster", DUNGEONMASTER, DUNGEON_SECTIONS, "DUNGEONS", 10)
FAC.classicRaider = MetaAch("classicRaider", 1285, "Classic Raider",
    "Complete the classic raid achievements listed below.",
    "Interface\\Icons\\Achievement_Dungeon_ClassicRaider", RAIDER, DUNGEON_SECTIONS, "RAIDS", 20)

-------------------------------------------------------------------------------
--  Leeeeeeeeeeeeeroy! (2188): 50 Rookery Whelps within 15 seconds
-------------------------------------------------------------------------------
local WHELP = "Rookery Whelp" -- NPC 10161; the death lines name it, they carry no creature ID
local WINDOW, NEED = 15, 50
-- GetTime() of each whelp death in the window: this session only, an
-- attempt never survives a reload or a logout.
local kills = {}

local function Prune(now)
    while kills[1] and now - kills[1] > WINDOW do table.remove(kills, 1) end
end

local function Live()
    local now = GetTime()
    Prune(now)
    return #kills, kills[1] and (now - kills[1]) or nil
end

-- (its WotLK reward, the title "<name> Jenkins", through the addon's titles)
local leeroy = { key = "leeroy", id = 2188, name = "Leeeeeeeeeeeeeroy!", pts = 10, kill = true, title = "%s Jenkins",
    icon = "Interface\\Icons\\INV_Misc_Head_Dragon_Black",
    desc = "Kill 50 Rookery Whelps within 15 seconds in Upper Blackrock Spire.",
    tracking = "Rookery Whelp deaths from the chat's death lines (yours and your group's), in a rolling 15 second window. "
        .. "Counted only while you are there; nothing carries over a reload." }
leeroy.progress = function()
    if DB().flags.leeroy then return NEED, NEED end
    return math.min((Live()), NEED), NEED
end
-- The tracker's value while an attempt runs: "32/50  8.4s/15s".
leeroy.liveText = function()
    if DB().flags.leeroy then return nil end
    local n, elapsed = Live()
    if n == 0 or not elapsed then return nil end
    return ("%d/%d  %.1fs/%ds"):format(n, NEED, elapsed, WINDOW)
end
table.insert(SectionOf(DUNGEON_SECTIONS, "DUNGEONS").list, leeroy)

-------------------------------------------------------------------------------
--  Shave and a Haircut (545) and Safe Deposit (546)
-------------------------------------------------------------------------------
local STAT_BARBER_GOLD, STAT_BANK_SLOTS = 1147, 928

-- Any gold spent at a barber shop: the game's statistic, so a haircut from
-- before the addon counts too.
local function PaidBarber()
    local text = FAC.StatText(STAT_BARBER_GOLD)
    return text ~= nil and text:find("[1-9]") ~= nil
end

local barber = { key = "barber", id = 545, name = "Shave and a Haircut", pts = 10, title = "%s, Freshly Shorn",
    icon = "Interface\\Icons\\INV_Misc_Comb_02",
    desc = "Visit a Barber Shop and get a haircut.",
    tracking = "The game's \"Gold spent at barber shops\" statistic, or a change applied in the barber chair. Opening it is not enough.",
    progress = function() return (DB().flags.barber or PaidBarber()) and 1 or 0, 1 end }

-- The client's number of bank bag slots: WotLK has 7; a client with fewer
-- asks for all it has, or the achievement could never be earned.
local function SlotsWanted()
    local n = tonumber(rawget(_G, "NUM_BANKBAGSLOTS"))
    if n and n >= 1 and n < 7 then return n end
    return 7
end

-- Bank bag slots bought: the statistic, or the bank's own count (both are
-- purchases, never the bags put in them). The best seen is kept.
local function SlotsBought()
    local d = DB()
    local best = math.max(d.bankSlotsBest or 0, FAC.StatNumber(STAT_BANK_SLOTS) or 0)
    if type(GetNumBankSlots) == "function" then
        local ok, n = pcall(GetNumBankSlots)
        n = ok and not secret(n) and tonumber(n) or nil
        if n then best = math.max(best, n) end
    end
    d.bankSlotsBest = best
    return best
end

local safeDeposit = { key = "safeDeposit", id = 546, name = "Safe Deposit", pts = 10, title = "%s, Out of Bank Space",
    icon = "Interface\\Icons\\INV_Box_01",
    desc = "Buy 7 additional bank slots.",
    progress = function() local need = SlotsWanted(); return math.min(SlotsBought(), need), need end }

-- General, with the other things done around the world.
local around = SectionOf(FAC.SECTIONS, "AROUND AZEROTH")
around.list[#around.list + 1] = barber
around.list[#around.list + 1] = safeDeposit

-------------------------------------------------------------------------------
--  Events
-------------------------------------------------------------------------------
local ev = CreateFrame("Frame")
local handlers = {}
-- Guarded: an event this client does not have must not stop the file.
local function On(event, fn)
    if pcall(ev.RegisterEvent, ev, event) then handlers[event] = fn end
end
ev:SetScript("OnEvent", function(_, event, ...) handlers[event](...) end)

-- The barber: only a change that was applied (and paid for) counts.
local function Haircut()
    if DB().flags.barber then return end
    DB().flags.barber = true
    FAC.CheckAll()
end
On("BARBER_SHOP_APPEARANCE_APPLIED", Haircut)
On("BARBER_SHOP_SUCCESS", Haircut)
On("BARBER_SHOP_RESULT", function(success) if success == true then Haircut() end end)

-- The bank: a slot bought, or the bank opened (its count read again).
On("PLAYERBANKBAGSLOTS_CHANGED", function() FAC.CheckAll() end)
On("BANKFRAME_OPENED", function() FAC.CheckAll() end)

-- The whelps. "You have slain %s!", "%s dies." and "%s is slain by %s!"
-- from the game's own strings.
local function Pattern(fmt)
    if type(fmt) ~= "string" then return nil end
    fmt = fmt:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")
    fmt = fmt:gsub("%%%%s", "(.+)")
    return "^" .. fmt .. "$"
end
local P_SLAIN = Pattern(rawget(_G, "SELFKILLOTHER") or "You have slain %s!")
local P_DIES = Pattern(rawget(_G, "UNITDIESOTHER") or "%s dies.")
local P_PARTY = Pattern(rawget(_G, "PARTYKILLOTHER") or "%s is slain by %s!")

-- One death may come as a "slain" line and a "dies" line in the same frame;
-- several whelps dying to one blow come in one frame too. A frame counts
-- the larger of its two kinds of line, so a death is never counted twice
-- (at worst one is missed, never one too many).
local frame = { at = -1, slain = 0, dies = 0, counted = 0 }
local ticker

local function Tick()
    local n = Live()
    if ns.FA and ns.FA.UpdateTracker then ns.FA.UpdateTracker() end
    if n == 0 and ticker then ticker:Cancel(); ticker = nil end
end

local function WhelpDied(kind)
    local now = GetTime()
    if frame.at ~= now then frame.at, frame.slain, frame.dies, frame.counted = now, 0, 0, 0 end
    frame[kind] = frame[kind] + 1
    local deaths = math.max(frame.slain, frame.dies)
    for _ = frame.counted + 1, deaths do kills[#kills + 1] = now end
    frame.counted = deaths
    Prune(now)
    if FAC.debugOn then print(TAG .. (" Rookery Whelp down (%s): %d in the last %ds"):format(kind, #kills, WINDOW)) end
    if #kills >= NEED and not DB().flags.leeroy then
        DB().flags.leeroy = true
        wipe(kills)
    end
    -- (a kill pass: it runs in combat)
    FAC.CheckAll(nil, true)
    if not ticker and #kills > 0 and C_Timer.NewTicker then ticker = C_Timer.NewTicker(0.25, Tick) end
end

On("CHAT_MSG_COMBAT_HOSTILE_DEATH", function(msg)
    if not msg or secret(msg) or DB().flags.leeroy then return end
    local who = P_SLAIN and msg:match(P_SLAIN)
    if who == WHELP then return WhelpDied("slain") end
    who = P_PARTY and msg:match(P_PARTY)
    if who == WHELP then return WhelpDied("slain") end
    who = P_DIES and msg:match(P_DIES)
    if who == WHELP then return WhelpDied("dies") end
end)

-- (for the tests)
FAC.Classic = { kills = kills, WhelpDied = WhelpDied, SlotsWanted = SlotsWanted, frame = frame,
    leeroy = leeroy, barber = barber, safeDeposit = safeDeposit }
