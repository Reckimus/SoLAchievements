-------------------------------------------------------------------------------
--  Credits and license of this data
--
--  The tables in this file are derived from QuestieDB, the database of the
--  Questie addon (https://github.com/Questie/Questie), by the Questie team
--  and its contributors. QuestieDB is licensed under the GNU General Public
--  License v3.0 (GPL-3.0), and this derived data is used and redistributed
--  under the terms of the GPL-3.0: https://www.gnu.org/licenses/gpl-3.0.html
-------------------------------------------------------------------------------

-- Where the critters of To All The Squirrels I've Loved Before and Pest
-- Control live: generated from QuestieDB's Forever NPC spawns (creatures
-- of the same name merged), most spawns first, instances last. Not in the
-- data: Crab, Scorpion, Skunk.
local _, ns = ...

-- areaID -> { English name, uiMapID }; an instance has no uiMapID and is
-- matched by the zone text.
ns.CRITTER_AREAS = {
    [1] = { "Dun Morogh", 1426 },
    [8] = { "Swamp of Sorrows", 1435 },
    [10] = { "Duskwood", 1431 },
    [11] = { "Wetlands", 1437 },
    [12] = { "Elwynn Forest", 1429 },
    [14] = { "Durotar", 1411 },
    [15] = { "Dustwallow Marsh", 1445 },
    [17] = { "The Barrens", 1413 },
    [28] = { "Western Plaguelands", 1422 },
    [33] = { "Stranglethorn Vale", 1434 },
    [36] = { "Alterac Mountains", 1416 },
    [38] = { "Loch Modan", 1432 },
    [40] = { "Westfall", 1436 },
    [44] = { "Redridge Mountains", 1433 },
    [45] = { "Arathi Highlands", 1417 },
    [46] = { "Burning Steppes", 1428 },
    [51] = { "Searing Gorge", 1427 },
    [85] = { "Tirisfal Glades", 1420 },
    [130] = { "Silverpine Forest", 1421 },
    [141] = { "Teldrassil", 1438 },
    [148] = { "Darkshore", 1439 },
    [215] = { "Mulgore", 1412 },
    [267] = { "Hillsbrad Foothills", 1424 },
    [331] = { "Ashenvale", 1440 },
    [357] = { "Feralas", 1444 },
    [405] = { "Desolace", 1443 },
    [406] = { "Stonetalon Mountains", 1442 },
    [490] = { "Un'Goro Crater", 1449 },
    [493] = { "Moonglade", 1450 },
    [718] = { "Wailing Caverns" },
    [722] = { "Razorfen Downs" },
    [796] = { "Scarlet Monastery" },
    [1497] = { "Undercity", 1458 },
    [1519] = { "Stormwind City", 1453 },
    [1581] = { "The Deadmines" },
    [1583] = { "Blackrock Spire" },
    [1657] = { "Darnassus", 1457 },
    [1977] = { "Zul'Gurub" },
    [2057] = { "Scholomance" },
    [2100] = { "Maraudon" },
    [2557] = { "Dire Maul" },
    [3456] = { "Naxxramas" },
}

-- critter name -> areaIDs
ns.CRITTER_ZONES = {
    ["Adder"] = { 17, 14 },
    ["Cat"] = { 12, 45 },
    ["Chicken"] = { 40, 12, 17, 267, 11, 10, 15, 85, 44, 1 },
    ["Cow"] = { 12, 267, 45, 11, 40, 44 },
    ["Deer"] = { 493, 12, 141, 331, 1657, 36, 148, 357, 130, 406, 40, 28, 2557 },
    ["Fawn"] = { 12 },
    ["Fire Beetle"] = { 51, 46 },
    ["Frog"] = { 2557, 2100, 1977 },
    ["Gazelle"] = { 17 },
    ["Hare"] = { 14 },
    ["Larva"] = { 3456 },
    ["Maggot"] = { 331, 3456 },
    ["Moccasin"] = { 8 },
    ["Mouse"] = { 40 },
    ["Parrot"] = { 490 },
    ["Prairie Dog"] = { 215, 17, 45, 40 },
    ["Rabbit"] = { 1, 12, 141, 44, 493, 148, 406, 85, 267, 357, 11, 130, 2557, 796 },
    ["Ram"] = { 11, 36, 38, 45 },
    ["Rat"] = { 85, 405, 45, 1519, 36, 130, 406, 267, 1497, 33, 3456, 2557, 796, 2057, 1581, 1977 },
    ["Roach"] = { 405, 28, 406, 1583, 2557, 2100, 722 },
    ["Sheep"] = { 12, 38, 44, 267, 36 },
    ["Snake"] = { 15, 405, 357, 490, 40, 130, 2557, 2100, 718, 1977 },
    ["Spider"] = { 3456, 1977 },
    ["Squirrel"] = { 493, 1657, 38, 406, 15, 331, 357, 148, 1519, 130, 2557 },
    ["Swine"] = { 14, 17 },
    ["Toad"] = { 15, 490, 1657, 141, 11, 8, 130, 45, 1977 },
}
