local _, ns = ...
local FA = ns.FA
local ID = "SoLAchievements"

-------------------------------------------------------------------------------
--  Schema: SoLAchievementsDB.schemaVersion, one step at a time. The
--  achievement data's own revision stays dataVersion (per character).
-------------------------------------------------------------------------------
local SCHEMA = 2
local MIGRATIONS = {
    -- 0 -> 1: the version is written down; nothing is moved.
    [1] = function(db) end,
    -- 1 -> 2: completion provenance. Before it, the history pass wrote the
    -- time it ran as the earned date; those entries came in bursts (three
    -- or more in the same second) and get "date not known". Nothing is
    -- removed and no date is changed.
    [2] = function(db)
        local function Mark(done, meta)
            local by = {}
            for key, t in pairs(done or {}) do by[t] = (by[t] or 0) + 1 end
            for key, t in pairs(done or {}) do
                if not meta[key] then
                    if by[t] >= 3 then meta[key] = { source = "backfill", exact = false }
                    else meta[key] = { source = "observed", exact = true } end
                end
            end
        end
        local d = ns.FA.DB()
        d.doneMeta = d.doneMeta or {}
        Mark(d.done, d.doneMeta)
        for _, c in pairs(db.chars or {}) do
            if type(c) == "table" and type(c.done) == "table" then
                c.doneMeta = c.doneMeta or {}
                Mark(c.done, c.doneMeta)
            end
        end
    end,
}
local function Migrate()
    local db = FA.Account()
    local v = tonumber(db.schemaVersion) or 0
    while v < SCHEMA do
        local step = MIGRATIONS[v + 1]
        if step then
            local ok = pcall(step, db)
            if not ok then return end -- (stays where it is: tried again next login)
        end
        v = v + 1
        db.schemaVersion = v
    end
end

-------------------------------------------------------------------------------
--  Selftest: the data and the integrations, nothing changed.
-------------------------------------------------------------------------------
local function SelfTest(Check)
    local db = FA.Account()
    Check((db.schemaVersion or 0) == SCHEMA and "PASS" or "WARN", ("schema %s of %d"):format(tostring(db.schemaVersion), SCHEMA))
    local seen, n = {}, 0
    for _, a in ipairs(FA.ALL) do
        n = n + 1
        if seen[a.key] then Check("FAIL", "duplicate key " .. tostring(a.key)) end
        seen[a.key] = true
        if type(a.name) ~= "string" or a.name == "" then Check("FAIL", "no name: " .. tostring(a.key)) end
        if type(a.desc) ~= "string" then Check("WARN", "no description: " .. tostring(a.key)) end
        if type(a.pts) ~= "number" or a.pts < 0 then Check("FAIL", "bad points: " .. tostring(a.key)) end
        if type(a.progress) ~= "function" then
            Check("FAIL", "no progress: " .. tostring(a.key))
        else
            local ok, cur, need = pcall(a.progress)
            if not ok then Check("FAIL", "progress fails: " .. tostring(a.key) .. " (" .. tostring(cur) .. ")")
            elseif type(need) ~= "number" or need <= 0 then Check("FAIL", "need <= 0: " .. tostring(a.key))
            elseif type(cur) ~= "number" or cur > need then Check("WARN", ("progress %s / %s: %s"):format(tostring(cur), tostring(need), a.key)) end
        end
    end
    Check(n > 0 and "PASS" or "FAIL", n .. " achievements")
    -- The game's own ids: each used once.
    local ids = {}
    for _, a in ipairs(FA.ALL) do
        if a.id then
            if ids[a.id] then Check("FAIL", ("native id %s on %s and %s"):format(tostring(a.id), ids[a.id], tostring(a.key))) end
            ids[a.id] = tostring(a.key)
        end
    end
    -- Series: every member names its series, and every series lists it.
    for name, list in pairs(FA.SERIES or {}) do
        if #list < 2 then Check("WARN", "series of one: " .. name) end
        for _, a in ipairs(list) do
            if a.series ~= name then Check("FAIL", ("%s listed in series %s but names %s"):format(tostring(a.key), name, tostring(a.series))) end
            if not seen[a.key] then Check("FAIL", ("series %s lists an unknown achievement"):format(name)) end
        end
    end
    for _, a in ipairs(FA.ALL) do
        if a.series and not (FA.SERIES and FA.SERIES[a.series]) then Check("FAIL", ("%s names a missing series %s"):format(tostring(a.key), tostring(a.series))) end
    end
    -- Events: each event section maps to a known event.
    for _, sec in ipairs(ns.EVENT_SECTIONS or {}) do
        if sec.event and not (ns.EVENT_BY_KEY and ns.EVENT_BY_KEY[sec.event]) then
            Check("FAIL", "event section for an unknown event: " .. tostring(sec.event))
        end
    end
    -- Pinned and watch list: only keys that exist (an old key: stale).
    local d = FA.DB()
    local stale = 0
    for _, set in ipairs({ d.tracked or {}, d.watch or {} }) do
        for key in pairs(set) do if not seen[key] then stale = stale + 1 end end
    end
    Check(stale == 0 and "PASS" or "WARN", stale == 0 and "pinned and watch list keys all known" or (stale .. " pinned or watched keys no longer exist"))
    -- Provenance: every earned one says how it was earned.
    local noMeta, unknownKey = 0, 0
    for key in pairs(d.done or {}) do
        if not seen[key] then unknownKey = unknownKey + 1
        elseif not (d.doneMeta and d.doneMeta[key]) then noMeta = noMeta + 1 end
    end
    Check(noMeta == 0 and "PASS" or "WARN", noMeta == 0 and "every earned achievement has its source" or (noMeta .. " earned without a source (shown as date unknown)"))
    if unknownKey > 0 then Check("WARN", unknownKey .. " earned keys no longer exist") end
    -- Providers this client must have.
    for _, fn in ipairs({ "GetRealZoneText", "C_Map", "GetStatistic", "C_Calendar" }) do
        Check(_G[fn] and "PASS" or "WARN", (_G[fn] and "has " or "missing ") .. fn)
    end
    -- Exploration: 0, 0 is an unknown offset (counts by subzone name only).
    local unknown = 0
    for _, z in ipairs(ns.EXPLORE or {}) do
        if z.map and type(z.map) ~= "number" then Check("FAIL", "bad map ID: " .. tostring(z.zone)) end
        for _, area in ipairs(z.areas or {}) do
            if area[2] == 0 and area[3] == 0 then unknown = unknown + 1
            elseif type(area[2]) == "number" and (area[2] < 0 or area[2] > 1024 or (area[3] or 0) < 0 or (area[3] or 0) > 1024) then
                Check("FAIL", ("offset out of range: %s %s"):format(tostring(z.zone), tostring(area[1])))
            end
        end
    end
    Check("PASS", unknown .. " exploration areas without an offset (subzone name only)")
    -- Events: which of their items this client knows.
    for _, e in ipairs(ns.EVENTS or {}) do
        local st = ns.eventState and ns.eventState[e.key]
        Check("PASS", ("event %s: %s"):format(e.name, st and st.state or "not read yet"))
    end
    local api = ns.QF.API()
    Check(api and "PASS" or "WARN", api and ("Fishing API v" .. tostring(api.version)) or "Fishing not loaded (its achievements wait)")
    local qs = ns.Questie.State()
    Check((qs == "READY" or qs == "MISSING") and "PASS" or "WARN", "Questie " .. ns.Questie.Describe())
    for name, c in pairs(db.chars or {}) do
        if type(c) ~= "table" or (c.done and type(c.done) ~= "table") then Check("FAIL", "broken character snapshot: " .. tostring(name)) end
    end
end

local function State()
    local _, all, earned, avail = FA.TotalPoints()
    local watch, pins = 0, 0
    for _ in pairs(FA.DB().tracked or {}) do pins = pins + 1 end
    for _ in pairs(FA.DB().watch or {}) do watch = watch + 1 end
    return {
        ("Achievements %d available  ·  Earned %d  ·  Points %d"):format(avail or 0, earned or 0, all or 0),
        ("Pinned %d  ·  Watched %d  ·  Data %s"):format(pins, watch, tostring(FA.DB().dataVersion)),
    }
end

local function Meta()
    local meta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    return meta and meta(ID, "Version") or "?"
end
-- The card's capabilities and the API's: one table.
local CAPS = { progress = true, completion = true, events = true, social = true, watch = true, pinned = true, npcRelevance = true,
               zoneRelevance = true, callbacks = true, fishingMilestones = true }

FA.SLASH.state = function()
    for _, line in ipairs(State()) do print(FA.TAG .. " " .. line) end
end
FA.SLASH.selftest = function()
    SelfTest(function(status, detail) print(FA.TAG .. " " .. status .. " — " .. detail) end)
end

do
    local f = CreateFrame("Frame")
    f:RegisterEvent("PLAYER_LOGIN")
    f:SetScript("OnEvent", function() Migrate() end)
end

-------------------------------------------------------------------------------
--  SoLAchievementsAPI: the stable, versioned API for other addons (the
--  scanner, fishing, navigation). Ask for a capability, not a version.
--  SoLAchievementsAPI (every internal) stays for older users; new code
--  uses this.
--    GetVersion()                 the addon's version
--    GetAchievement(key)          { key, name, desc, points } or nil
--    GetProgress(key)             { current, required, percent, remaining, completed, available,
--                                   blocked, reliability, recoverability }
--    IsEarned(key)                true / false (this character, or the account view)
--    GetCompletion(key)           { time, exact, source, character } or nil
--    GetWatchList()               { key, ... } the watch list
--    GetPinned()                  { key, ... } pinned to the on-screen tracker
--    GetRelevantForNPC(npcID)     { { key, name, criterion }, ... } still needed
--    OpenAchievement(key)         the window, searched for it
--    RegisterCallback(event, fn)  ACHIEVEMENT_EARNED (key),
--                                 ACHIEVEMENT_PROGRESS_CHANGED (key, current, required, before),
--                                 WATCH_CHANGED (key, watched), PINNED_CHANGED (key, pinned),
--                                 INTEGRATION_CHANGED (addon, loaded), DATA_READY ()
--    GetCounter(name)             a counter Achievements keeps ("fished")
--    IntroPending()               false; no introductory window
--    GetOption(name)              "screenshot", "toastY" (read only)
--    GetToastFrame()              its toast frame (nil before the first)
--    GetRareKills()               { [rare name] = time killed } (a copy)
--    GetInstanceBosses(name)      { boss name, ... } of a dungeon or raid
--    GetBossName(npcID)           the boss an NPC id is, or nil
--    TogglePinned(key)            pinned on / off (as the card's menu)
--    GetCriteria(key)             { { name, done }, ... } of a list achievement
--    GetCritterInfo()             { critters = { name }, pests = { [npcID] = name },
--                                   pestNames = { [name] = true } } (copies)
--    CritterHere(name), CritterNearest(names), CritterZones(name)
--    callbacks also: TOAST_SHOWN (frame)
--  capabilities.fishingMilestones: Achievements shows Fishing's milestones
--  itself (Fishing then leaves the announcing to it).
--  Other addons use this API only: never SoLAchievementsDB/CharDB or
--  SoLAchievementsAPI (the internals, kept for older users).
-------------------------------------------------------------------------------
do
    local listeners = {}
    local function Fire(event, ...)
        for _, fn in ipairs(listeners[event] or {}) do
            pcall(fn, ...)
        end
    end
    table.insert(FA.EARN_HOOKS, function(a) Fire("ACHIEVEMENT_EARNED", a.key) end)
    -- (the other modules tell their changes through this)
    ns.FireAPI = Fire
    -- The addons it works with, loaded later or on demand.
    local INTEGRATIONS = { QuickFish = true }
    local ie = CreateFrame("Frame")
    ie:RegisterEvent("ADDON_LOADED")
    ie:SetScript("OnEvent", function(_, _, name)
        if INTEGRATIONS[name] then Fire("INTEGRATION_CHANGED", name, true) end
    end)
    local prevReady = FA.OnReady
    FA.OnReady = function(...)
        if prevReady then pcall(prevReady, ...) end
        Fire("DATA_READY")
    end

    local function Copy(a)
        return a and { key = a.key, name = a.name, desc = a.desc, points = a.pts, money = a.money and true or nil,
                       icon = a.icon } or nil
    end
    -- The critter and pest lists (static data): copied once.
    local critterInfo
    SoLAchievementsAPI = {
        version = 1,
        capabilities = CAPS,
        GetVersion = function()
            local meta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
            return meta and meta(ID, "Version") or "?"
        end,
        GetAchievement = function(key) return Copy(FA.BY_KEY[key]) end,
        GetProgress = function(key)
            local a = FA.BY_KEY[key]
            if not a or not ns.Evaluate then return nil end
            local r = ns.Evaluate(a)
            return { current = r.current, required = r.required, percent = r.percent, remaining = r.remaining,
                     completed = r.completed, available = r.available, blocked = r.blocked,
                     reliability = r.reliability, recoverability = r.recoverability }
        end,
        IsEarned = function(key) return FA.Earned(key) and true or false end,
        GetCompletion = function(key) return ns.Completion and ns.Completion(key) or nil end,
        GetWatchList = function()
            local out = {}
            for key in pairs(FA.DB().watch or {}) do out[#out + 1] = key end
            table.sort(out)
            return out
        end,
        GetCounter = function(name)
            if name == "fished" then return tonumber(FA.DB().fished) or 0 end
            return nil
        end,
        IntroPending = function() return false end,
        GetOption = function(name)
            if name == "screenshot" or name == "toastY" then return FA.Settings()[name] end
            return nil
        end,
        GetToastFrame = function() return FA.GetToastFrame and FA.GetToastFrame() or nil end,
        GetRareKills = function()
            local out = {}
            for name, t in pairs(FA.DB().rares or {}) do out[name] = t end
            return out
        end,
        GetInstanceBosses = function(name)
            local out = {}
            if type(name) ~= "string" or name == "" then return out end
            for _, set in ipairs({ FA.DUNGEONS or {}, FA.RAIDS or {} }) do
                for _, dg in ipairs(set) do
                    if dg.name == name or name:find(dg.name, 1, true) or dg.name:find(name, 1, true) then
                        for _, b in ipairs(dg.bosses or {}) do out[#out + 1] = b[1] end
                    end
                end
            end
            return out
        end,
        GetBossName = function(npcID) return FA.BOSS_IDS and FA.BOSS_IDS[npcID] or nil end,
        TogglePinned = function(key)
            local a = FA.BY_KEY[key]
            if a and FA.ToggleTrack then FA.ToggleTrack(a) end
        end,
        GetCriteria = function(key)
            local a = FA.BY_KEY[key]
            if not (a and type(a.list) == "table" and type(a.has) == "function") then return nil end
            local out = {}
            for _, n in ipairs(a.list) do
                local ok, done = pcall(a.has, n)
                out[#out + 1] = { name = n, done = ok and done and true or false }
            end
            return out
        end,
        GetCritterInfo = function()
            if not critterInfo then
                local c, p, pn = {}, {}, {}
                for _, n in ipairs(FA.CRITTERS or {}) do c[#c + 1] = n end
                for id, n in pairs(FA.PESTS or {}) do p[id] = n end
                for n in pairs(FA.PEST_NAMES or {}) do pn[n] = true end
                critterInfo = { critters = c, pests = p, pestNames = pn }
            end
            return critterInfo
        end,
        CritterHere = function(name) return FA.CritterHere and FA.CritterHere(name) or false end,
        CritterNearest = function(names) return FA.CritterNearest and FA.CritterNearest(names) or nil end,
        CritterZones = function(name) return FA.CritterZones and FA.CritterZones(name) or {} end,
        GetPinned = function()
            local out = {}
            for key in pairs(FA.DB().tracked or {}) do out[#out + 1] = key end
            table.sort(out)
            return out
        end,
        GetRelevantForNPC = function(npcID)
            local out = {}
            local pest = FA.PESTS and FA.PESTS[npcID]
            if pest and not FA.Earned("pests") and not (FA.DB().pests or {})[pest] then
                out[#out + 1] = { key = "pests", name = FA.BY_KEY.pests and FA.BY_KEY.pests.name or "Pest Control", criterion = pest }
            end
            local boss = FA.BOSS_IDS and FA.BOSS_IDS[npcID]
            if boss and not (FA.DB().bosses or {})[npcID] then
                out[#out + 1] = { name = FA.BOSS_ACH and FA.BOSS_ACH[boss] or boss, criterion = boss }
            end
            return out
        end,
        -- What a unit is still needed for: { love = bool, pest = name or nil,
        -- boss = name or nil, rare = bool } (nil: nothing).
        NeededFor = function(npcID, name)
            local d = FA.DB()
            local out = {}
            local done = d.done or {}
            if name and not done.critters and not (d.critters or {})[name] then
                for _, n in ipairs(FA.CRITTERS or {}) do if n == name then out.love = true break end end
            end
            local pest = (npcID and FA.PESTS and FA.PESTS[npcID]) or (name and FA.PEST_NAMES and FA.PEST_NAMES[name] and name)
            if pest and not done.pests and not (d.pests or {})[pest] then out.pest = pest end
            local boss = (npcID and FA.BOSS_IDS and FA.BOSS_IDS[npcID]) or (name and FA.BOSS_BY_NAME and FA.BOSS_BY_NAME[name] and name)
            if boss and not (d.bosses or {})[npcID or 0] and not (d.bosses or {})[boss] then out.boss = boss end
            if next(out) then return out end
            return nil
        end,
        OpenAchievement = function(key)
            local a = FA.BY_KEY[key]
            if a and FA.OpenSearch then FA.OpenSearch(a.name) end
        end,
        RegisterCallback = function(event, fn)
            if type(event) ~= "string" or type(fn) ~= "function" then return end
            listeners[event] = listeners[event] or {}
            table.insert(listeners[event], fn)
        end,
    }
end

-- Fishing tells each catch (its API's callbacks): the fishing achievements
-- are looked at then (the loot window's close stays the way for older ones).
do
    local f = CreateFrame("Frame")
    f:RegisterEvent("PLAYER_LOGIN")
    f:SetScript("OnEvent", function()
        local api = ns.QF.API()
        if type(api) == "table" and type(api.capabilities) == "table" and api.capabilities.callbacks then
            local queued
            api.RegisterCallback("FISH_CAUGHT", function()
                if queued then return end
                queued = true
                C_Timer.After(0.5, function() queued = nil; if FA.CheckAll then FA.CheckAll() end end)
            end)
        end
    end)
end

