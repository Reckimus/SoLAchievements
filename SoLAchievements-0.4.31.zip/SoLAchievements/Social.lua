-------------------------------------------------------------------------------
--  Sharing: achievement links in chat, what other players with the addon have
--  earned, comparing, titles, guild announcements and the account overview.
-------------------------------------------------------------------------------
local _, ns = ...
local FA = ns.FA
local TAG, secret = FA.TAG, FA.secret
local PREFIX = "SoLAch"
local LINK_COLOR = "ff2ec4b6"

local function Settings() return FA.Settings() end

-- Forever characters have a surname, and the client keeps it where the realm
-- normally goes, so players are keyed and addressed by full name.
local function FullName(unit)
    if not unit or not UnitFullName then return end
    local name, surname = UnitFullName(unit)
    if not name or secret(name) then return end
    if surname and not secret(surname) and surname ~= "" then return name .. "-" .. surname end
    return name
end
FA.FullName = FullName

local function First(name) return name and name:match("^([^%-]+)") end
local function Key(name) return name end
-- "Tne-Pojajach" -> "Tne Pojajach", the way the game shows it.
local function Display(name) return name and (name:gsub("%-", " ")) end
-- This session's mark, sent with our hello and our ask: our own guild
-- message comes back to us under a name we cannot always match (the client
-- gives our realm, the chat gives our surname), the mark tells it is ours.
local NONCE = tostring(math.random(100000, 999999)) .. tostring(math.floor((GetTime() or 0) * 1000) % 100000)
local mySender -- how the chat writes our name, once learned from the mark
local function IsMe(name)
    return name == FullName("player") or name == UnitName("player") or (mySender ~= nil and name == mySender)
end

local frame = CreateFrame("Frame")
local handlers = {}
local function On(event, fn)
    if pcall(frame.RegisterEvent, frame, event) then handlers[event] = fn end
end
frame:SetScript("OnEvent", function(_, event, ...) handlers[event](...) end)

-------------------------------------------------------------------------------
--  Titles
-------------------------------------------------------------------------------
local TITLED = {}
for _, a in ipairs(FA.ALL) do if a.title then TITLED[#TITLED + 1] = a end end
local CLASS_TITLES = {}
for token, name in pairs({
    WARRIOR = "Warrior", PALADIN = "Paladin", HUNTER = "Hunter", ROGUE = "Rogue",
    PRIEST = "Priest", SHAMAN = "Shaman", MAGE = "Mage", WARLOCK = "Warlock", DRUID = "Druid",
    DEATHKNIGHT = "Death Knight", MONK = "Monk", DEMONHUNTER = "Demon Hunter", EVOKER = "Evoker",
}) do
    local key = "class_" .. token
    CLASS_TITLES[key] = { key = key, title = "%s the " .. name }
end

local function PlayerClassTitle()
    local _, class = UnitClass("player")
    if type(class) == "string" and not secret(class) then
        return CLASS_TITLES["class_" .. class]
    end
end

local function HasEarnedTitle(a)
    return FA.DB().done[a.key] and (not a.titleRequires or a.titleRequires())
end

local function GameTitleID(key)
    return type(key) == "string" and tonumber(key:match("^game_title_(%d+)$")) or nil
end

local function GameTitleFormat(id)
    if not (type(id) == "number" and not secret(id) and id > 0 and GetTitleName and GetNumTitles) then return end
    local count = GetNumTitles()
    if secret(count) or type(count) ~= "number" or id > count then return end
    local name = GetTitleName(id)
    if secret(name) or type(name) ~= "string" or name:find("[%c|]") or not name:find("%S") then return end
    local escaped = name:gsub("%%", "%%%%")
    if escaped:match("%s$") then return escaped .. "%s" end
    if escaped:match("^[%s,]") then return "%s" .. escaped end
    return "%s, " .. escaped
end

local function KnownGameTitle(id)
    if not (type(id) == "number" and not secret(id) and id > 0 and IsTitleKnown) then return end
    local known = IsTitleKnown(id)
    if not secret(known) and known then return GameTitleFormat(id) end
end

-- Titles this character can equip.
function FA.AvailableTitles()
    local out = {}
    local starter = PlayerClassTitle()
    if starter then out[#out + 1] = starter end
    for _, a in ipairs(TITLED) do
        if HasEarnedTitle(a) and FA.Available(a) then out[#out + 1] = a end
    end
    local count = GetNumTitles and GetNumTitles()
    if type(count) == "number" and not secret(count) and IsTitleKnown then
        for id = 1, count do
            local title = KnownGameTitle(id)
            if title then out[#out + 1] = { key = "game_title_" .. id, title = title, gameTitle = true } end
        end
    end
    return out
end

-- An explicit addon choice wins. Otherwise follow the equipped game title,
-- falling back to the class title.
function FA.CurrentTitle()
    local d = FA.DB()
    local starter = PlayerClassTitle()
    if d.title == "inForever" and starter then d.title = starter.key end
    if starter and d.title == starter.key then return starter.title, starter.key end
    local a = d.title and FA.BY_KEY[d.title]
    if a and a.title and HasEarnedTitle(a) then return a.title, a.key end
    if d.title == nil then
        local id = GetCurrentTitle and GetCurrentTitle()
        local title = KnownGameTitle(id)
        if title then return title, "game_title_" .. id end
        if starter then return starter.title, starter.key end
    end
end

-------------------------------------------------------------------------------
--  Links: "[ach:Name]" in chat turns into a clickable link
-------------------------------------------------------------------------------
local BY_NAME = {}
for _, a in ipairs(FA.ALL) do
    local k = a.name:lower()
    -- Name-only links from older builds use the first matching tier.
    BY_NAME[k] = BY_NAME[k] or a
end

local function CharacterStatus(key)
    local d = FA.DB()
    local stamp = d.done[key]
    if not stamp then return "0" end
    local meta = d.doneMeta and d.doneMeta[key]
    if meta and meta.exact == false then return "1" end
    return date("%Y%m%d", stamp)
end

local function StatusText(status)
    if status == "0" then return "Not earned" end
    if status == "1" then return "Previously earned" end
    local year, month, day = status:match("^(%d%d%d%d)(%d%d)(%d%d)$")
    if year and tonumber(month) >= 1 and tonumber(month) <= 12 and tonumber(day) >= 1 and tonumber(day) <= 31 then
        return ("Earned %s-%s-%s"):format(month, day, year)
    end
    return "Status unavailable"
end

local function PlayerName()
    return FullName("player") or UnitName("player")
end

local function ChatToken(a)
    return ("[ach:%s~%s~%s]"):format(a.name, a.key, CharacterStatus(a.key))
end

function FA.LINK.insert(box, a)
    local prefix = box:GetText():sub(1, box:GetCursorPosition())
    local separator = prefix:sub(-1) == "]" and " " or ""
    box:Insert(separator .. ChatToken(a))
end

FA.LINK.fn = function(a, sender, status)
    local payload = a.key
    if type(sender) == "string" and not secret(sender) then
        sender = sender:gsub("[%c|:%[%]]", "")
        if sender ~= "" then payload = ("%s:%s:%s"):format(payload, sender, status or "") end
    end
    return ("|c%s|Haddon:SoLAchievements:%s|h[%s]|h|r"):format(LINK_COLOR, payload, a.name)
end

local function FindByName(name)
    local lower = name:lower()
    if BY_NAME[lower] then return BY_NAME[lower] end
    for _, a in ipairs(FA.ALL) do
        if a.name:lower() == lower then
            BY_NAME[lower] = a
            return a
        end
    end
end

local function Filter(_, event, msg, sender, ...)
    if type(msg) ~= "string" or secret(msg) or not msg:find("[ach:", 1, true) then return false end
    local author = event == "CHAT_MSG_WHISPER_INFORM" and PlayerName() or sender
    local previousEnd
    local out = msg:gsub("()%[ach:([^%[%]]+)%]()", function(first, token, nextPosition)
        local name, key, status = token:match("^(.-)~([^~]+)~(%d+)$")
        local a = key and FA.BY_KEY[key]
        if not a or a.name:lower() ~= name:lower() then
            a, status = FindByName(name or token), nil
        end
        if not a then return end
        local separator = previousEnd == first and " " or ""
        previousEnd = nextPosition
        if type(author) == "string" and not secret(author) and IsMe(author) and not status then
            status = CharacterStatus(a.key)
        end
        return separator .. FA.LINK.fn(a, author, status)
    end)
    if out ~= msg then return false, out, sender, ... end
    return false
end

local addFilter = ChatFrame_AddMessageEventFilter or (ChatFrameUtil and ChatFrameUtil.AddMessageEventFilter)
if addFilter then
    for _, e in ipairs({ "CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_PARTY",
        "CHAT_MSG_PARTY_LEADER", "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER", "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM",
        "CHAT_MSG_CHANNEL", "CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER", "CHAT_MSG_EMOTE" }) do
        pcall(addFilter, e, Filter)
    end
end

-- Clicking a link: the achievement in the item tooltip; shift-click opens it.
local lastLink, lastLinkTime = nil, 0
local function OnLink(link)
    local payload = type(link) == "string" and not secret(link) and link:match("^addon:SoLAchievements:(.+)$")
    if not payload then return end
    local key, sender, status = payload:match("^([^:]+):([^:]+):(%d*)$")
    key = key or payload
    if payload == lastLink and GetTime() - lastLinkTime < 0.2 then return end
    lastLink, lastLinkTime = payload, GetTime()
    local a = FA.BY_KEY[key]
    if not a then return end
    if IsShiftKeyDown() then
        FA.OpenSearch(a.name)
        return
    end
    local r, g, b = FA.Kit.Accent()
    local C = FA.Kit.COLORS
    local tt = ItemRefTooltip
    tt:SetOwner(UIParent, "ANCHOR_PRESERVE")
    tt:ClearLines()
    -- The icon and the name; the points on the right, as on the card.
    local icon = a.icon or ns.ICONS[a.id] or 236376
    tt:AddDoubleLine(("|T%s:18:18:0:0:64:64:5:59:5:59|t %s"):format(tostring(icon), a.name),
        (a.pts and a.pts > 0) and tostring(a.pts) or "", 1, 1, 1, r, g, b)
    tt:AddLine(a.desc, C.dim[1], C.dim[2], C.dim[3], true)
    tt:AddLine(" ")
    local viewerStatus = CharacterStatus(a.key)
    if sender then
        sender = sender:gsub("[%c|]", "")
        tt:AddDoubleLine(Display(sender) .. " (linked)", StatusText(status), C.text[1], C.text[2], C.text[3], r, g, b)
    end
    tt:AddDoubleLine((Display(PlayerName()) or "Your character") .. " (you)", StatusText(viewerStatus),
        C.text[1], C.text[2], C.text[3], r, g, b)
    if viewerStatus == "0" then
        local r2 = ns.Evaluate(a)
        tt:AddDoubleLine("Your progress", r2.blocked and "not readable now" or ns.ProgressText(a, r2.current, r2.required),
            C.text[1], C.text[2], C.text[3], r, g, b)
        -- What is left of a list (the first few).
        if a.list and a.has then
            local shown, left = 0, 0
            for _, n in ipairs(a.list) do
                local ok, have = pcall(a.has, n)
                if ok and not have then
                    left = left + 1
                    if shown < 6 then
                        tt:AddLine("  ·  " .. n, C.dim[1], C.dim[2], C.dim[3])
                        shown = shown + 1
                    end
                end
            end
            if left > shown then tt:AddLine(("  +%d more"):format(left - shown), C.dim[1], C.dim[2], C.dim[3]) end
        end
    end
    tt:AddLine(" ")
    tt:AddLine("Shift-click the link: open it in SoLAchievements", 0.55, 0.55, 0.55, true)
    tt:Show()
end
ns.OnChatLink = OnLink -- (for the selftest and the tests)
if EventRegistry and EventRegistry.RegisterCallback then
    EventRegistry:RegisterCallback("SetItemRef", function(_, link) OnLink(link) end, "SoLAchievements")
end
if SetItemRef then hooksecurefunc("SetItemRef", function(link) OnLink(link) end) end

-------------------------------------------------------------------------------
--  Talking to other players with the addon (hidden addon messages)
-------------------------------------------------------------------------------
if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then C_ChatInfo.RegisterAddonMessagePrefix(PREFIX) end

local function Send(msg, channel, target)
    local sendAddon = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage
    if sendAddon then pcall(sendAddon, PREFIX, msg, channel, target) end
end

local function Broadcast(msg)
    if Settings().share == false then return end
    if IsInGuild() then Send(msg, "GUILD") end
    if LE_PARTY_CATEGORY_INSTANCE and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
        Send(msg, "INSTANCE_CHAT")
    elseif IsInRaid() then
        Send(msg, "RAID")
    elseif IsInGroup() then
        Send(msg, "PARTY")
    end
end

-- This addon's version, and a version as numbers ("0.4.10-alpha" -> 0, 4, 10).
local meta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
local MY_VERSION = (meta and meta("SoLAchievements", "Version")) or "0"
local function Parts(v)
    local out = {}
    for n in tostring(v or ""):gmatch("%d+") do out[#out + 1] = tonumber(n) if #out == 3 then break end end
    return out
end
-- true when a is newer than b.
local function Newer(a, b)
    local x, y = Parts(a), Parts(b)
    for i = 1, 3 do
        if (x[i] or 0) ~= (y[i] or 0) then return (x[i] or 0) > (y[i] or 0) end
    end
    return false
end
FA.VERSION, FA.NewerVersion = MY_VERSION, Newer

-- A newer version seen on another player: said once per session (and only
-- once per version), never more.
local toldVersion
local function NoteVersion(v, who)
    if type(v) ~= "string" or v == "" or #v > 20 or not v:match("^%d") then return end
    if Settings().versionNotice == false or not Newer(v, MY_VERSION) then return end
    local S = Settings()
    if toldVersion and not Newer(v, toldVersion) then return end
    toldVersion = v
    S.newestSeen = (S.newestSeen and Newer(S.newestSeen, v)) and S.newestSeen or v
    print(TAG .. (" a newer version is out: %s (you have %s; %s runs it)."):format(v, MY_VERSION, who or "someone"))
end

local function HelloMsg()
    local pts, n = FA.CharacterPoints()
    -- (the 5th field, the version: older versions read four and ignore it)
    return table.concat({ "HI", pts, n, FA.CurrentTitle() or "", MY_VERSION, NONCE }, "\t")
end

local peers = {}    -- [short name] = { pts, count, title, time }
local nearbyTitles = {}
local TITLE_REFRESH = 90
local titleRequestAt = 0
local titleReplyAt = 0
local answeredAsk   -- [name] = when we last answered their Ask
local answeredReq   -- [name] = when we last answered their compare request
FA.PEERS = peers

function FA.NearbyTitle(name)
    if IsMe(name) then return FA.CurrentTitle() end
    name = name:gsub(" ", "-")
    local entry = nearbyTitles[name]
    local peer = peers[name]
    if entry and entry.received and time() - entry.received < 2 * TITLE_REFRESH
        and (not peer or entry.received >= peer.time) then
        return entry.title
    end
    return peer and peer.title
end

function FA.RequestNearbyTitle(name)
    if Settings().nameplateTitles == false or IsMe(name) then return end
    name = name:gsub(" ", "-")
    local now = time()
    if now < titleRequestAt then return end
    local peer = peers[name]
    if peer and now - peer.time < TITLE_REFRESH then return end
    local entry = nearbyTitles[name]
    if entry and now - entry.requested < TITLE_REFRESH then return end
    for key, value in pairs(nearbyTitles) do
        if now - value.requested >= 2 * TITLE_REFRESH then nearbyTitles[key] = nil end
    end
    entry = entry or {}
    entry.requested = now
    nearbyTitles[name] = entry
    titleRequestAt = now + 1
    Send("TITLE_REQ", "WHISPER", name)
    return true
end
local replied = {}  -- answered their hello this session
local incoming = {} -- [sender] = keys while a compare answer arrives
local pendingCompare
local pendingRid    -- the request id of the compare asked (v2)

-- Exact "Name-Surname" first; a bare first name matches only when unambiguous.
function FA.Peer(name)
    if not name then return end
    if peers[name] then return peers[name] end
    if name:find("-", 1, true) then return end
    local found
    for key, p in pairs(peers) do
        if First(key) == name then
            if found then return end
            found = p
        end
    end
    return found
end

-- Protocol v2 (older versions read the first fields and ignore the rest):
--   REQ  <rid>                 a compare asked, with the asker's request id
--   DONE <keys> <rid> <i> <n>  chunk i of n of the answer
--   END  <rid> <n>             the answer's end and its chunk count
-- Limits: MAX_CHUNKS a answer, MAX_PER_10S messages from one sender (the
-- rest dropped), field lengths checked; what nobody asked for is dropped.
local MAX_CHUNKS, MAX_PER_10S, MAX_TITLE = 40, 60, 64
local inbound = {} -- [sender] = { t0, n }
local function Flooding(sender)
    local now = GetTime()
    local b = inbound[sender]
    if not b or now - b.t0 > 10 then b = { t0 = now, n = 0 }; inbound[sender] = b end
    b.n = b.n + 1
    return b.n > MAX_PER_10S
end

local function AnswerCompare(sender, rid)
    rid = (type(rid) == "string" and #rid <= 12 and rid) or ""
    local keys = {}
    for key in pairs(FA.DB().done) do keys[#keys + 1] = key end
    local chunk, chunks = {}, {}
    local size = 0
    for _, key in ipairs(keys) do
        if size + #key + 1 > 230 then
            chunks[#chunks + 1] = table.concat(chunk, ",")
            chunk, size = {}, 0
        end
        chunk[#chunk + 1] = key
        size = size + #key + 1
    end
    if #chunk > 0 then chunks[#chunks + 1] = table.concat(chunk, ",") end
    while #chunks > MAX_CHUNKS do table.remove(chunks) end
    local n = #chunks
    for i, c in ipairs(chunks) do
        C_Timer.After(i * 0.25, function() Send(("DONE\t%s\t%s\t%d\t%d"):format(c, rid, i, n), "WHISPER", sender) end)
    end
    C_Timer.After((n + 1) * 0.25, function() Send(("END\t%s\t%d"):format(rid, n), "WHISPER", sender) end)
end

On("CHAT_MSG_ADDON", function(prefix, msg, channel, sender)
    if prefix ~= PREFIX or type(msg) ~= "string" or secret(msg) or not sender or secret(sender) then return end
    if IsMe(sender) then return end
    if #msg > 255 or Flooding(sender) then return end
    local short = Key(sender)
    local kind, a1, a2, a3, a4, a5 = strsplit("\t", msg)
    -- Ours, back from the server: the name it came under is ours from now on.
    if (kind == "HI" and a5 == NONCE) or (kind == "ASK" and a1 == NONCE) then
        mySender = sender
        peers[short] = nil
        return
    end
    if kind == "TITLE_REQ" and channel == "WHISPER" then
        local now = time()
        if Settings().share ~= false and now >= titleReplyAt then
            titleReplyAt = now + 1
            local _, titleKey = FA.CurrentTitle()
            Send("TITLE\t" .. (titleKey or ""), "WHISPER", sender)
        end
    elseif kind == "TITLE" and channel == "WHISPER" then
        local entry = nearbyTitles[sender:gsub(" ", "-")]
        local now = time()
        if entry and now - entry.requested <= 15 then
            local reward = CLASS_TITLES[a1 or ""] or FA.BY_KEY[a1 or ""]
            entry.title = reward and reward.title or GameTitleFormat(GameTitleID(a1))
            entry.received = now
            if FA.RefreshNameplateTitles then FA.RefreshNameplateTitles() end
        end
    elseif kind == "HI" then
        peers[short] = { pts = tonumber(a1) or 0, count = tonumber(a2) or 0, title = (a3 and a3 ~= "" and #a3 <= MAX_TITLE and a3) or nil,
                         time = time(), version = a4 }
        local entry = nearbyTitles[sender:gsub(" ", "-")]
        if entry then entry.received = nil end
        NoteVersion(a4, Display(short))
        if FA.OnPeers then FA.OnPeers() end
        if FA.RefreshNameplateTitles then FA.RefreshNameplateTitles() end
        if channel ~= "WHISPER" and not replied[short] and Settings().share ~= false then
            replied[short] = true
            Send(HelloMsg(), "WHISPER", sender)
        end
    elseif kind == "ASK" then
        -- "Ask the guild": our hello back to them (not more than every 10 s each).
        if Settings().share ~= false then
            answeredAsk = answeredAsk or {}
            if (answeredAsk[short] or 0) + 10 < GetTime() then
                answeredAsk[short] = GetTime()
                Send(HelloMsg(), "WHISPER", sender)
            end
        end
    elseif kind == "EARN" then
        local a = FA.BY_KEY[a1 or ""]
        if a and Settings().showOthers ~= false then
            print(TAG .. " " .. Display(short) .. " earned " .. FA.LINK.fn(a, sender, a2 and a2:match("^%d+$") or "1"))
        end
        if peers[short] then peers[short].count = peers[short].count + 1 end
    elseif kind == "REQ" then
        -- (one answer per asker every 30 s: a compare is a few whispers)
        answeredReq = answeredReq or {}
        if Settings().share ~= false and (answeredReq[short] or 0) + 30 < GetTime() then
            answeredReq[short] = GetTime()
            AnswerCompare(sender, a1)
        end
    elseif kind == "DONE" then
        -- Only from the player being asked (pendingCompare), and bounded: what
        -- nobody asked for is dropped, and no answer grows past the known keys.
        local asked = pendingCompare and (pendingCompare == short or First(pendingCompare) == First(short))
        if not asked then return end
        -- (v2: another request's chunk is dropped)
        if a2 and a2 ~= "" and pendingRid and a2 ~= pendingRid then return end
        local box = incoming[short]
        if not (box and box.n) then box = { n = 0 }; incoming[short] = box end
        box.chunks = (box.chunks or 0) + 1
        if box.chunks > MAX_CHUNKS then return end
        for key in (a1 or ""):gmatch("[^,]+") do
            if box.n >= 4000 then break end
            if FA.BY_KEY[key] and not box[key] then box[key] = true; box.n = box.n + 1 end
        end
    elseif kind == "END" then
        -- The answer may come back with or without the surname.
        if pendingCompare and (pendingCompare == short or First(pendingCompare) == First(short)
            and not (pendingCompare:find("-", 1, true) and short:find("-", 1, true))) then
            if a1 and a1 ~= "" and pendingRid and a1 ~= pendingRid then return end
            pendingCompare, pendingRid = nil, nil
            local box = incoming[short] or {}
            local got, want = box.chunks or 0, tonumber(a2)
            box.n, box.chunks = nil, nil
            if want and got < want then
                print(TAG .. (" %s's answer came in part (%d of %d messages): the comparison may miss some."):format(Display(short), got, want))
            end
            FA.COMPARE.name, FA.COMPARE.done = Display(short), box
            FA.COMPARE.cachedAt = nil
            -- Kept for when they are offline (marked cached then).
            local acc = FA.Account()
            acc.compareCache = acc.compareCache or {}
            local keys = {}
            for k in pairs(box) do keys[#keys + 1] = k end
            acc.compareCache[short] = { t = time(), keys = keys }
            incoming[short] = nil
            local n = 0
            for _ in pairs(FA.COMPARE.done) do n = n + 1 end
            print(TAG .. (" comparing with %s (%d earned). /fach compare off to stop."):format(Display(short), n))
            FA.ShowTab(FA.DB().tab ~= "summary" and FA.DB().tab or "general")
        end
    end
end)

-- Ask another player with the addon for what they have earned.
function FA.RequestCompare(name)
    if not name or name == "" then
        if UnitIsPlayer("target") and not secret(UnitIsPlayer("target")) then name = FullName("target") end
    end
    if not name or name == "" or secret(name) then
        print(TAG .. " target a player or type /fach compare Name-Surname.")
        return
    end
    -- Typed as "Tne Pojajach": the whisper target needs "Tne-Pojajach".
    name = name:gsub("^%s+", ""):gsub("%s+$", ""):gsub("%s+", "-")
    pendingCompare = name
    pendingRid = tostring(math.random(100000, 999999))
    incoming[Key(name)] = {}
    Send("REQ\t" .. pendingRid, "WHISPER", name)
    print(TAG .. " asking " .. Display(name) .. " ...")
    C_Timer.After(6, function()
        if pendingCompare == name then
            pendingCompare = nil
            local cache = (FA.Account().compareCache or {})[Key(name)]
            if cache then
                local done = {}
                for _, k in ipairs(cache.keys or {}) do done[k] = true end
                FA.COMPARE.name, FA.COMPARE.done, FA.COMPARE.cachedAt = Display(name), done, cache.t
                print(TAG .. (" no answer from %s: comparing with what they had on %s (cached)."):format(Display(name), date("%m-%d-%Y", cache.t)))
                FA.Refresh()
            else
                print(TAG .. " no answer from " .. Display(name) .. ": they may not run SoLAchievements.")
            end
        end
    end)
end

function FA.StopCompare()
    FA.COMPARE.name, FA.COMPARE.done = nil, nil
    FA.Refresh()
end

FA.SLASH.compare = function(rest)
    if rest:lower() == "off" then
        FA.StopCompare()
        print(TAG .. " comparing stopped.")
    else
        FA.RequestCompare(rest)
    end
end

-- "Compare achievements" in the right-click menu of a player.
if Menu and Menu.ModifyMenu then
    for _, tag in ipairs({ "MENU_UNIT_PLAYER", "MENU_UNIT_PARTY", "MENU_UNIT_RAID_PLAYER", "MENU_UNIT_FRIEND",
        "MENU_UNIT_TARGET", "MENU_UNIT_GUILD" }) do
        pcall(Menu.ModifyMenu, tag, function(_, root, context)
            if not context then return end
            -- Unit menus (target, party, raid) know the surname via the unit.
            local name = context.unit and not secret(context.unit) and FullName(context.unit)
            if not name then
                name = context.name
                if not name or secret(name) then return end
                if context.server and not secret(context.server) and context.server ~= "" then
                    name = name .. "-" .. context.server
                end
            end
            if IsMe(name) then return end
            root:CreateDivider()
            root:CreateButton("Compare achievements", function() FA.RequestCompare(name) end)
        end)
    end
end

-------------------------------------------------------------------------------
--  Account overview: every character's points, for the Summary page
-------------------------------------------------------------------------------
local function SaveCharacter()
    local name, realm = UnitName("player"), GetRealmName()
    if not name or secret(name) then return end
    local pts, n = FA.CharacterPoints()
    local done, meta = {}, {}
    for k, v in pairs(FA.DB().done) do done[k] = v end
    for k, v in pairs(FA.DB().doneMeta or {}) do meta[k] = v end
    local _, class = UnitClass("player")
    FA.Account().chars[name .. "-" .. (realm or "")] = {
        name = name, realm = realm, class = class, level = UnitLevel("player"),
        pts = pts, count = n, last = time(), done = done, doneMeta = meta, title = FA.CurrentTitle(),
    }
end
FA.SaveCharacter = SaveCharacter

function FA.SetPlayerTitle(key)
    local gameTitle = GameTitleID(key)
    if gameTitle then
        if not (KnownGameTitle(gameTitle) and SetCurrentTitle and pcall(SetCurrentTitle, gameTitle)) then return end
        -- Follow the game selection after explicitly choosing a native title.
        FA.DB().title = nil
    else
        -- Store an explicit opt-out separately from an untouched character.
        FA.DB().title = key or false
    end
    if FA.RefreshCharacterTitle then FA.RefreshCharacterTitle() end
    SaveCharacter()
    Broadcast(HelloMsg())
    if FA.RefreshNameplateTitles then FA.RefreshNameplateTitles() end
end

local lastGameTitleKey
local function RefreshGameTitle(unit, titlesChanged)
    if secret(unit) or unit ~= "player" then return end
    if FA.DB().title == nil then
        local _, key = FA.CurrentTitle()
        if key ~= lastGameTitleKey then
            lastGameTitleKey = key
            if FA.RefreshCharacterTitle then FA.RefreshCharacterTitle() end
            SaveCharacter()
            Broadcast(HelloMsg())
            if FA.RefreshNameplateTitles then FA.RefreshNameplateTitles() end
            titlesChanged = true
        end
    end
    if titlesChanged then FA.Refresh() end
end
On("UNIT_NAME_UPDATE", function(unit) RefreshGameTitle(unit) end)
On("KNOWN_TITLES_UPDATE", function(unit)
    RefreshGameTitle(unit, true)
end)

-------------------------------------------------------------------------------
--  Earning: tell the guild and group, keep the overview current
-------------------------------------------------------------------------------
local sendChat = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
table.insert(FA.EARN_HOOKS, function(a)
    SaveCharacter()
    Broadcast("EARN\t" .. a.key .. "\t" .. CharacterStatus(a.key))
    if Settings().announce and IsInGuild() and not a.native then
        pcall(sendChat, "earned the achievement " .. ChatToken(a) .. "!", "GUILD")
    end
end)

On("PLAYER_LOGIN", function()
    C_Timer.After(12, function()
        SaveCharacter()
        Broadcast(HelloMsg())
    end)
end)
On("GROUP_JOINED", function() C_Timer.After(3, function() Broadcast(HelloMsg()) end) end)
On("PLAYER_LOGOUT", SaveCharacter)

-------------------------------------------------------------------------------
--  Guild: everyone with the addon who answered (Ask the guild, or their
--  hello at login or on joining a group), by points. Click a name to compare.
-------------------------------------------------------------------------------
function FA.AskGuild()
    if not IsInGuild() then print(TAG .. " you are not in a guild.") return end
    if Settings().share == false then print(TAG .. " sharing is off (Settings): turn it on to ask the guild.") return end
    Send("ASK\t" .. NONCE, "GUILD")
    print(TAG .. " asked the guild: the answers come in over a few seconds.")
end

local function Ago(t)
    local s = time() - (t or 0)
    if s < 120 then return "just now" end
    if s < 3600 then return math.floor(s / 60) .. " min ago" end
    if s < 86400 then return math.floor(s / 3600) .. "h ago" end
    return math.floor(s / 86400) .. "d ago"
end

FA.VIEWS.guild = function(child, width)
    local Kit = FA.Kit
    local W = Kit.W
    local C = Kit.COLORS
    local r, g, b = Kit.Accent()
    local y = 0
    local _, h = W:SectionHeader(child, "GUILD", y)
    y = y - h
    _, h = W:WideDualButton(child, "Ask the guild", "Stop comparing", y,
        function() FA.AskGuild() end,
        function() if FA.StopCompare then FA.StopCompare() end end)
    y = y - h - 6
    -- Comparing: you, them, both.
    if FA.COMPARE.name and FA.COMPARE.done then
        local mine, theirs, both = 0, 0, 0
        for _, a in ipairs(FA.ALL) do
            local me, them = FA.DB().done[a.key] and true or false, FA.COMPARE.done[a.key] and true or false
            if me and them then both = both + 1 elseif me then mine = mine + 1 elseif them then theirs = theirs + 1 end
        end
        local line = Kit.MakeFont(child, 12, nil, C.text[1], C.text[2], C.text[3], 1)
        line:SetPoint("TOPLEFT", 20, y)
        line:SetWidth(width - 40)
        line:SetJustifyH("LEFT")
        line:SetWordWrap(true)
        line:SetText(("Comparing with %s%s:  only you %d  ·  only them %d  ·  both %d"):format(FA.COMPARE.name,
            FA.COMPARE.cachedAt and (" (cached " .. date("%m-%d-%Y", FA.COMPARE.cachedAt) .. ")") or "", mine, theirs, both))
        y = y - line:GetStringHeight() - 12
    end
    -- Me first in the list too, for the ranking.
    local me = FullName("player") or UnitName("player")
    local pts, n = FA.CharacterPoints()
    local list = { { name = me, pts = pts, count = n, title = FA.CurrentTitle(), time = time(), me = true } }
    for name, p in pairs(peers) do
        list[#list + 1] = { name = name, pts = p.pts or 0, count = p.count or 0, title = p.title, time = p.time }
    end
    table.sort(list, function(x, y2)
        if x.pts ~= y2.pts then return x.pts > y2.pts end
        return x.name < y2.name
    end)
    for i, p in ipairs(list) do
        local row = CreateFrame("Button", nil, child)
        row:SetSize(width - 40, 30)
        row:SetPoint("TOPLEFT", 20, y)
        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(C.card[1], C.card[2], C.card[3], C.card[4])
        if p.me then
            local edge = row:CreateTexture(nil, "ARTWORK")
            edge:SetPoint("TOPLEFT")
            edge:SetPoint("BOTTOMLEFT")
            edge:SetWidth(2)
            edge:SetColorTexture(r, g, b, 1)
        end
        local rank = Kit.MakeFont(row, 12, nil, C.dim[1], C.dim[2], C.dim[3], 1)
        rank:SetPoint("LEFT", 10, 0)
        rank:SetText("#" .. i)
        local name = Kit.MakeFont(row, 13, nil, 1, 1, 1, 1)
        name:SetPoint("LEFT", 50, 0)
        local shown = Display(p.name)
        if p.title and p.title:find("%s", 1, true) then shown = p.title:format(shown) end
        name:SetText(shown .. (p.me and "  |cff888888(you)|r" or ""))
        local right = Kit.MakeFont(row, 12, nil, C.dim[1], C.dim[2], C.dim[3], 1)
        right:SetPoint("RIGHT", -12, 0)
        right:SetText(("|cffffffff%d|r pts  ·  %d earned  ·  %s"):format(p.pts, p.count, p.me and "now" or Ago(p.time)))
        name:SetPoint("RIGHT", right, "LEFT", -10, 0)
        name:SetJustifyH("LEFT")
        name:SetWordWrap(false)
        if not p.me then
            row:SetScript("OnEnter", function() bg:SetColorTexture(C.cardHover[1], C.cardHover[2], C.cardHover[3], C.cardHover[4]) end)
            row:SetScript("OnLeave", function() bg:SetColorTexture(C.card[1], C.card[2], C.card[3], C.card[4]) end)
            row:SetScript("OnClick", function() FA.RequestCompare(p.name) end)
        end
        y = y - 36
    end
    if #list == 1 then
        local note = Kit.MakeFont(child, 12, nil, 1, 1, 1, 0.45)
        note:SetPoint("TOPLEFT", 20, y - 4)
        note:SetWidth(width - 40)
        note:SetJustifyH("LEFT")
        note:SetWordWrap(true)
        note:SetText("No guildmates have replied yet. Click Ask the guild to check for players using SoLAchievements.")
        y = y - 8 - note:GetStringHeight()
    end
    return -y + 10
end
-- New answers while the Guild tab is open: drawn again (once a second at most).
do
    local queued
    FA.OnPeers = function()
        if queued or FA.DB().tab ~= "statistics" or FA.DB().statTab ~= "guild" then return end
        queued = true
        C_Timer.After(1, function() queued = nil; FA.Refresh() end)
    end
end
