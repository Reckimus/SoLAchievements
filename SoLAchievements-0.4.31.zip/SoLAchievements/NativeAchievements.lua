-- Mirror the catalogue the client actually exposes, including its subcategories.
local _, ns = ...
local FAC = ns.Split_SoLAchievements
local mapped, sections, listed = {}, {}, {}
local nativeSections = FAC.CATEGORY_SECTIONS.native

local function Plain(value)
    return not (issecretvalue and issecretvalue(value))
end

local function Criteria(id)
    local items = {}
    if not (GetAchievementNumCriteria and GetAchievementCriteriaInfo) then return items end
    local ok, count = pcall(GetAchievementNumCriteria, id)
    if not ok or not Plain(count) or type(count) ~= "number" then return items end
    for i = 1, count do
        local read, label, _, done = pcall(GetAchievementCriteriaInfo, id, i)
        if read and Plain(label) and Plain(done) and type(label) == "string" and label ~= "" then
            items[#items + 1] = { label, done == true }
        end
    end
    return items
end

local function Sync(a, done, month, day, year)
    local db = FAC.DB()
    if not done or db.done[a.key] then return end
    local stamp
    if type(month) == "number" and type(day) == "number" and type(year) == "number" then
        local ok, result = pcall(time, { year = year < 100 and year + 2000 or year, month = month, day = day, hour = 12 })
        if ok then stamp = result end
    end
    db.done[a.key] = stamp or time()
    ns.NoteEarned(a.key, "native", stamp ~= nil)
    db.tracked[a.key] = nil
    ns.earnedSinceView = true
end

local function Ingest(id, name, points, done, month, day, year, desc, icon, title)
    if not (Plain(id) and Plain(name) and Plain(done) and type(id) == "number" and type(name) == "string" and name ~= "") then return end
    local a = mapped[id]
    if not a then
        local nativeID = id
        a = { key = "blizz" .. id, id = id, nativeID = id, native = true, name = name,
            desc = Plain(desc) and type(desc) == "string" and desc or "",
            pts = Plain(points) and type(points) == "number" and math.max(0, points) or 0,
            icon = Plain(icon) and icon or nil }
        a.dynamicList = function() return Criteria(nativeID) end
        a.progress = function()
            if FAC.DB().done[a.key] then return 1, 1 end
            local rows, completed = Criteria(nativeID), 0
            for _, row in ipairs(rows) do if row[2] then completed = completed + 1 end end
            return completed, math.max(1, #rows)
        end
        mapped[id] = a
        table.insert(FAC.ALL, a)
        if ns.FA then ns.FA.BY_KEY[a.key] = a end
    end
    if not listed[a.key] then
        local section = sections[title]
        if not section then
            section = { title = title, list = {} }
            sections[title] = section
            table.insert(nativeSections, section)
        end
        table.insert(section.list, a)
        listed[a.key] = true
    end
    Sync(a, done == true, Plain(month) and month, Plain(day) and day, Plain(year) and year)
end

local function CategoryTitle(id)
    if not GetCategoryInfo then return "Game Achievements" end
    local ok, title, parent = pcall(GetCategoryInfo, id)
    if not ok or not Plain(title) or type(title) ~= "string" or title == "" then return "Game Achievements" end
    if Plain(parent) and type(parent) == "number" and parent > 0 and parent ~= id then
        local read, top = pcall(GetCategoryInfo, parent)
        if read and Plain(top) and type(top) == "string" and top ~= title then return top .. " — " .. title end
    end
    return title
end

local function RefreshCatalog()
    if not (GetCategoryList and GetCategoryNumAchievements and GetAchievementInfo) then return end
    local ok, categories = pcall(GetCategoryList)
    if not ok or not Plain(categories) or type(categories) ~= "table" then return end
    -- Existing client-backed entries retain their original keys and progress.
    for _, a in ipairs(FAC.ALL) do
        if a.nativeIDs then
            for _, id in ipairs(a.nativeIDs) do mapped[id] = mapped[id] or a end
        end
    end
    for _, category in ipairs(categories) do
        if Plain(category) and type(category) == "number" then
            local read, count = pcall(GetCategoryNumAchievements, category, true)
            if read and Plain(count) and type(count) == "number" then
                local title = CategoryTitle(category)
                for i = 1, count do
                    local info, id, name, points, done, month, day, year, desc, _, icon =
                        pcall(GetAchievementInfo, category, i)
                    if info then Ingest(id, name, points, done, month, day, year, desc, icon, title) end
                end
            end
        end
    end
    if FAC.RefreshWindow then FAC.RefreshWindow() end
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
pcall(events.RegisterEvent, events, "ACHIEVEMENT_EARNED")
events:SetScript("OnEvent", function(_, event, id)
    if event == "PLAYER_LOGIN" then
        RefreshCatalog()
        -- Some clients populate the catalogue after entering the world.
        C_Timer.After(3, RefreshCatalog)
    elseif Plain(id) and type(id) == "number" then
        local a = mapped[id]
        if not a then RefreshCatalog(); a = mapped[id] end
        if a and GetAchievementInfo then
            local ok, _, _, _, done, month, day, year = pcall(GetAchievementInfo, id)
            if ok and Plain(done) and done == true then
                Sync(a, true, Plain(month) and month, Plain(day) and day, Plain(year) and year)
            end
        end
        FAC.CheckAll()
        -- Blizzard receives the same event and plays its own alert.
    end
end)
