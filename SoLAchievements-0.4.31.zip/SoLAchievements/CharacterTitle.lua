local _, ns = ...
local FA = ns.FA
local hookedFrame

local function Apply(frame)
    if FA.Settings().characterPaneTitle == false then return end
    if frame.activeSubframe and frame.activeSubframe ~= "PaperDollFrame" then return end
    if not PaperDollFrame or not PaperDollFrame:IsShown() then return end
    local title = FA.CurrentTitle()
    local name = title and (FA.FullName("player") or UnitName("player"))
    if name and not FA.secret(name) then
        frame:SetTitle(title:format((name:gsub("-", " "))))
    end
end

local events = CreateFrame("Frame")
local function Attach()
    local frame = CharacterFrame
    if not frame or type(frame.UpdateTitle) ~= "function" or type(frame.SetTitle) ~= "function" then return end
    if hookedFrame ~= frame then
        hooksecurefunc(frame, "UpdateTitle", Apply)
        hookedFrame = frame
    end
    events:UnregisterAllEvents()
    return frame
end

function FA.RefreshCharacterTitle()
    local frame = Attach()
    if frame and frame:IsShown() then frame:UpdateTitle() end
end

events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", FA.RefreshCharacterTitle)
FA.RefreshCharacterTitle()
