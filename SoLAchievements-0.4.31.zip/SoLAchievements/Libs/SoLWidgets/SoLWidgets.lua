-- Widget library adapted for SoLAchievements by StepOnLegos.
-- See LICENSE and PROVENANCE.txt in the addon folder.
local MAJOR, MINOR = "SoLAchievementsWidgets-1.0", 23
local Lib = LibStub and LibStub:NewLibrary(MAJOR, MINOR)
if not Lib then return end
Lib.MINOR = MINOR

-- This copy's own folder: the kit's pictures (corners, glyphs) are read
-- from the addon whose copy is the one running.
local ADDON = ...
Lib.MEDIA = "Interface\\AddOns\\" .. tostring(ADDON) .. "\\Libs\\SoLWidgets\\Media\\"
Lib.kits = Lib.kits or {}

-------------------------------------------------------------------------------
--  The game's tooltip over the kits' windows: in the look of the window's
--  kit (its background, the outer line) and at the window's scale, back to
--  the game's own when it hides. One hook for every kit (Lib.tipWins: a
--  window name -> its kit), so two addons never undo each other.
-------------------------------------------------------------------------------
Lib.tipWins = Lib.tipWins or {}
Lib.tipFonts = Lib.tipFonts or {} -- a window name -> fn() -> title size, text size (its own text sizes)
local function TipWindow(frame)
    local depth = 0
    while frame and depth < 14 do
        local name = frame.GetName and frame:GetName()
        if name and Lib.tipWins[name] then return frame, Lib.tipWins[name] end
        frame = frame.GetParent and frame:GetParent()
        depth = depth + 1
    end
end
function Lib.HookTooltip()
    if Lib.tipHooked or not GameTooltip then return end
    Lib.tipHooked = true
    local tt = GameTooltip
    local st = {}
    -- The lines back in the game's own fonts (after a window's own sizes).
    local function GameFonts()
        if not st.fonts then return end
        st.fonts = nil
        for i = 1, tt:NumLines() do
            local l, r = _G["GameTooltipTextLeft" .. i], _G["GameTooltipTextRight" .. i]
            if l and GameTooltipHeaderText and GameTooltipText then l:SetFontObject(i == 1 and GameTooltipHeaderText or GameTooltipText) end
            if r and GameTooltipText then r:SetFontObject(GameTooltipText) end
        end
    end
    local function Off()
        if st.skin then st.skin:Hide() end
        if tt.NineSlice then tt.NineSlice:SetAlpha(1) end
        if st.scale then tt:SetScale(st.scale); st.scale = nil end
        GameFonts()
    end
    tt:HookScript("OnShow", function(self)
        local okO, owner = pcall(self.GetOwner, self)
        local win, kit = TipWindow(okO and owner or nil)
        if not win then Off() return end
        local C = kit.COLORS
        if not st.skin then
            st.skin = CreateFrame("Frame", nil, tt)
            st.skin:SetAllPoints()
            st.skin.bg = st.skin:CreateTexture(nil, "BACKGROUND")
            st.skin.bg:SetAllPoints()
            st.skin.edge = kit.MakeBorder(st.skin, unpack(kit.EDGE))
        end
        st.skin:SetFrameLevel(math.max(0, tt:GetFrameLevel() - 1))
        st.skin.bg:SetColorTexture(C.bg[1], C.bg[2], C.bg[3], kit.BgAlpha and kit.BgAlpha(0.97) or 0.97)
        st.skin.edge:SetColor(kit.EDGE[1], kit.EDGE[2], kit.EDGE[3], kit.EDGE[4] or 1)
        st.skin:Show()
        if tt.NineSlice then tt.NineSlice:SetAlpha(0) end
        -- The window's size: its effective scale for the tooltip too.
        local pe = (tt:GetParent() or UIParent):GetEffectiveScale()
        local want = pe > 0 and (win:GetEffectiveScale() / pe) or 1
        -- (Times the kit's own tooltip size, when the addon sets one.)
        local extra = (type(kit.TipScale) == "function" and kit.TipScale()) or kit.tipScale or 1
        want = want * (tonumber(extra) or 1)
        if not st.scale then st.scale = tt:GetScale() end
        if math.abs(tt:GetScale() - want) > 0.001 then tt:SetScale(want) end
        -- A window with text sizes of its own (a HUD): the tooltip's lines in
        -- them too, the title as its title, the rest as its rows.
        local fontsFor = Lib.tipFonts[win:GetName() or ""]
        if fontsFor then
            local okF, titleSize, textSize = pcall(fontsFor)
            if okF and titleSize and textSize then
                local font = kit.FONT or STANDARD_TEXT_FONT
                for i = 1, tt:NumLines() do
                    local l, r = _G["GameTooltipTextLeft" .. i], _G["GameTooltipTextRight" .. i]
                    if l then l:SetFont(font, i == 1 and titleSize or textSize, "") end
                    if r then r:SetFont(font, textSize, "") end
                end
                st.fonts = true
                if not st.relayout then
                    st.relayout = true
                    tt:Show() -- (the size again, for the new fonts)
                    st.relayout = false
                end
            end
        elseif st.fonts then
            GameFonts()
        end
        if st.skin.edge.Align then C_Timer.After(0, function() st.skin.edge:Align() end) end
    end)
    tt:HookScript("OnHide", Off)
end

local function Build(owner)
local MEDIA = Lib.MEDIA
local FONT = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local FONT_BOLD = FONT

local C = {
    bg = { 0.047, 0.075, 0.106, 0.97 },
    card = { 0.078, 0.122, 0.168, 0.92 },
    cardHover = { 0.098, 0.150, 0.205, 0.95 },
    edge = { 1, 1, 1, 0.07 },
    accent = { 0.18, 0.77, 0.71 },
    text = { 0.93, 0.95, 0.97 },
    dim = { 0.62, 0.68, 0.74 },
}

local ROW_H, GAP, PAD = 44, 6, 20

local Kit = { FONT = FONT, style = "alpha", COLORS = C, owner = owner, lib = Lib, version = MINOR }
Kit.ROW_H, Kit.GAP, Kit.PAD = ROW_H, GAP, PAD

function Kit.Accent() return C.accent[1], C.accent[2], C.accent[3] end

-- The kit's font (the addon's UI font choice): text made after this uses
-- it; text already made keeps its font until it is made again (/reload).
-- A file that does not load leaves the game's font.
local GAME_FONT, fontProbe = FONT, nil
function Kit.SetFont(path)
    local ok = false
    if path and path ~= GAME_FONT then
        fontProbe = fontProbe or UIParent:CreateFontString(nil, "OVERLAY")
        fontProbe:Hide()
        local fine, res = pcall(fontProbe.SetFont, fontProbe, path, 12, "")
        ok = fine and res ~= false
    end
    FONT = ok and path or GAME_FONT
    FONT_BOLD = FONT
    Kit.FONT = FONT
    return ok
end

-- The text's outline and shadow (Appearance > Fonts), for text made after
-- they are set (at login): a font given its own outline keeps it.
Kit.fontOutline = ""
Kit.fontShadow = false
Kit.accentTitles = false -- windows' titles in the accent (Appearance > Theme)
function Kit.MakeFont(parent, size, flags, r, g, b, a)
    local fs = parent:CreateFontString(nil, "OVERLAY")
    if (flags == nil or flags == "") and Kit.fontOutline ~= "" then flags = Kit.fontOutline end
    fs:SetFont((size and size >= 15) and FONT_BOLD or FONT, size or 13, flags or "")
    if Kit.fontShadow then
        fs:SetShadowColor(0, 0, 0, 1)
        fs:SetShadowOffset(1, -1)
    end
    if r then fs:SetTextColor(r, g, b, a or 1) end
    return fs
end

-- Text sizes by role (Settings > Text Size): each kind of text keeps its
-- own sizes, moved up or down together by the role's step. The kit's roles
-- (an addon adds its own with the same calls):
Kit.FONT_ROLES = {
    { key = "title", label = "Window title", size = 20 },
    { key = "tab", label = "Tabs", size = 13 },
    { key = "header", label = "Section headers", size = 15 },
    { key = "label", label = "Option names", size = 13 },
    { key = "control", label = "Values and lists", size = 12 },
    { key = "button", label = "Buttons", size = 13 },
    { key = "wizHead", label = "Setup step titles", size = 18 },
    { key = "wizText", label = "Setup text", size = 12 },
    { key = "wizCard", label = "Setup choices", size = 15 },
}
Kit.fontDelta = {}                                  -- [role] = steps from its default
local roleFonts = setmetatable({}, { __mode = "k" }) -- [font string] = { role, base, flags }
function Kit.RoleSize(role, base)
    return math.max(6, (base or 12) + (role and Kit.fontDelta[role] or 0))
end
-- A font string of a role: its size follows the role's setting, now and
-- later (Kit.RefreshFonts).
function Kit.RoleFont(parent, role, base, flags, r, g, b, a)
    local fs = Kit.MakeFont(parent, Kit.RoleSize(role, base), flags, r, g, b, a)
    roleFonts[fs] = { role, base or 13, flags }
    return fs
end
-- The size picked for a role (nil: its default).
function Kit.SetFontSize(role, size, default)
    size, default = tonumber(size), tonumber(default)
    Kit.fontDelta[role] = (size and default) and (size - default) or nil
end
-- Every role's text again at its size (text already on screen).
function Kit.RefreshFonts()
    for fs, info in pairs(roleFonts) do
        local size = Kit.RoleSize(info[1], info[2])
        local flags = info[3]
        if (flags == nil or flags == "") and Kit.fontOutline ~= "" then flags = Kit.fontOutline end
        pcall(fs.SetFont, fs, size >= 15 and FONT_BOLD or FONT, size, flags or "")
    end
end

-- One physical screen pixel in the frame's own units. A 1-unit line is 1.3 or
-- 1.4 pixels at most UI scales, so it rounds to 1 or 2 pixels depending on
-- where it lands; one real pixel is the same width everywhere.
function Kit.PixelSize(frame)
    local scale = frame:GetEffectiveScale()
    if not scale or scale <= 0 then return 1 end
    -- Exactly one screen pixel in this frame's units. (Not the client's
    -- GetNearestPixelSize(1, ...): it rounds a UI unit to whole pixels, so
    -- at a UI scale where one unit is 1.5 pixels or more it gave 2 pixels:
    -- lines of uneven width, and edges that missed the pixel grid and
    -- dropped out. A pixel-perfect UI scale hid it.)
    local factor = PixelUtil and PixelUtil.GetPixelToUIUnitFactor and PixelUtil.GetPixelToUIUnitFactor()
    if not factor or factor <= 0 then
        local _, height = GetPhysicalScreenSize()
        if not height or height <= 0 then return 1 end
        factor = 768 / height
    end
    return factor / scale
end

-- The scale that makes one UI unit one screen pixel (768 / screen height):
-- a window of the kit at that scale looks the same with or without a
-- pixel-perfect interface scale.
function Kit.PixelScale()
    local factor = PixelUtil and PixelUtil.GetPixelToUIUnitFactor and PixelUtil.GetPixelToUIUnitFactor()
    if not factor or factor <= 0 then
        local _, height = GetPhysicalScreenSize()
        factor = (height and height > 0) and (768 / height) or 1
    end
    return factor
end

-- Thin lines must land on whole pixels: by default the client smooths a
-- texture that sits between two pixels, which shows as a line that is
-- thicker and fainter on some sides.
-- The outer line of windows, tooltips, dialogs and panels: solid grey,
-- one pixel, as the nameplates' lines.
Kit.EDGE = { 0.38, 0.38, 0.38, 1 }

function Kit.Snap(tex)
    if tex.SetSnapToPixelGrid then tex:SetSnapToPixelGrid(true) end
    if tex.SetTexelSnappingBias then tex:SetTexelSnappingBias(0) end
    return tex
end

-- For textures the kit puts on whole pixels itself: the client's own
-- snapping off (a 1 px line placed a hair short of a pixel had both sides
-- rounded to the same pixel and vanished).
function Kit.NoSnap(tex)
    if tex.SetSnapToPixelGrid then tex:SetSnapToPixelGrid(false) end
    if tex.SetTexelSnappingBias then tex:SetTexelSnappingBias(0) end
    return tex
end

-- A window's top left corner on a whole screen pixel: inside a frame that
-- sits between two pixels, a 1 px line can drop out.
function Kit.SnapFrame(f)
    local px = Kit.PixelSize(f)
    local L, T = f:GetLeft(), f:GetTop()
    if not (L and T and px > 0) then return end
    if issecretvalue and (issecretvalue(L) or issecretvalue(T)) then return end
    local p = f:GetParent() or UIParent
    if p ~= UIParent then return end -- (only free windows; children follow them)
    f:ClearAllPoints()
    f:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", math.floor(L / px + 0.5) * px, math.floor(T / px + 0.5) * px)
end

-- Bordered frames, so their edges can be put back on whole pixels after the
-- frame moves (scrolling, dragging). Hidden ones drop out and come back with
-- their OnShow.
local bordered = {}
-- Every border ever made (hidden ones too), so a new look reaches them all.
local allBorders = setmetatable({}, { __mode = "k" })

-------------------------------------------------------------------------------
--  The look the options pick (the addon sets it from its saved settings with
--  Kit.SetLook): the lines' thickness in screen pixels, sharp or rounded
--  corners, and the backgrounds' opacity as a share of each one's own. The
--  defaults are the plain look: 1 px lines, sharp corners, full opacity.
-------------------------------------------------------------------------------
Kit.look = { thickness = 1, corners = "sharp", bgAlpha = 1 }
local CORNERS = MEDIA .. "corner_"

-- A background's alpha under the chosen opacity (base: its own, 0.97 when
-- not given).
function Kit.BgAlpha(base)
    return (base or 0.97) * (Kit.look.bgAlpha or 1)
end

-- The border lines' width in a frame's own units (whole screen pixels).
function Kit.LineWidth(frame)
    return Kit.PixelSize(frame) * math.max(1, math.min(3, math.floor((Kit.look.thickness or 1) + 0.5)))
end

-- Backgrounds the kit paints, kept so a new opacity reaches them at once.
local backgrounds = setmetatable({}, { __mode = "k" })

-- A background in a palette colour (C.bg, C.card...) at the chosen opacity.
-- base: its own alpha (the colour's fourth value when not given).
function Kit.PaintBg(tex, color, base)
    local e = backgrounds[tex]
    if not e then
        e = {}
        backgrounds[tex] = e
    end
    e.color, e.base = color, base
    tex:SetColorTexture(color[1], color[2], color[3], Kit.BgAlpha(base or color[4] or 1))
end

local function SameColor(c, r, g, b, a)
    return math.abs(c[1] - r) < 0.003 and math.abs(c[2] - g) < 0.003 and math.abs(c[3] - b) < 0.003
        and math.abs((c[4] or 1) - (a or 1)) < 0.003
end

-- The corner radius a frame gets, in screen pixels: none when the corners
-- are sharp or the frame is small (a check box would turn into a circle),
-- 4 for buttons and rows, 8 for panels and windows.
local function CornerRadius(edges, frame, px)
    if Kit.look.corners ~= "round" or edges.noRound then return 0 end
    local ok, w, h = pcall(function() return frame:GetWidth(), frame:GetHeight() end)
    if not ok or not w or not h then return 0 end
    if issecretvalue and (issecretvalue(w) or issecretvalue(h)) then return 0 end
    local side = math.min(w, h) / px
    if side >= 40 then return 8 end
    if side >= 20 then return 4 end
    return 0
end

-- Where each corner piece sits and how its top-left picture is turned.
local CORNER_POINTS = {
    { "TOPLEFT", 1, -1, 0, 1, 0, 1 },
    { "TOPRIGHT", -1, -1, 1, 0, 0, 1 },
    { "BOTTOMLEFT", 1, 1, 0, 1, 1, 0 },
    { "BOTTOMRIGHT", -1, 1, 1, 0, 1, 0 },
}

-------------------------------------------------------------------------------
--  Rounded backgrounds: the client allows few masks per texture (three, and
--  a texture may have some already), so a rounded fill is drawn as pieces
--  instead: a centre, a strip down each side between the corners and four
--  filled quarter discs, all in the fill's colour. The fill itself goes to
--  alpha 0 while they stand in for it; its colour, alpha and shown state are
--  followed (hooked), so modules paint it as before. Sharp corners: the
--  pieces hidden and the fill as it was.
-------------------------------------------------------------------------------
local fills = setmetatable({}, { __mode = "k" })
-- Colours given to RoundFill, kept until the corners first turn round.
local givenColor = setmetatable({}, { __mode = "k" })

local function PieceAlpha(st)
    for _, p in ipairs(st.pieces) do p:SetAlpha(st.alpha) end
end

local function PaintPieces(st)
    local c = st.color
    for i = 1, 3 do st.pieces[i]:SetColorTexture(c[1], c[2], c[3], c[4]) end
    for i = 4, 7 do st.pieces[i]:SetVertexColor(c[1], c[2], c[3], c[4]) end
end

local function ShowPieces(st, tex)
    local on = st.on and tex:IsShown()
    for _, p in ipairs(st.pieces) do p:SetShown(on and true or false) end
end

-- The fill's own alpha set while the pieces stand in for it (no hook loop).
local function FillAlpha(st, tex, a)
    st.busy = true
    tex:SetAlpha(a)
    st.busy = false
end

local function FillState(tex)
    local st = fills[tex]
    if st then return st end
    st = { alpha = tex:GetAlpha() or 1 }
    fills[tex] = st
    local e = backgrounds[tex]
    if e then st.color = { e.color[1], e.color[2], e.color[3], Kit.BgAlpha(e.base or e.color[4] or 1) }
    else st.color = givenColor[tex] end
    hooksecurefunc(tex, "SetColorTexture", function(_, r, g, b, a)
        st.color = { r or 1, g or 1, b or 1, a or 1 }
        if st.on then PaintPieces(st)
        elseif st.place then pcall(st.place) end
    end)
    hooksecurefunc(tex, "SetAlpha", function(self, a)
        if st.busy then return end
        st.alpha = a or 1
        if st.on then
            FillAlpha(st, self, 0)
            PieceAlpha(st)
        end
    end)
    local function Shown(self) if st.pieces then ShowPieces(st, self) end end
    hooksecurefunc(tex, "Show", Shown)
    hooksecurefunc(tex, "Hide", Shown)
    hooksecurefunc(tex, "SetShown", Shown)
    return st
end

-- Puts the pieces over a fill (radius in screen pixels; 0 = sharp).
local function PlaceFill(tex, frame, radius, px, oL, oR, oT, oB)
    -- Sharp and never rounded: the texture is not touched at all.
    if radius == 0 and not fills[tex] then return end
    local st = FillState(tex)
    if radius == 0 or not st.color then
        -- No colour known yet: the first one painted brings the pieces in.
        st.place = radius > 0 and function() PlaceFill(tex, frame, radius, px, oL, oR, oT, oB) end or nil
        if st.on then
            st.on = false
            ShowPieces(st, tex)
            FillAlpha(st, tex, st.alpha)
        end
        return
    end
    st.place = nil
    if not st.pieces then
        st.pieces = {}
        local host = tex:GetParent()
        local layer, sub = tex:GetDrawLayer()
        for i = 1, 7 do
            local t = host:CreateTexture(nil, layer or "BACKGROUND", nil, sub or 0)
            Kit.Snap(t)
            if Kit.ours then Kit.ours[t] = true end
            st.pieces[i] = t
        end
    end
    local p = st.pieces
    local rr = radius * px
    -- Centre (full height), then the left and right strips between corners.
    p[1]:ClearAllPoints()
    p[1]:SetPoint("TOPLEFT", frame, "TOPLEFT", oL + rr, -oT)
    p[1]:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -oR - rr, oB)
    p[2]:ClearAllPoints()
    p[2]:SetPoint("TOPLEFT", frame, "TOPLEFT", oL, -oT - rr)
    p[2]:SetPoint("BOTTOMRIGHT", frame, "BOTTOMLEFT", oL + rr, oB + rr)
    p[3]:ClearAllPoints()
    p[3]:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -oR, -oT - rr)
    p[3]:SetPoint("BOTTOMLEFT", frame, "BOTTOMRIGHT", -oR - rr, oB + rr)
    local offX = { oL, -oR, oL, -oR }
    local offY = { -oT, -oT, oB, oB }
    for i = 1, 4 do
        local c, cp = p[3 + i], CORNER_POINTS[i]
        if st.radius ~= radius then c:SetTexture(CORNERS .. "fill" .. radius) end
        c:SetTexCoord(cp[4], cp[5], cp[6], cp[7])
        c:ClearAllPoints()
        c:SetPoint(cp[1], frame, cp[1], offX[i], offY[i])
        c:SetSize(rr, rr)
    end
    st.radius = radius
    PaintPieces(st)
    PieceAlpha(st)
    st.on = true
    FillAlpha(st, tex, 0)
    ShowPieces(st, tex)
end

-- Edges in a colour, one screen pixel thick (or the look's thickness). Each
-- edge is placed on the first whole screen pixel inside the frame's side: a
-- frame side that falls between two pixels would otherwise give a blurred or
-- a missing line. The table holds the top, bottom, left and right lines, then
-- the four corner pieces (drawn only with rounded corners), so a loop over it
-- shows, hides or marks them all.
function Kit.MakeBorder(frame, r, g, b, a)
    local edges = {}
    r, g, b, a = r or 1, g or 1, b or 1, a or 1
    local function edge()
        local t = frame:CreateTexture(nil, "BORDER")
        t:SetColorTexture(r, g, b, a)
        Kit.Snap(t)
        edges[#edges + 1] = t
        return t
    end
    local top, bottom, left, right = edge(), edge(), edge(), edge()
    -- The corner pieces: a white quarter ring tinted in the line's colour,
    -- without a place (so not drawn) while the corners are sharp.
    local corners = {}
    for i = 1, 4 do
        local t = frame:CreateTexture(nil, "BORDER")
        t:SetVertexColor(r, g, b, a)
        Kit.Snap(t)
        edges[#edges + 1] = t
        corners[i] = t
    end
    -- A window's outer line (made in Kit.EDGE): follows a new border colour.
    edges.outer = SameColor(Kit.EDGE, r, g, b, a)
    edges.color = { r, g, b, a }
    local ringFile

    function edges:Align()
        local px = Kit.PixelSize(frame)
        -- Frames on a nameplate cannot be measured (restricted): the call
        -- fails, and the lines simply sit on the sides.
        local okM, L, R, T, B = pcall(function() return frame:GetLeft(), frame:GetRight(), frame:GetTop(), frame:GetBottom() end)
        if not okM then L, R, T, B = nil, nil, nil, nil end
        local oL, oR, oT, oB = 0, 0, 0, 0
        -- Secret positions (frames placed by secure code in combat): no
        -- arithmetic on those, the lines simply on the sides.
        local sec = issecretvalue and (issecretvalue(L) or issecretvalue(R) or issecretvalue(T) or issecretvalue(B))
        if L and R and T and B and not sec then
            -- Distance from each side to the nearest whole pixel inside it,
            -- never negative: a line a hair outside the frame could round to
            -- the pixel beyond it and look cut off.
            oL = math.max(0, math.ceil(L / px - 0.01) * px - L)
            oR = math.max(0, R - math.floor(R / px + 0.01) * px)
            oT = math.max(0, T - math.floor(T / px + 0.01) * px)
            oB = math.max(0, math.ceil(B / px - 0.01) * px - B)
        end
        local thick = math.max(1, math.min(3, math.floor((Kit.look.thickness or 1) + 0.5)))
        local lw = thick * px
        local radius = CornerRadius(self, frame, px)
        -- With rounded corners the straight lines stop where the corner
        -- pieces start.
        local rr = radius * px
        top:ClearAllPoints()
        top:SetPoint("TOPLEFT", oL + rr, -oT)
        top:SetPoint("TOPRIGHT", -oR - rr, -oT)
        top:SetHeight(lw)
        bottom:ClearAllPoints()
        bottom:SetPoint("BOTTOMLEFT", oL + rr, oB)
        bottom:SetPoint("BOTTOMRIGHT", -oR - rr, oB)
        bottom:SetHeight(lw)
        -- The sides between the top and bottom lines, not over them: where
        -- they crossed, a see-through border drew its corners twice (lighter).
        local inV = radius > 0 and rr or lw
        left:ClearAllPoints()
        left:SetPoint("TOPLEFT", oL, -oT - inV)
        left:SetPoint("BOTTOMLEFT", oL, oB + inV)
        left:SetWidth(lw)
        right:ClearAllPoints()
        right:SetPoint("TOPRIGHT", -oR, -oT - inV)
        right:SetPoint("BOTTOMRIGHT", -oR, oB + inV)
        right:SetWidth(lw)
        local offX = { oL, -oR, oL, -oR }
        local offY = { -oT, -oT, oB, oB }
        local file = radius > 0 and (CORNERS .. "ring" .. radius .. "_" .. math.min(thick, radius)) or nil
        for i, c in ipairs(corners) do
            c:ClearAllPoints()
            if radius > 0 then
                local p = CORNER_POINTS[i]
                if file ~= ringFile then c:SetTexture(file) end
                c:SetTexCoord(p[4], p[5], p[6], p[7])
                c:SetPoint(p[1], frame, p[1], offX[i], offY[i])
                c:SetSize(rr, rr)
            else
                c:SetSize(0, 0)
            end
        end
        ringFile = file or ringFile
        -- The background under it (RoundFill) rounded the same; never an
        -- error from it, whatever the texture.
        if self.fill then pcall(PlaceFill, self.fill, frame, radius, px, oL, oR, oT, oB) end
    end
    function edges:SetColor(r2, g2, b2, a2)
        top:SetColorTexture(r2, g2, b2, a2)
        bottom:SetColorTexture(r2, g2, b2, a2)
        left:SetColorTexture(r2, g2, b2, a2)
        right:SetColorTexture(r2, g2, b2, a2)
        for _, c in ipairs(corners) do c:SetVertexColor(r2, g2, b2, a2) end
        local col = self.color
        col[1], col[2], col[3], col[4] = r2, g2, b2, a2 or 1
    end
    -- The background under this border (a texture filling the frame) gets
    -- the same rounded corners. Safe to call again with the same texture.
    -- r, g, b, a: its colour when it was painted before this call (the kit
    -- only sees colours painted after it, or through Kit.PaintBg).
    function edges:RoundFill(tex, r2, g2, b2, a2)
        if not tex then return end
        if r2 then
            givenColor[tex] = { r2, g2 or r2, b2 or r2, a2 or 1 }
            local st = fills[tex]
            if st and not st.color then st.color = givenColor[tex] end
        end
        if self.fill == tex then return end
        if self.fill then pcall(PlaceFill, self.fill, frame, 0, 1, 0, 0, 0, 0) end
        self.fill = tex
        self:Align()
    end

    edges:Align()
    bordered[edges] = frame
    allBorders[edges] = frame
    frame:HookScript("OnShow", function()
        bordered[edges] = frame
        edges:Align()
    end)
    frame:HookScript("OnSizeChanged", function() edges:Align() end)
    -- Positions settle on the next frame after creation.
    C_Timer.After(0, function() edges:Align() end)
    return edges
end

-- Puts every visible border back on whole pixels (after a scroll or a drag).
function Kit.RealignBorders()
    for edges, frame in pairs(bordered) do
        if frame:IsVisible() then edges:Align() else bordered[edges] = nil end
    end
end

-- After any scroll: the borders put back on whole pixels on the next frame
-- (a wheel step is 40 units, not whole pixels at most UI scales, and a
-- 1 px line left between two pixels lost one side, check boxes' rings).
-- Once per frame however many scrolls; a plain post-hook, nothing changed
-- in the scroll itself.
do
    local queued = false
    local function Run()
        queued = false
        Kit.RealignBorders()
    end
    local function Queue()
        if queued then return end
        queued = true
        C_Timer.After(0, Run)
    end
    -- (Called by our own scroll lists after they scroll; never a hook on
    -- the game's scroll frames: the chat dock's scroll ran it and erred.)
    Kit.QueueRealign = Queue
end

-- A new look (any of thickness, corners, bgAlpha): every border placed
-- again, hidden ones included, and every background the kit painted given
-- the new opacity. Module backgrounds follow on their next paint.
function Kit.SetLook(t)
    for k, v in pairs(t or {}) do Kit.look[k] = v end
    for edges in pairs(allBorders) do pcall(edges.Align, edges) end
    for tex, e in pairs(backgrounds) do
        tex:SetColorTexture(e.color[1], e.color[2], e.color[3], Kit.BgAlpha(e.base or e.color[4] or 1))
    end
end

-- A new outer line colour: Kit.EDGE changed in place (modules read it on
-- each paint), and every outer line still in the old colour recoloured now
-- (one tinted for the moment, an item's quality on a tooltip, is left).
function Kit.SetEdgeColor(r, g, b, a)
    local E = Kit.EDGE
    local old = { E[1], E[2], E[3], E[4] }
    E[1], E[2], E[3], E[4] = r, g, b, a or 1
    if SameColor(old, E[1], E[2], E[3], E[4]) then return end
    for edges in pairs(allBorders) do
        if edges.outer and SameColor(edges.color, old[1], old[2], old[3], old[4]) then
            edges:SetColor(E[1], E[2], E[3], E[4])
        end
    end
end

-- A texture a whole number of screen pixels inside the frame's pixel-aligned
-- edges (the same edges MakeBorder uses), so the gap is even on every side.
-- units: the inset wanted, in the frame's own units; rounded to pixels.
function Kit.PixelInset(frame, tex, units)
    local inset = {}
    function inset:Align()
        local px = Kit.PixelSize(frame)
        -- Frames on a nameplate cannot be measured (restricted): the call
        -- fails, and the lines simply sit on the sides.
        local okM, L, R, T, B = pcall(function() return frame:GetLeft(), frame:GetRight(), frame:GetTop(), frame:GetBottom() end)
        if not okM then L, R, T, B = nil, nil, nil, nil end
        local oL, oR, oT, oB = 0, 0, 0, 0
        -- Secret positions (frames placed by secure code in combat): no
        -- arithmetic on those, the lines simply on the sides.
        local sec = issecretvalue and (issecretvalue(L) or issecretvalue(R) or issecretvalue(T) or issecretvalue(B))
        if L and R and T and B and not sec then
            oL = math.ceil(L / px - 0.01) * px - L
            oR = R - math.floor(R / px + 0.01) * px
            oT = T - math.floor(T / px + 0.01) * px
            oB = math.ceil(B / px - 0.01) * px - B
        end
        local k = math.max(2, math.floor(units / px + 0.5)) * px
        tex:ClearAllPoints()
        tex:SetPoint("TOPLEFT", oL + k, -(oT + k))
        tex:SetPoint("BOTTOMRIGHT", -(oR + k), oB + k)
    end
    inset:Align()
    bordered[inset] = frame
    frame:HookScript("OnShow", function()
        bordered[inset] = frame
        inset:Align()
    end)
    frame:HookScript("OnSizeChanged", function() inset:Align() end)
    C_Timer.After(0, function() inset:Align() end)
    return inset
end

-------------------------------------------------------------------------------
--  Tweens: one shared OnUpdate eases every running animation and hides
--  itself when none is left. A tween with the same key replaces the last
--  one. With animations off (Kit.animate false) each jumps to its end.
-------------------------------------------------------------------------------
Kit.animate = true
Kit.animSpeed = 1   -- 0.5 slower .. 2 faster (General > Animations)
Kit.growBars = true -- bars grow in from zero
local tweens = {}
local tweenDriver = CreateFrame("Frame")
tweenDriver:Hide()
local running = {}
tweenDriver:SetScript("OnUpdate", function(_, elapsed)
    -- Walk a snapshot: step()/done() may start new tweens (toastIn's done starts
    -- toastShine), and adding keys to a table during pairs() breaks next().
    local n = 0
    for key in pairs(tweens) do n = n + 1; running[n] = key end
    for i = 1, n do
        local key = running[i]
        running[i] = nil
        local tw = tweens[key]
        if tw then
            tw.t = tw.t + elapsed
            local f = math.min(1, tw.t / tw.duration)
            local e = 1 - (1 - f) ^ 3 -- ease-out cubic
            tw.step(e)
            -- step() may have replaced this tween under the same key; leave the new one.
            if f >= 1 and tweens[key] == tw then
                tweens[key] = nil
                if tw.done then tw.done() end
            end
        end
    end
    if not next(tweens) then tweenDriver:Hide() end
end)

-- step(e) gets 0..1 (eased); done() runs once at the end.
function Kit.Tween(key, duration, step, done)
    if not Kit.animate or duration <= 0 then
        step(1)
        if done then done() end
        return
    end
    tweens[key] = { t = 0, duration = duration / (Kit.animSpeed or 1), step = step, done = done }
    step(0)
    tweenDriver:Show()
end

function Kit.Lerp(a, b, e) return a + (b - a) * e end

-------------------------------------------------------------------------------
--  Growing bars: a fill texture eases from zero to its width. Each bar keeps
--  its own start time, so bars made while others still grow do not jump.
-------------------------------------------------------------------------------
local growing = {}
local growDriver = CreateFrame("Frame")
growDriver:Hide()
growDriver:SetScript("OnUpdate", function()
    local now = GetTime()
    for tex, g in pairs(growing) do
        local f = math.min(1, (now - g.t0) / g.dur)
        local e = 1 - (1 - f) ^ 3
        tex:SetWidth(math.max(1, g.width * e))
        if f >= 1 then growing[tex] = nil end
    end
    if not next(growing) then growDriver:Hide() end
end)

-- delay: seconds before it starts, to stagger a list of bars.
function Kit.GrowBar(tex, width, delay, duration)
    width = math.max(1, width)
    if not Kit.animate or not Kit.growBars then
        growing[tex] = nil
        tex:SetWidth(width)
        return
    end
    tex:SetWidth(1)
    growing[tex] = { width = width, t0 = GetTime() + (delay or 0), dur = (duration or 0.6) / (Kit.animSpeed or 1) }
    growDriver:Show()
end

-- Section names written in capitals shown as words: "WHAT SHOWS" as "What
-- Shows"; known short forms kept ("HUD", "AH"), the small joining words lower
-- ("Loot and Log"). One for the headers, the options' tabs and the search.
local TITLE_KEEP = { HUD = true, AH = true, UI = true, XP = true, DPS = true, HPS = true, NPC = true, GCD = true, MVP = true,
                     PVP = true, LFG = true, MT = true, AFK = true, SCT = true, CD = true, ID = true, FPS = true }
local TITLE_SMALL = { AND = "and", OF = "of", TO = "to", IN = "in", ON = "on", THE = "the", FOR = "for", AT = "at", BY = "by", OR = "or" }
local function TitleCase(s)
    s = tostring(s or "")
    if s:upper() ~= s then return s end
    local first = true
    return (s:gsub("[%a']+", function(w)
        local out
        if TITLE_SMALL[w] and not first then out = TITLE_SMALL[w]
        elseif TITLE_KEEP[w] then out = w
        else out = w:sub(1, 1) .. w:sub(2):lower() end
        first = false
        return out
    end))
end
Kit.TitleCase = TitleCase

local function Tooltip(frame, title, text)
    if not text then return end
    frame:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(title, 1, 1, 1)
        GameTooltip:AddLine(text, nil, nil, nil, true)
        GameTooltip:Show()
    end)
    frame:HookScript("OnLeave", function() GameTooltip:Hide() end)
end

-- A card row: background, border, hover, label on the left.
local function Card(parent, y, text, tooltip, width, x)
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(width or (parent:GetWidth() - PAD * 2), ROW_H)
    row:SetPoint("TOPLEFT", parent, "TOPLEFT", x or PAD, y)
    row:EnableMouse(true)
    local bg = row:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    Kit.PaintBg(bg, C.card)
    Kit.MakeBorder(row, unpack(C.edge)):RoundFill(bg)
    row:SetScript("OnEnter", function() Kit.PaintBg(bg, C.cardHover) end)
    row:SetScript("OnLeave", function() Kit.PaintBg(bg, C.card) end)
    if text then
        local label = Kit.RoleFont(row, "label", 13, nil, unpack(C.text))
        label:SetPoint("LEFT", 14, 0)
        label:SetText(text)
        row.label = label
    end
    Tooltip(row, text, tooltip)
    return row
end

-------------------------------------------------------------------------------
--  Controls (placed inside a card or a half of one)
-------------------------------------------------------------------------------
local function Checkbox(host, get, set)
    local box = CreateFrame("Button", nil, host)
    box:SetSize(18, 18)
    -- A dark well with a 1 px ring (pixel-aligned like every border) and a
    -- filled square when on.
    local well = box:CreateTexture(nil, "BACKGROUND")
    well:SetAllPoints()
    local ring = Kit.MakeBorder(box, 1, 1, 1, 0.35)
    local tick = Kit.Snap(box:CreateTexture(nil, "OVERLAY"))
    Kit.PixelInset(box, tick, 4)
    local state = Kit.RoleFont(host, "control", 12, nil, unpack(C.dim))
    state:SetPoint("RIGHT", box, "LEFT", -8, 0)
    local function paint()
        local on = get() and true or false
        well:SetColorTexture(C.bg[1], C.bg[2], C.bg[3], 1)
        tick:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 1)
        if on then
            ring:SetColor(C.accent[1], C.accent[2], C.accent[3], 1)
        else
            ring:SetColor(1, 1, 1, 0.35)
        end
        tick:SetShown(on)
        state:SetText(on and "On" or "Off")
        state:SetTextColor(on and C.accent[1] or C.dim[1], on and C.accent[2] or C.dim[2], on and C.accent[3] or C.dim[3])
    end
    box:SetScript("OnClick", function() set(not get()); paint() end)
    -- (Placed on whole pixels once the page is laid out, else a half-pixel
    -- spot loses one side of the ring.)
    local function Align()
        local px = Kit.PixelSize(box)
        if px and px > 0 then
            local s = math.max(px, math.floor(18 / px + 0.5) * px)
            local w = box:GetWidth()
            if w and math.abs(w - s) > 0.001 then box:SetSize(s, s) end
        end
        if ring.Align then ring:Align() end
        if Kit.SnapFrame then pcall(Kit.SnapFrame, box) end
    end
    box:HookScript("OnShow", Align)
    box:HookScript("OnSizeChanged", Align)
    C_Timer.After(0, Align)
    paint()
    box.state = state
    return box
end
Kit.Checkbox = Checkbox

local function SliderControl(host, width, minVal, maxVal, step, get, set)
    local holder = CreateFrame("Frame", nil, host)
    holder:SetSize(width, 20)
    -- The value on the right is a button: a click turns it into a box to
    -- type a number in (Enter sets it, Escape leaves it as it was).
    local valueBtn = CreateFrame("Button", nil, holder)
    valueBtn:SetPoint("RIGHT", 0, 0)
    valueBtn:SetSize(44, 20)
    local value = Kit.RoleFont(valueBtn, "control", 12, nil, C.accent[1], C.accent[2], C.accent[3], 1)
    value:SetAllPoints()
    value:SetJustifyH("RIGHT")
    local track = CreateFrame("Frame", nil, holder)
    track:SetPoint("LEFT", 0, 0)
    track:SetPoint("RIGHT", valueBtn, "LEFT", -12, 0)
    track:SetHeight(16)
    track:EnableMouse(true)
    local line = track:CreateTexture(nil, "BACKGROUND")
    line:SetHeight(2)
    line:SetPoint("LEFT")
    line:SetPoint("RIGHT")
    line:SetColorTexture(1, 1, 1, 0.15)
    local fill = track:CreateTexture(nil, "ARTWORK")
    fill:SetHeight(2)
    fill:SetPoint("LEFT")
    fill:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 1)
    local knob = track:CreateTexture(nil, "OVERLAY")
    knob:SetSize(8, 8)
    knob:SetColorTexture(1, 1, 1, 1)
    local function paint()
        local v = get()
        local f = (v - minVal) / math.max(1e-9, maxVal - minVal)
        local w = math.max(1, (track:GetWidth() or 100) * f)
        fill:SetWidth(w)
        knob:ClearAllPoints()
        knob:SetPoint("CENTER", track, "LEFT", w, 0)
        value:SetText(tostring(math.floor(v + 0.5)))
    end
    local function setFromCursor()
        local x = GetCursorPosition() / track:GetEffectiveScale()
        local left, w = track:GetLeft(), track:GetWidth()
        if not left or w <= 0 then return end
        local f = math.min(1, math.max(0, (x - left) / w))
        local v = minVal + f * (maxVal - minVal)
        v = minVal + math.floor((v - minVal) / step + 0.5) * step
        set(v)
        paint()
    end
    track:SetScript("OnMouseDown", function(self)
        setFromCursor()
        self:SetScript("OnUpdate", function()
            if IsMouseButtonDown("LeftButton") then setFromCursor() else track:SetScript("OnUpdate", nil) end
        end)
    end)
    track:SetScript("OnSizeChanged", paint)
    -- Typed values: put on the slider's step and kept between its ends.
    local box
    local function Shown(v)
        if step < 1 then return (("%.2f"):format(v):gsub("%.?0+$", "")) end
        return tostring(math.floor(v + 0.5))
    end
    local function Close() if box then box:Hide(); value:Show() end end
    local function Apply(text)
        local v = tonumber(((text or ""):gsub(",", ".")):match("^%s*(.-)%s*$"))
        if v then
            v = math.min(maxVal, math.max(minVal, v))
            v = minVal + math.floor((v - minVal) / step + 0.5) * step
            set(v)
        end
        Close()
        paint()
    end
    valueBtn:SetScript("OnEnter", function() value:SetTextColor(C.text[1], C.text[2], C.text[3], 1) end)
    valueBtn:SetScript("OnLeave", function() value:SetTextColor(C.accent[1], C.accent[2], C.accent[3], 1) end)
    valueBtn:SetScript("OnClick", function()
        if not box then
            box = CreateFrame("EditBox", nil, holder)
            box:SetAllPoints(valueBtn)
            box:SetAutoFocus(false)
            box:SetFont(FONT, 12, "")
            box:SetTextColor(C.text[1], C.text[2], C.text[3])
            box:SetJustifyH("RIGHT")
            box:SetTextInsets(4, 4, 0, 0)
            box:SetMaxLetters(8)
            local bg = box:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints()
            bg:SetColorTexture(0, 0, 0, 0.35)
            Kit.MakeBorder(box, C.accent[1], C.accent[2], C.accent[3], 0.8)
            box:SetScript("OnEnterPressed", function(self) Apply(self:GetText()) end)
            box:SetScript("OnEscapePressed", Close)
            box:SetScript("OnEditFocusLost", Close)
        end
        value:Hide()
        box:SetText(Shown(get()))
        box:Show()
        box:SetFocus()
        box:HighlightText()
    end)
    C_Timer.After(0, paint)
    return holder
end

local openMenu
local MENU_ROWS = 16 -- entries a dropdown's list shows at once (more scroll)
local function DropdownControl(host, width, values, order, get, set)
    local btn = CreateFrame("Button", nil, host)
    btn:SetSize(width, 26)
    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.35)
    local border = Kit.MakeBorder(btn, 1, 1, 1, 0.2)
    local text = Kit.RoleFont(btn, "control", 12, nil, unpack(C.text))
    text:SetPoint("LEFT", 10, 0)
    text:SetPoint("RIGHT", -24, 0)
    text:SetJustifyH("LEFT")
    text:SetWordWrap(false)
    -- Chevron drawn from two thin rotated bars, so it matches the flat look.
    local chevron = CreateFrame("Frame", nil, btn)
    chevron:SetSize(12, 8)
    chevron:SetPoint("RIGHT", -10, 0)
    local bars = {}
    for _, side in ipairs({ -1, 1 }) do
        local bar = chevron:CreateTexture(nil, "OVERLAY")
        bar:SetSize(7, 1.5)
        bar:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 1)
        bar:SetPoint("CENTER", chevron, "CENTER", side * 2.4, 0)
        bar:SetRotation(side * math.pi / 4)
        bars[side] = bar
    end
    -- open 0 = pointing down, 1 = pointing up; eased between the two.
    local function Chevron(open)
        for side, bar in pairs(bars) do bar:SetRotation(side * math.pi / 4 * (1 - 2 * open)) end
    end
    local function TurnChevron(toOpen)
        local from = toOpen and 0 or 1
        Kit.Tween(btn, 0.16, function(e) Chevron(Kit.Lerp(from, 1 - from, e)) end)
    end
    local function paint() text:SetText(values[get()] or tostring(get())) end
    btn:SetScript("OnEnter", function() border:SetColor(C.accent[1], C.accent[2], C.accent[3], 0.8) end)
    btn:SetScript("OnLeave", function() border:SetColor(1, 1, 1, 0.2) end)
    btn:SetScript("OnClick", function(self)
        -- A second click on the same dropdown closes its list.
        if openMenu then
            local mine = openMenu.owner == self
            openMenu:Hide()
            if mine then return end
        end
        local menu = CreateFrame("Frame", nil, UIParent)
        menu.owner = self
        -- As big as the button's window (one scaled apart from the
        -- interface, as the options window): the list matches its button.
        local ue = UIParent:GetEffectiveScale()
        if ue and ue > 0 then menu:SetScale(self:GetEffectiveScale() / ue) end
        menu:SetFrameStrata("FULLSCREEN_DIALOG")
        menu:SetWidth(width)
        menu:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, -2)
        local mbg = menu:CreateTexture(nil, "BACKGROUND")
        mbg:SetAllPoints()
        Kit.PaintBg(mbg, C.bg, 0.99)
        Kit.MakeBorder(menu, C.accent[1], C.accent[2], C.accent[3], 0.6):RoundFill(mbg)
        local keys = order or {}
        if not order then for k in pairs(values) do keys[#keys + 1] = k end end
        menu:SetClampedToScreen(true)
        -- A long list (the shared fonts) shows MENU_ROWS at a time and
        -- scrolls with the wheel, the picked entry in view when it opens.
        local scroll = #keys > MENU_ROWS
        local shown = math.min(#keys, MENU_ROWS)
        local offset = 0
        if scroll then
            for i, k in ipairs(keys) do
                if k == get() then offset = math.max(0, math.min(#keys - shown, i - math.floor(shown / 2) - 1)) end
            end
        end
        local items, widest = {}, 0
        for _, k in ipairs(keys) do
          if k == "-" then
            -- A thin line between groups (a row of its own, not picked).
            local item = CreateFrame("Frame", nil, menu)
            items[#items + 1] = item
            item:SetSize(width - 8, 22)
            local line = item:CreateTexture(nil, "ARTWORK")
            line:SetHeight(1)
            line:SetPoint("LEFT", 6, 0)
            line:SetPoint("RIGHT", -6, 0)
            line:SetColorTexture(1, 1, 1, 0.15)
          else
            local item = CreateFrame("Button", nil, menu)
            items[#items + 1] = item
            item:SetSize(width - 8, 22)
            local hl = item:CreateTexture(nil, "BACKGROUND")
            hl:SetAllPoints()
            hl:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], k == get() and 0.22 or 0)
            local it = Kit.RoleFont(item, "control", 12, nil, unpack(C.text))
            it:SetPoint("LEFT", 8, 0)
            it:SetText(values[k] or k)
            widest = math.max(widest, it:GetStringWidth() or 0)
            item:SetScript("OnEnter", function() if k ~= get() then hl:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.12) end end)
            item:SetScript("OnLeave", function() if k ~= get() then hl:SetColorTexture(0, 0, 0, 0) end end)
            item:SetScript("OnClick", function() set(k); paint(); menu:Hide() end)
          end
        end
        menu:SetHeight(shown * 22 + 8)
        -- As wide as the longest entry (8 px text inset each side), never
        -- narrower than the button: long names stayed outside the frame.
        local bar = scroll and 6 or 0
        local menuW = math.max(width, math.ceil(widest) + 8 + 16 + 8 + bar)
        menu:SetWidth(menuW)
        for _, item in ipairs(items) do item:SetWidth(menuW - 8 - bar) end
        local thumb
        if scroll then
            thumb = menu:CreateTexture(nil, "OVERLAY")
            thumb:SetWidth(2)
            thumb:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.6)
        end
        local function Place()
            for i, item in ipairs(items) do
                local row = i - 1 - offset
                if row >= 0 and row < shown then
                    item:SetPoint("TOPLEFT", 4, -4 - row * 22)
                    item:Show()
                else
                    item:Hide()
                end
            end
            if thumb then
                local track = shown * 22
                thumb:SetHeight(math.max(12, track * shown / #keys))
                thumb:SetPoint("TOPRIGHT", -4, -4 - (track - thumb:GetHeight()) * offset / (#keys - shown))
            end
        end
        Place()
        if scroll then
            menu:EnableMouseWheel(true)
            menu:SetScript("OnMouseWheel", function(_, delta)
                local o = math.max(0, math.min(#keys - shown, offset - delta * 3))
                if o ~= offset then offset = o; Place() end
            end)
        end
        menu:EnableMouse(true)
        menu:SetScript("OnHide", function()
            if openMenu == menu then openMenu = nil end
            TurnChevron(false)
        end)
        -- Fades in while sliding down a few pixels from the button.
        menu:SetAlpha(0)
        Kit.Tween(menu, 0.14, function(e)
            menu:SetAlpha(e)
            menu:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, Kit.Lerp(6, -2, e))
        end)
        TurnChevron(true)
        -- Close on a click anywhere else.
        menu:SetScript("OnUpdate", function()
            if IsMouseButtonDown("LeftButton") and not menu:IsMouseOver() and not self:IsMouseOver() then menu:Hide() end
        end)
        openMenu = menu
    end)
    paint()
    return btn
end

Kit.Dropdown = DropdownControl

-- A one-line text box in the dropdown's look. hint: dim text shown while it
-- is empty and not typed in; onEnter(text) on Enter.
local function InputControl(host, width, hint, onEnter)
    local eb = CreateFrame("EditBox", nil, host)
    eb:SetSize(width, 26)
    eb:SetAutoFocus(false)
    eb:SetMaxLetters(64)
    eb:SetFont(Kit.FONT, 12, "")
    eb:SetTextColor(unpack(C.text))
    eb:SetTextInsets(10, 10, 0, 0)
    local bg = eb:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.35)
    local border = Kit.MakeBorder(eb, 1, 1, 1, 0.2)
    local ph = Kit.RoleFont(eb, "control", 12, nil, unpack(C.dim))
    ph:SetPoint("LEFT", 10, 0)
    ph:SetPoint("RIGHT", -10, 0)
    ph:SetJustifyH("LEFT")
    ph:SetWordWrap(false)
    ph:SetText(hint or "")
    local function ShowHint() ph:SetShown(eb:GetText() == "" and not eb:HasFocus()) end
    eb:SetScript("OnEditFocusGained", function() border:SetColor(C.accent[1], C.accent[2], C.accent[3], 0.8); ShowHint() end)
    eb:SetScript("OnEditFocusLost", function() border:SetColor(1, 1, 1, 0.2); ShowHint() end)
    eb:SetScript("OnTextChanged", ShowHint)
    eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    eb:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
        if onEnter then onEnter(self:GetText()) end
    end)
    ShowHint()
    return eb
end
Kit.Input = InputControl

-------------------------------------------------------------------------------
--  Gates: a card that waits on another option. cfg.enabled() false dims it
--  and a cover takes its clicks (cfg.disabledNote as the tooltip, why);
--  cfg.highlight() true frames it in the accent (the option to set first).
--  Kit.RefreshGates() paints them again after that option changes.
-------------------------------------------------------------------------------
Kit.gates = setmetatable({}, { __mode = "k" })
function Kit.PaintGate(card, cfg)
    local on = not cfg.enabled or (cfg.enabled() and true or false)
    card:SetAlpha(on and 1 or 0.35)
    if cfg.enabled then
        local cover = card.gateCover
        if not cover then
            cover = CreateFrame("Frame", nil, card)
            cover:SetAllPoints()
            cover:EnableMouse(true)
            cover:SetScript("OnEnter", function(self)
                if not cfg.disabledNote then return end
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:AddLine(cfg.text or "", 1, 1, 1)
                GameTooltip:AddLine(cfg.disabledNote, 1, 0.82, 0.3, true)
                GameTooltip:Show()
            end)
            cover:SetScript("OnLeave", function() GameTooltip:Hide() end)
            card.gateCover = cover
        end
        cover:SetFrameLevel(card:GetFrameLevel() + 30)
        cover:SetShown(not on)
    end
    if cfg.highlight then
        if not card.gateEdge then card.gateEdge = Kit.MakeBorder(card, C.accent[1], C.accent[2], C.accent[3], 1) end
        card.gateEdge:SetColor(C.accent[1], C.accent[2], C.accent[3], cfg.highlight() and 1 or 0)
    end
end
function Kit.RefreshGates()
    for card, cfg in pairs(Kit.gates) do
        if card:IsVisible() then Kit.PaintGate(card, cfg) end
    end
end

-------------------------------------------------------------------------------
--  Reset per section: a page built from Kit.Track(saved) (a stand-in for the
--  saved settings that notes each key a control reads) gets a "Reset" by
--  each section header (two clicks): the keys its controls read set back to
--  nil (the addon's defaults fill them again), then Kit.onReset runs.
--  Keys in Kit.NO_RESET, and tables not in Kit.RESET_TABLES, never reset.
-------------------------------------------------------------------------------
Kit.NO_RESET, Kit.RESET_TABLES = {}, {}
local recording            -- the key set of the section being built
local curKeys              -- the last section header's key set, by parent
local tracked = setmetatable({}, { __mode = "k" })
function Kit.Track(real)
    local proxy = tracked[real]
    if proxy then Kit.trackedReal = real return proxy end
    proxy = setmetatable({}, {
        __index = function(_, k)
            if recording then recording[k] = true end
            return real[k]
        end,
        __newindex = function(_, k, v) real[k] = v end,
    })
    tracked[real] = proxy
    Kit.trackedReal = real
    return proxy
end
-- What a control reads, once: its keys to the section's set.
function Kit.NoteKeys(parent, getValue)
    local keys = curKeys and curKeys[parent]
    if not (keys and type(getValue) == "function") then return end
    recording = keys
    pcall(getValue)
    recording = nil
end
local function ResetButton(frame, keys)
    local btn = CreateFrame("Button", nil, frame)
    btn:SetSize(60, 20)
    btn:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 4)
    local label = Kit.MakeFont(btn, 11, nil, C.dim[1], C.dim[2], C.dim[3], 0.8)
    label:SetPoint("RIGHT")
    label:SetText("Reset")
    local armed = false
    btn:SetScript("OnEnter", function(self)
        label:SetTextColor(C.accent[1], C.accent[2], C.accent[3], 1)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Reset this section", 1, 1, 1)
        GameTooltip:AddLine("Its options back to the defaults. Click twice.", 0.7, 0.7, 0.7, true)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function()
        if not armed then label:SetTextColor(C.dim[1], C.dim[2], C.dim[3], 0.8) end
        GameTooltip:Hide()
    end)
    btn:SetScript("OnClick", function()
        if not armed then
            armed = true
            label:SetText("Click again")
            label:SetTextColor(1, 0.45, 0.45, 1)
            C_Timer.After(3, function()
                armed = false
                label:SetText("Reset")
                label:SetTextColor(C.dim[1], C.dim[2], C.dim[3], 0.8)
            end)
            return
        end
        armed = false
        local real = Kit.trackedReal
        if not real then return end
        for k in pairs(keys) do
            if not Kit.NO_RESET[k] and (type(real[k]) ~= "table" or Kit.RESET_TABLES[k]) then real[k] = nil end
        end
        if Kit.onReset then Kit.onReset() end
    end)
    btn:SetShown(next(keys) ~= nil)
    C_Timer.After(0, function() btn:SetShown(next(keys) ~= nil) end)
    return btn
end

-------------------------------------------------------------------------------
--  Page widgets: each takes the parent and a y offset, returns the row and its height
-------------------------------------------------------------------------------
local W = {}
Kit.W = W
local BuildCard -- (gates on a built card, set by BuildRow's file part)

-------------------------------------------------------------------------------
--  Grouping by kind: while a page is built between W:BeginGroups() and
--  W:EndGroups() (the options window does it round every page), DualRow
--  only notes its two cells and the row's place. A section ends at the
--  next SectionHeader or WideDualButton on the same parent (or at
--  EndGroups); its cells are then packed by kind: dropdowns, sliders,
--  check boxes, buttons, the page's order kept inside each kind, two to a
--  row with no gaps (a kind with an odd count shares its last row with
--  the next kind's first). Only a section's very last cell can be alone;
--  it then fills the whole row. The rows take the section's first places;
--  the places left over are dropped and everything under them on the page
--  (headers, previews, text boxes, notes, the next sections) moves up.
--  A cell with group = false keeps its row as the page wrote it (alone
--  with full = true: the whole row).
-------------------------------------------------------------------------------
local KIND_RANK = { dropdown = 1, slider = 2, toggle = 3, button = 4, input = 5 }
local function Rank(cfg) return KIND_RANK[cfg.type] or 5 end
local ROW_STEP = ROW_H + GAP

-- cells: in the page's order. Returns the rows ({ left, right }; a lone
-- last cell as { left }), ceil(#cells / 2) of them.
function Kit.ArrangeCells(cells)
    local tagged = {}
    for i, c in ipairs(cells) do tagged[i] = { c = c, i = i } end
    table.sort(tagged, function(a, b)
        local ra, rb = Rank(a.c), Rank(b.c)
        if ra ~= rb then return ra < rb end
        return a.i < b.i
    end)
    local rows = {}
    for i = 1, #tagged, 2 do
        rows[#rows + 1] = { tagged[i].c, tagged[i + 1] and tagged[i + 1].c or nil }
    end
    return rows
end

local grouping, sections, dropped = false, {}, {}
local BuildRow -- (DualRow's cards, further down)

local function CloseSection(parent)
    local sec = sections[parent]
    if not sec then return end
    sections[parent] = nil
    local rows = Kit.ArrangeCells(sec.cells)
    for k, slot in ipairs(sec.slots) do
        local row = rows[k]
        if row then
            BuildRow(parent, slot.y, row[1], row[2], not row[2])
        else
            -- A place no row needs: the page closes up over it.
            dropped[parent] = dropped[parent] or {}
            table.insert(dropped[parent], slot.y)
        end
    end
end

-- How many dropped places lie above a point at y (page offsets, down is
-- negative).
local function DroppedAbove(list, y)
    local n = 0
    for _, top in ipairs(list) do
        if y < top - 0.5 then n = n + 1 end
    end
    return n
end

-- Everything on the parent placed from its top moved up by the dropped
-- places above it; a scroll child loses their height too.
local function CloseUp(parent, list)
    local function Move(obj)
        local n = obj.GetNumPoints and obj:GetNumPoints() or 0
        if n == 0 then return end
        local points, moved = {}, false
        for i = 1, n do
            local p, rel, rp, x, y = obj:GetPoint(i)
            if rel == parent and type(rp) == "string" and rp:find("TOP") and type(y) == "number" then
                local k = DroppedAbove(list, y)
                if k > 0 then y = y + k * ROW_STEP; moved = true end
            end
            points[i] = { p, rel, rp, x, y }
        end
        if not moved then return end
        obj:ClearAllPoints()
        for _, pt in ipairs(points) do obj:SetPoint(pt[1], pt[2], pt[3], pt[4], pt[5]) end
    end
    for _, c in ipairs({ parent:GetChildren() }) do Move(c) end
    for _, r in ipairs({ parent:GetRegions() }) do Move(r) end
    local sf = parent:GetParent()
    if sf and sf.GetScrollChild and sf:GetScrollChild() == parent then
        local h = parent:GetHeight() or 0
        parent:SetHeight(math.max(10, h - #list * ROW_STEP))
    end
end

function W:BeginGroups()
    grouping, sections, dropped = true, {}, {}
end

function W:EndGroups()
    local open = {}
    for parent in pairs(sections) do open[#open + 1] = parent end
    for _, parent in ipairs(open) do CloseSection(parent) end
    for parent, list in pairs(dropped) do CloseUp(parent, list) end
    grouping, sections, dropped = false, {}, {}
end

function W:SectionHeader(parent, text, y)
    CloseSection(parent)
    local keys
    if Kit.trackedReal then
        curKeys = curKeys or setmetatable({}, { __mode = "k" })
        keys = {}
        curKeys[parent] = keys
    end
    local frame = CreateFrame("Frame", nil, parent)
    frame:SetSize(parent:GetWidth() - PAD * 2, 34)
    frame:SetPoint("TOPLEFT", parent, "TOPLEFT", PAD, y)
    local bar = frame:CreateTexture(nil, "ARTWORK")
    bar:SetSize(3, 16)
    bar:SetPoint("BOTTOMLEFT", 0, 6)
    bar:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 1)
    local label = Kit.RoleFont(frame, "header", 15, nil, unpack(C.text))
    label:SetPoint("LEFT", bar, "RIGHT", 8, 0)
    label:SetText(TitleCase(text))
    if keys then frame.reset = ResetButton(frame, keys) end
    if self.headLog then table.insert(self.headLog, { parent = parent, text = text, frame = frame }) end
    return frame, 34
end
-- The section headers a page builds, noted while a log is set (a tab strip
-- made from them, a search): W:LogHeads(list) before, W:LogHeads(nil) after.
function W:LogHeads(list) self.headLog = list end

function W:Toggle(parent, text, y, getValue, setValue, tooltip)
    local row = Card(parent, y, text, tooltip)
    local box = Checkbox(row, getValue, setValue)
    box:SetPoint("RIGHT", -14, 0)
    return row, ROW_H + GAP
end

function W:Slider(parent, text, y, minVal, maxVal, step, getValue, setValue, tooltip)
    local row = Card(parent, y, text, tooltip)
    local s = SliderControl(row, 300, minVal, maxVal, step, getValue, setValue)
    s:SetPoint("RIGHT", -14, 0)
    return row, ROW_H + GAP
end

function W:Dropdown(parent, text, y, values, getValue, setValue, order, tooltip)
    local row = Card(parent, y, text, tooltip)
    local dd = DropdownControl(row, 220, values, order, getValue, setValue)
    dd:SetPoint("RIGHT", -14, 0)
    if row.label then
        row.label:SetPoint("RIGHT", dd, "LEFT", -12, 0)
        row.label:SetJustifyH("LEFT")
        row.label:SetWordWrap(false)
    end
    return row, ROW_H + GAP
end

local function FitLabel(label, room)
    if not label or room <= 0 then return end
    local font, _, flags = label:GetFont()
    for size = 13, 11, -1 do
        if font then label:SetFont(font, size, flags) end
        if (label:GetStringWidth() or 0) <= room then return end
    end
    label:SetWidth(room)
    label:SetJustifyH("LEFT")
    label:SetWordWrap(false)
end

-- Plays a sound to hear it: a sound kit ID (number) or a file (string), on
-- the Master channel; nil, 0 or "" plays nothing.
function Kit.PlayPreview(snd)
    if type(snd) == "number" then
        if snd > 0 then pcall(PlaySound, snd, "Master") end
    elseif type(snd) == "string" and snd ~= "" then
        local id = tonumber(snd)
        if id then pcall(PlaySound, id, "Master") else pcall(PlaySoundFile, snd, "Master") end
    end
end

-- A cell (dropdown or toggle cfg) with a play button: snd is a sound kit
-- ID, a file, or a function returning one (nil: nothing to play). Returns
-- the cfg.
function Kit.WithSound(cfg, snd)
    if type(cfg) == "table" then
        cfg.sound = type(snd) == "function" and snd or function() return snd end
    end
    return cfg
end

-- A function returning SOUNDKIT[name] (fallback: the ID when the game has
-- no such name), for Kit.WithSound.
function Kit.SoundKit(name, fallback)
    return function() return (SOUNDKIT and SOUNDKIT[name]) or fallback end
end

-- A small play button (the Kit button's look) that plays what getSound()
-- returns (see Kit.PlayPreview).
local PLAY_GLYPH = MEDIA .. "play"
local PLAY_SIZE = 26 -- (as tall as a dropdown: one size beside every control)
local CONTROL_H = 26 -- every control in a page's row: dropdown, play, buttons
function Kit.PlayButton(host, getSound)
    local b = CreateFrame("Button", nil, host)
    b:SetSize(PLAY_SIZE, PLAY_SIZE)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.35)
    local edge = Kit.MakeBorder(b, 1, 1, 1, 0.2)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(12, 12)
    icon:SetPoint("CENTER", 0, 0) -- (the glyph is drawn optically centred)
    icon:SetTexture(PLAY_GLYPH)
    icon:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1)
    b:SetScript("OnEnter", function(self)
        bg:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.2)
        edge:SetColor(C.accent[1], C.accent[2], C.accent[3], 0.8)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Play", 1, 1, 1)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function()
        bg:SetColorTexture(0, 0, 0, 0.35)
        edge:SetColor(1, 1, 1, 0.2)
        GameTooltip:Hide()
    end)
    b:SetScript("OnClick", function()
        local ok, snd = pcall(getSound)
        if ok then Kit.PlayPreview(snd) end
    end)
    return b
end

-- full: the left cell alone over the whole row (a section's lone last cell).
-- A dropdown or toggle cell with cfg.sound (a function returning a sound
-- kit ID or a file) gets a play button on its right that plays it.
BuildRow = function(parent, y, leftCfg, rightCfg, full)
    local total = parent:GetWidth() - PAD * 2
    local half = full and total or math.floor((total - GAP) / 2)
    local function build(cfg, x, w)
        if not cfg then return end
        local card = Card(parent, y, cfg.text, cfg.tooltip, w or half, x)
        -- The play button left of the control (the control keeps the column's
        -- right edge, as in rows without one).
        local play = 0
        local playBtn
        if type(cfg.sound) == "function" and (cfg.type == "dropdown" or cfg.type == "toggle") then
            playBtn = Kit.PlayButton(card, cfg.sound)
            play = PLAY_SIZE + 6
            -- Played as it is switched on or a value is picked (the play
            -- button stays, to hear it again).
            if cfg.setValue then
                local set, isToggle, base = cfg.setValue, cfg.type == "toggle", cfg
                cfg = setmetatable({ setValue = function(v)
                    set(v)
                    if (not isToggle) or v then
                        local ok, snd = pcall(base.sound)
                        if ok and snd and Kit.PlayPreview then Kit.PlayPreview(snd) end
                    end
                end }, { __index = base })
            end
        end
        if cfg.type == "dropdown" then
            -- (The play button as tall as the dropdown beside it.)
            if playBtn then play = PLAY_SIZE + 6 end
            -- 12 after the label (a long one shortens the box).
            local lw = card.label and math.ceil(card.label:GetStringWidth() or 0) or 0
            -- One width for every dropdown (and every slider): the label is
            -- cut short instead, so the controls line up down the page.
            local dw = math.min(170, half - 14 - 12 - 60 - play)
            if card.label then FitLabel(card.label, half - 14 - 12 - dw - 12 - play) end
            local dd = DropdownControl(card, dw, cfg.values, cfg.order, cfg.getValue, cfg.setValue)
            dd:SetPoint("RIGHT", -12, 0)
            if playBtn then playBtn:SetPoint("RIGHT", dd, "LEFT", -6, 0) end
        elseif cfg.type == "slider" then
            -- The track starts 16 after the label (a long one shortens it).
            local lw = card.label and math.ceil(card.label:GetStringWidth() or 0) or 0
            local sw = math.min(150, half - 14 - 12 - 60)
            if card.label then FitLabel(card.label, half - 14 - 12 - sw - 16) end
            SliderControl(card, sw, cfg.min, cfg.max, cfg.step or 1, cfg.getValue, cfg.setValue):SetPoint("RIGHT", -12, 0)
        elseif cfg.type == "toggle" then
            local box = Checkbox(card, cfg.getValue, cfg.setValue)
            box:SetPoint("RIGHT", -12, 0)
            -- (Left of the On/Off text: the box, 8, the text up to 24 wide.)
            if playBtn then playBtn:SetPoint("RIGHT", box, "LEFT", -(8 + 24 + 6), 0) end
            -- Room up to the On/Off text (as wide as "Off" at most).
            FitLabel(card.label, half - 14 - 12 - 18 - 8 - 24 - 10 - play)
        elseif cfg.type == "button" then
            -- A small button on the right (an action, not a setting).
            local bw = cfg.width or 72
            local b = Kit.Button(card, cfg.button or "Show", bw, cfg.onClick)
            b:SetHeight(CONTROL_H)
            b:SetPoint("RIGHT", -12, 0)
            FitLabel(card.label, half - 14 - 12 - bw - 10)
        elseif cfg.type == "buttons" then
            local right, used = -12, 0
            for k = #(cfg.buttons or {}), 1, -1 do
                local bc = cfg.buttons[k]
                local bw = bc.width or 60
                local b = Kit.Button(card, bc.text, bw, bc.onClick)
                b:SetHeight(CONTROL_H)
                b:SetPoint("RIGHT", right, 0)
                right = right - bw - 6
                used = used + bw + 6
            end
            FitLabel(card.label, half - 14 - 12 - used - 4)
        elseif cfg.type == "input" then
            -- A text box, with an optional button on its right that takes
            -- the text (Enter does the same).
            local bw = cfg.button and (cfg.width or 64) or 0
            local eb
            local function go() if cfg.onClick then cfg.onClick(eb:GetText(), eb) end end
            local right = -12
            if cfg.button then
                local b = Kit.Button(card, cfg.button, bw, go)
                b:SetHeight(24)
                b:SetPoint("RIGHT", -12, 0)
                right = -12 - bw - 6
            end
            local lw = card.label and math.ceil(card.label:GetStringWidth() or 0) or 0
            local ew = math.max(90, math.min(180, half - 14 - lw - 12 + right))
            eb = InputControl(card, ew, cfg.hint, go)
            eb:SetPoint("RIGHT", right, 0)
            if cfg.getValue then eb:SetText(cfg.getValue() or "") end
            card.input = eb
            if cfg.init then cfg.init(eb) end
        end
        BuildCard(card, cfg)
    end
    build(leftCfg, PAD)
    if not full then build(rightCfg, PAD + half + GAP, total - half - GAP) end
end
BuildCard = function(card, cfg)
    if cfg and (cfg.enabled or cfg.highlight) then
        Kit.gates[card] = cfg
        Kit.PaintGate(card, cfg)
    end
end

function W:DualRow(parent, y, leftCfg, rightCfg)
    if not leftCfg and rightCfg then leftCfg, rightCfg = rightCfg, nil end
    Kit.NoteKeys(parent, leftCfg and leftCfg.getValue)
    Kit.NoteKeys(parent, rightCfg and rightCfg.getValue)
    local keep = (leftCfg and leftCfg.group == false) or (rightCfg and rightCfg.group == false)
    if not grouping or keep then
        -- (one cell alone fills the whole row: no half card by an empty space)
        BuildRow(parent, y, leftCfg, rightCfg, leftCfg and not rightCfg)
        return nil, ROW_H + GAP
    end
    local sec = sections[parent]
    if not sec then
        sec = { slots = {}, cells = {} }
        sections[parent] = sec
    end
    sec.slots[#sec.slots + 1] = { y = y, left = leftCfg, right = rightCfg }
    if leftCfg then sec.cells[#sec.cells + 1] = leftCfg end
    if rightCfg then sec.cells[#sec.cells + 1] = rightCfg end
    return nil, ROW_H + GAP
end

-- One part's place across the row: its name, then a dropdown and up to
-- three small sliders (each with a short dim label), in the same columns
-- on every such row (a slider it lacks leaves its column empty). Never
-- grouped by kind. cfg: text, tooltip, values, order, getValue, setValue
-- (the dropdown), cols = { { label, min, max, getValue, setValue }, ... }.
local POS_LABEL_W, POS_DROP_W, POS_COL_LABEL_W = 132, 176, 34
function W:PosRow(parent, y, cfg)
    local total = parent:GetWidth() - PAD * 2
    local card = Card(parent, y, cfg.text, cfg.tooltip, total, PAD)
    if card.label then
        card.label:SetWidth(POS_LABEL_W)
        card.label:SetJustifyH("LEFT")
        card.label:SetWordWrap(false)
    end
    local x = 14 + POS_LABEL_W + 12
    local dd = DropdownControl(card, POS_DROP_W, cfg.values, cfg.order, cfg.getValue, cfg.setValue)
    dd:SetPoint("LEFT", card, "LEFT", x, 0)
    x = x + POS_DROP_W + 12
    local colW = math.floor((total - x - 12 - 2 * 12) / 3)
    for i = 1, 3 do
        local c = cfg.cols and cfg.cols[i]
        if c then
            local lbl = Kit.RoleFont(card, "label", 12, nil, unpack(C.dim))
            lbl:SetPoint("LEFT", card, "LEFT", x, 0)
            lbl:SetText(c.label or "")
            local s = SliderControl(card, colW - POS_COL_LABEL_W, c.min, c.max, c.step or 1, c.getValue, c.setValue)
            s:SetPoint("LEFT", card, "LEFT", x + POS_COL_LABEL_W, 0)
        end
        x = x + colW + 12
    end
    return card, ROW_H + GAP
end

-- An action: a faint frame, the accent on hover (a button filled with the
-- accent means "chosen": tabs and pills, Kit.MakeTab). b.label, b:SetText,
-- b:SetEnabled dims it.
local function Button(parent, text, width, onClick)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, 34)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(1, 1, 1, 0.05)
    local border = Kit.MakeBorder(b, 1, 1, 1, 0.2)
    local label = Kit.RoleFont(b, "button", 13, nil, unpack(C.text))
    label:SetPoint("CENTER")
    label:SetText(text)
    b.label, b.bg, b.edge = label, bg, border
    -- Primary: the one main action of a screen (Send, Queue them): an accent
    -- frame at rest, no fill (a fill means "chosen", as on tabs and pills).
    local primary = false
    local function Paint(over)
        if not b:IsEnabled() then
            bg:SetColorTexture(1, 1, 1, 0.02)
            border:SetColor(1, 1, 1, 0.12)
            label:SetTextColor(C.dim[1], C.dim[2], C.dim[3], 0.6)
        elseif over then
            bg:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.3)
            border:SetColor(C.accent[1], C.accent[2], C.accent[3], 0.8)
            label:SetTextColor(C.text[1], C.text[2], C.text[3], 1)
        elseif primary then
            bg:SetColorTexture(1, 1, 1, 0.05)
            border:SetColor(C.accent[1], C.accent[2], C.accent[3], 0.85)
            label:SetTextColor(C.text[1], C.text[2], C.text[3], 1)
        else
            bg:SetColorTexture(1, 1, 1, 0.05)
            border:SetColor(1, 1, 1, 0.2)
            label:SetTextColor(C.text[1], C.text[2], C.text[3], 1)
        end
    end
    function b:SetPrimary(on) primary = on and true or false; Paint(b:IsMouseOver()) end
    b:SetScript("OnEnter", function() Paint(true) end)
    b:SetScript("OnLeave", function() Paint(false) end)
    b:SetScript("OnClick", onClick)
    hooksecurefunc(b, "SetEnabled", function() Paint(b:IsMouseOver()) end)
    hooksecurefunc(b, "Enable", function() Paint(b:IsMouseOver()) end)
    hooksecurefunc(b, "Disable", function() Paint(false) end)
    function b:SetText(t) label:SetText(t) end
    function b:GetText() return label:GetText() end
    return b
end
Kit.Button = Button
function Kit.PrimaryButton(parent, text, width, onClick)
    local b = Button(parent, text, width, onClick)
    b:SetPrimary(true)
    return b
end

function W:WideDualButton(parent, text1, text2, y, onClick1, onClick2)
    CloseSection(parent)
    local total = parent:GetWidth() - PAD * 2
    -- Two halves of the row, as a row of two cards (never a row left part empty).
    local half = math.floor((total - GAP) / 2)
    local frame = CreateFrame("Frame", nil, parent)
    -- (as tall as a dropdown: one control height on every page)
    frame:SetSize(total, CONTROL_H)
    frame:SetPoint("TOPLEFT", parent, "TOPLEFT", PAD, y)
    frame.b1 = Button(frame, text1, half, onClick1)
    frame.b1:SetHeight(CONTROL_H)
    frame.b1:SetPoint("LEFT", 0, 0)
    frame.b2 = Button(frame, text2, total - half - GAP, onClick2)
    frame.b2:SetHeight(CONTROL_H)
    frame.b2:SetPoint("LEFT", half + GAP, 0)
    -- (on whole pixels, or a button's 1 px edge drops out on one side)
    C_Timer.After(0, function()
        if Kit.SnapFrame then pcall(Kit.SnapFrame, frame.b1); pcall(Kit.SnapFrame, frame.b2) end
        Kit.QueueRealign()
    end)
    frame.isFooter = true -- (a window may pin it to its bottom)
    return frame, CONTROL_H + GAP
end

-------------------------------------------------------------------------------
--  Window chrome and pill tabs
-------------------------------------------------------------------------------
-- badge: the pill next to the title ("ALPHA" when not given).
function Kit.Chrome(win, title, subtitle, onClose, badgeText)
    local bg = win:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    Kit.PaintBg(bg, C.bg)
    win.chromeBg = bg -- kept so the opacity can change live
    win.chromeEdge = Kit.MakeBorder(win, unpack(Kit.EDGE))
    win.chromeEdge:RoundFill(bg)
    local strip = win:CreateTexture(nil, "ARTWORK")
    strip:SetHeight(3)
    strip:SetPoint("TOPLEFT")
    strip:SetPoint("TOPRIGHT")
    strip:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 1)
    strip:Hide()

    local t = Kit.RoleFont(win, "title", 20, nil, unpack(Kit.accentTitles and C.accent or C.text))
    -- On the close button's line (its middle 31 below the top; one lower for
    -- the letters' descent), at any title size; one padding from the left.
    t:SetPoint("LEFT", win, "TOPLEFT", PAD, -32)
    t:SetText(title)
    local badge = CreateFrame("Frame", nil, win)
    badge:SetSize(48, 18)
    badge:SetPoint("LEFT", t, "RIGHT", 10, 0)
    local bbg = badge:CreateTexture(nil, "BACKGROUND")
    bbg:SetAllPoints()
    bbg:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.2)
    local bt = Kit.MakeFont(badge, 11, nil, C.accent[1], C.accent[2], C.accent[3], 1)
    bt:SetPoint("CENTER")
    bt:SetText(badgeText or "ALPHA")
    badge:SetWidth(math.max(48, bt:GetStringWidth() + 16))
    local sub = Kit.MakeFont(win, 12, nil, unpack(C.dim))
    sub:SetPoint("LEFT", badge, "RIGHT", 10, 0)
    sub:SetText(subtitle)

    -- Close: a boxed X (a dark well, a thin frame; the accent on hover), on
    -- the title's line, the padding from the right edge.
    local close = CreateFrame("Button", nil, win)
    close:SetSize(26, 26)
    close:SetPoint("CENTER", win, "TOPRIGHT", -(PAD + 13), -31)
    local well = close:CreateTexture(nil, "BACKGROUND")
    well:SetAllPoints()
    well:SetColorTexture(0, 0, 0, 0.35)
    local cedge = Kit.MakeBorder(close, 1, 1, 1, 0.2)
    local xi = close:CreateTexture(nil, "ARTWORK")
    xi:SetSize(13, 13)
    xi:SetPoint("CENTER")
    xi:SetTexture(MEDIA .. "x")
    xi:SetVertexColor(C.dim[1], C.dim[2], C.dim[3], 1)
    close:SetScript("OnEnter", function()
        cedge:SetColor(C.accent[1], C.accent[2], C.accent[3], 0.8)
        xi:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1)
    end)
    close:SetScript("OnLeave", function()
        cedge:SetColor(1, 1, 1, 0.2)
        xi:SetVertexColor(C.dim[1], C.dim[2], C.dim[3], 1)
    end)
    close:SetScript("OnClick", onClose)
    return t, badge, sub, close
end

function Kit.MakeTab(win, text)
    local tab = CreateFrame("Button", nil, win)
    tab:SetHeight(24)
    local bg = tab:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    local label = Kit.RoleFont(tab, "tab", 13, nil, unpack(C.dim))
    label:SetPoint("CENTER")
    label:SetText(text)
    -- Width from the text, measured again once the font is ready.
    local function fit() tab:SetWidth(math.max(40, label:GetStringWidth() + 22)) end
    fit()
    C_Timer.After(0, fit)
    local active = false
    function tab:SetActive(on)
        active = on
        if on then
            bg:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.85)
            label:SetTextColor(0.03, 0.07, 0.09)
        else
            bg:SetColorTexture(1, 1, 1, 0.04)
            label:SetTextColor(unpack(C.dim))
        end
    end
    tab:SetScript("OnEnter", function() if not active then bg:SetColorTexture(1, 1, 1, 0.1) end end)
    tab:SetScript("OnLeave", function() if not active then bg:SetColorTexture(1, 1, 1, 0.04) end end)
    tab:SetActive(false)
    return tab
end

Kit.TAB_X = 30       -- tab row starts in line with the cards
Kit.TAB_Y = -56      -- tab row
Kit.CONTENT_Y = -92  -- content top
Kit.SEP = false      -- no rule under the tabs

-------------------------------------------------------------------------------
--  Tooltips and separators
-------------------------------------------------------------------------------
-- A tooltip on a frame: a title and an optional text under it (wrapped).
Kit.SetTooltip = Tooltip

-- The game's tooltip over these windows (names) in this kit's look and at
-- their scale (see Lib.HookTooltip).
-- names: the windows whose tooltips take the kit's look; fonts (optional):
-- fn() -> title size, text size, for windows with text sizes of their own.
function Kit.OwnTooltips(names, fonts)
    for _, n in ipairs(names or {}) do
        Lib.tipWins[n] = Kit
        if fonts then Lib.tipFonts[n] = fonts end
    end
    Lib.HookTooltip()
end

-- A thin line (1 px, the faint white of the kit's rules); placed by the caller.
function Kit.Separator(parent, alpha)
    local t = parent:CreateTexture(nil, "ARTWORK")
    t:SetHeight(1)
    t:SetColorTexture(1, 1, 1, alpha or 0.08)
    return t
end

-------------------------------------------------------------------------------
--  Window: the kit's frame, a fixed size, at the pixel scale (the same with
--  or without a pixel-perfect interface scale), moved by dragging, closed
--  with Escape. The kit keeps no position: o.onMove(point, relPoint, x, y)
--  hands it to the addon, o.position = { point, relPoint, x, y } puts it
--  back. f.content: the area under the header (inside the padding).
--  o: name (needed for Escape), title, subtitle, badge, width, height,
--  strata, onClose, onMove, position, pixelScale (default true), scale.
-------------------------------------------------------------------------------
local scaled = setmetatable({}, { __mode = "k" })
do
    local ev = CreateFrame("Frame")
    ev:RegisterEvent("UI_SCALE_CHANGED")
    ev:RegisterEvent("DISPLAY_SIZE_CHANGED")
    ev:SetScript("OnEvent", function()
        for f in pairs(scaled) do pcall(f.ApplyScale, f) end
    end)
end

function Kit.Window(o)
    o = o or {}
    local f = CreateFrame("Frame", o.name, UIParent)
    f:SetSize(o.width or 600, o.height or 500)
    f:SetFrameStrata(o.strata or "DIALOG")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        Kit.SnapFrame(self)
        Kit.RealignBorders()
        if o.onMove then
            local p, _, rp, x, y = self:GetPoint(1)
            o.onMove(p, rp, x, y)
        end
    end)
    if o.name and o.escape ~= false then tinsert(UISpecialFrames, o.name) end
    -- The game's tooltip over it in this kit's look (every kit window).
    if o.name then Kit.OwnTooltips({ o.name }) end
    -- (a click on it brings it over the other windows of its strata)
    f:SetToplevel(true)
    local title, badge, sub, close = Kit.Chrome(f, o.title or "", o.subtitle or "", o.onClose or function() f:Hide() end, o.badge)
    if not o.badge then
        badge:Hide()
        sub:ClearAllPoints()
        sub:SetPoint("LEFT", title, "RIGHT", 10, 0)
    end
    f.title, f.badge, f.subtitle, f.closeButton = title, badge, sub, close

    -- The pixel scale, kept when the interface scale or the screen changes.
    f.pixelScale = o.pixelScale ~= false
    function f:ApplyScale()
        if not self.pixelScale then self:SetScale(o.scale or 1) return end
        local ue = UIParent:GetEffectiveScale()
        if ue and ue > 0 then self:SetScale(Kit.PixelScale() / ue * (o.scale or 1)) end
        Kit.QueueRealign()
    end
    f:ApplyScale()
    scaled[f] = true

    f:ClearAllPoints()
    local pos = o.position
    if type(pos) == "table" and pos[1] then
        f:SetPoint(pos[1], UIParent, pos[2] or pos[1], pos[3] or 0, pos[4] or 0)
    else
        f:SetPoint("CENTER")
    end

    -- Square buttons with a glyph in the header, right to left from the X.
    function f:AddHeaderButton(icon, tipTitle, tipText, onClick)
        return Kit.HeaderButton(self, icon, tipTitle, tipText, onClick)
    end

    -- The content: under the header, the padding on every side.
    local content = CreateFrame("Frame", nil, f)
    content:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, Kit.TAB_Y)
    content:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -PAD, PAD)
    f.content = content
    f:HookScript("OnShow", function(self)
        self:ApplyScale()
        C_Timer.After(0, Kit.RealignBorders)
    end)
    Kit.TipsGoWith(f)
    -- A window shows when asked: built shown, a toggle's first click would hide it.
    f:Hide()
    return f
end

-- A square button with a glyph in a window's header, right to left from its
-- X (win.closeButton; a window from Kit.Chrome sets it from the X it got).
-- Kit.ICON_WHATSNEW: the glyph for What's New.
Kit.ICON_WHATSNEW = MEDIA .. "sparkles"
function Kit.HeaderButton(win, icon, tipTitle, tipText, onClick)
    do
        local self = win
        local close = win.closeButton
        win.__heads = win.__heads or {}
        local heads = win.__heads
        local b = CreateFrame("Button", nil, self)
        b:SetSize(24, 24)
        local anchor = heads[#heads] or close
        b:SetPoint("RIGHT", anchor, "LEFT", -6, 0)
        local well = b:CreateTexture(nil, "BACKGROUND")
        well:SetAllPoints()
        well:SetColorTexture(0, 0, 0, 0.35)
        local edge = Kit.MakeBorder(b, 1, 1, 1, 0.25)
        local t = b:CreateTexture(nil, "ARTWORK")
        t:SetSize(14, 14)
        t:SetPoint("CENTER")
        t:SetTexture(icon)
        t:SetVertexColor(C.dim[1], C.dim[2], C.dim[3], 1)
        b.icon, b.edge = t, edge
        b:SetScript("OnEnter", function(selfb)
            edge:SetColor(C.accent[1], C.accent[2], C.accent[3], 0.8)
            t:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1)
            if tipTitle then
                GameTooltip:SetOwner(selfb, "ANCHOR_BOTTOM")
                GameTooltip:AddLine(tipTitle, 1, 1, 1)
                -- (wrapped only when long: the kit's one tooltip rule)
                if tipText then Kit.AddTooltipLine(GameTooltip, tipText, 0.7, 0.7, 0.7) end
                GameTooltip:Show()
            end
        end)
        b:SetScript("OnLeave", function()
            edge:SetColor(1, 1, 1, 0.25)
            t:SetVertexColor(C.dim[1], C.dim[2], C.dim[3], 1)
            GameTooltip:Hide()
        end)
        b:SetScript("OnClick", onClick)
        heads[#heads + 1] = b
        return b
    end
end

-- Any frame of an addon at the pixel scale (as Kit.Window's), kept on
-- interface scale or screen changes and on each showing. extra: a factor
-- on top (the addon's own window scale), or a function returning one.
function Kit.UsePixelScale(f, extra)
    function f:ApplyScale()
        local x = type(extra) == "function" and extra() or extra or 1
        local ue = UIParent:GetEffectiveScale()
        if ue and ue > 0 then self:SetScale(Kit.PixelScale() / ue * x) end
        Kit.QueueRealign()
    end
    scaled[f] = true
    f:ApplyScale()
    f:HookScript("OnShow", function(self) self:ApplyScale() end)
end

-------------------------------------------------------------------------------
--  Scroll area: a clipped view over a child (sa.child) that scrolls with the
--  wheel, a thin accent thumb on the right while the child is taller than
--  the view. sa:SetContentHeight(h) after the child is filled.
-------------------------------------------------------------------------------
function Kit.ScrollArea(parent, step)
    local sa = CreateFrame("ScrollFrame", nil, parent)
    local child = CreateFrame("Frame", nil, sa)
    child:SetSize(1, 1)
    sa:SetScrollChild(child)
    sa.child = child
    local thumb = sa:CreateTexture(nil, "OVERLAY")
    thumb:SetWidth(2)
    thumb:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.5)
    thumb:Hide()
    local function Max() return math.max(0, (child:GetHeight() or 0) - (sa:GetHeight() or 0)) end
    local function PaintThumb()
        local view, full = sa:GetHeight() or 0, child:GetHeight() or 0
        if full <= view + 0.5 or view <= 0 then thumb:Hide() return end
        local h = math.max(16, view * view / full)
        local y = (view - h) * (sa:GetVerticalScroll() / math.max(1, full - view))
        thumb:ClearAllPoints()
        thumb:SetPoint("TOPRIGHT", sa, "TOPRIGHT", 0, -y)
        thumb:SetHeight(h)
        thumb:Show()
    end
    function sa:ScrollTo(v)
        self:SetVerticalScroll(math.max(0, math.min(Max(), v or 0)))
        PaintThumb()
        Kit.QueueRealign()
    end
    function sa:SetContentHeight(h)
        child:SetHeight(math.max(1, h or 1))
        self:ScrollTo(self:GetVerticalScroll())
    end
    sa:EnableMouseWheel(true)
    sa:SetScript("OnMouseWheel", function(self, delta) self:ScrollTo(self:GetVerticalScroll() - delta * (step or 40)) end)
    sa:SetScript("OnSizeChanged", function(self, w)
        if w and w > 0 then child:SetWidth(w) end
        self:ScrollTo(self:GetVerticalScroll())
    end)
    return sa
end

-------------------------------------------------------------------------------
--  Icon square: a picture in a 1 px frame, a count at its foot, a selected
--  state in the accent. IconSquare for any picture (spell, achievement,
--  profession); ItemIcon adds an item's picture, quality frame and tooltip.
-------------------------------------------------------------------------------
Kit.ICON_XS, Kit.ICON_S, Kit.ICON_M, Kit.ICON_L, Kit.ICON_XL = 16, 20, 32, 40, 48
function Kit.IconSquare(parent, size)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(size or 32, size or 32)
    local well = b:CreateTexture(nil, "BACKGROUND")
    well:SetAllPoints()
    well:SetColorTexture(0, 0, 0, 0.45)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetPoint("TOPLEFT", 1, -1)
    icon:SetPoint("BOTTOMRIGHT", -1, 1)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    local edge = Kit.MakeBorder(b, 1, 1, 1, 0.2)
    edge.noRound = true
    local count = Kit.MakeFont(b, math.max(9, math.floor((size or 32) / 3.2)), "OUTLINE", 1, 1, 1, 1)
    count:SetPoint("BOTTOMRIGHT", -2, 2)
    b.icon, b.edge, b.count = icon, edge, count
    local frameColor = { 1, 1, 1, 0.2 }
    local selected = false
    local function PaintEdge()
        if selected then edge:SetColor(C.accent[1], C.accent[2], C.accent[3], 1)
        else edge:SetColor(frameColor[1], frameColor[2], frameColor[3], frameColor[4]) end
    end
    function b:SetIcon(tex) icon:SetTexture(tex) end
    function b:SetCount(n)
        n = tonumber(n)
        count:SetText((n and n > 1) and n or "")
    end
    function b:SetBorderColor(r, g, bb, a)
        frameColor[1], frameColor[2], frameColor[3], frameColor[4] = r or 1, g or 1, bb or 1, a or 1
        PaintEdge()
    end
    function b:SetSelected(on) selected = on and true or false; PaintEdge() end
    function b:SetDesaturated(on) icon:SetDesaturated(on and true or false) end
    -- b.onTooltip(self): fill GameTooltip (owner set); nil: none.
    b:SetScript("OnEnter", function(self)
        if not selected then edge:SetColor(C.accent[1], C.accent[2], C.accent[3], 0.8) end
        if self.onTooltip then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            local ok = pcall(self.onTooltip, self)
            if ok then GameTooltip:Show() else GameTooltip:Hide() end
        end
    end)
    b:SetScript("OnLeave", function() PaintEdge(); GameTooltip:Hide() end)
    return b
end

local function Secret(v) return issecretvalue and issecretvalue(v) end
function Kit.ItemIcon(parent, size)
    local b = Kit.IconSquare(parent, size)
    -- item: an item ID or link (nil empties it); count: the stack.
    function b:SetItem(item, n)
        self.item = item
        self:SetCount(n)
        if not item or Secret(item) then
            self:SetIcon(nil)
            self:SetBorderColor(1, 1, 1, 0.2)
            return
        end
        local tex = (C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(item)) or (GetItemIcon and GetItemIcon(item))
        self:SetIcon(tex)
        local quality = select(3, (C_Item and C_Item.GetItemInfo or GetItemInfo)(item))
        if type(quality) == "number" and not Secret(quality) and quality >= 2 then
            local r, g, bb = 1, 1, 1
            if C_Item and C_Item.GetItemQualityColor then r, g, bb = C_Item.GetItemQualityColor(quality)
            elseif ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality] then
                local q = ITEM_QUALITY_COLORS[quality]
                r, g, bb = q.r, q.g, q.b
            end
            self:SetBorderColor(r, g, bb, 0.9)
        else
            self:SetBorderColor(1, 1, 1, 0.2)
        end
    end
    b.onTooltip = function(self)
        local item = self.item
        if not item then error("no item") end
        if type(item) == "string" and item:find("|H") then GameTooltip:SetHyperlink(item)
        else GameTooltip:SetItemByID(item) end
    end
    return b
end

-------------------------------------------------------------------------------
--  Progress bar: a track and a fill (the bar texture of the look), up to
--  three texts (left, centre, right: on the bar when it is 14 tall or more,
--  over it otherwise) and an optional leading icon. Colours: "accent",
--  "success", "warning", "danger", "neutral" or r, g, b.
--  bar:SetMinMax(lo, hi) / SetValue(v) / SetProgress(0..1)
--  bar:SetDuration(start, duration, onDone): fills (or empties, o.drain)
--  over time; the right text shows the time left when o.timeText.
-------------------------------------------------------------------------------
local TONES = {
    success = { 0.35, 0.80, 0.40 }, warning = { 1.00, 0.62, 0.20 },
    danger = { 0.92, 0.28, 0.26 }, neutral = { 0.62, 0.66, 0.70 },
}
Kit.BAR_TEXTURE = "Interface\\Buttons\\WHITE8X8"
local function Clock(s)
    s = math.max(0, math.floor(s + 0.5))
    if s >= 3600 then return ("%d:%02d:%02d"):format(s / 3600, (s % 3600) / 60, s % 60) end
    return ("%d:%02d"):format(s / 60, s % 60)
end
Kit.Clock = Clock
function Kit.ProgressBar(parent, o)
    o = o or {}
    local holder = CreateFrame("Frame", nil, parent)
    holder:SetSize(o.width or 200, o.height or 6)
    local bar = CreateFrame("Frame", nil, holder)
    bar:SetPoint("TOPLEFT")
    bar:SetPoint("BOTTOMRIGHT")
    local track = bar:CreateTexture(nil, "BACKGROUND")
    track:SetAllPoints()
    track:SetColorTexture(1, 1, 1, 0.08)
    local fill = bar:CreateTexture(nil, "ARTWORK")
    fill:SetPoint("TOPLEFT")
    fill:SetPoint("BOTTOMLEFT")
    fill:SetTexture(o.texture or Kit.BAR_TEXTURE)
    fill:SetWidth(1)
    if o.border then Kit.MakeBorder(bar, 1, 1, 1, 0.15) end
    holder.bar, holder.fill, holder.track = bar, fill, track
    local inside = (o.height or 6) >= 14
    local texts = {}
    for i, side in ipairs({ "LEFT", "CENTER", "RIGHT" }) do
        local fs = Kit.MakeFont(holder, o.fontSize or 11, inside and "OUTLINE" or nil, C.text[1], C.text[2], C.text[3], 1)
        if inside then fs:SetPoint(side, bar, side, side == "LEFT" and 6 or (side == "RIGHT" and -6 or 0), 0)
        else fs:SetPoint("BOTTOM" .. (side == "CENTER" and "" or side), bar, "TOP" .. (side == "CENTER" and "" or side), 0, 3) end
        texts[i] = fs
    end
    holder.texts = texts
    local lo, hi, frac = 0, 1, 0
    local function Paint()
        local w = bar:GetWidth() or 0
        fill:SetWidth(math.max(1, w * frac))
        fill:SetShown(frac > 0)
    end
    bar:SetScript("OnSizeChanged", Paint)
    function holder:SetColor(r, g, b, a)
        if type(r) == "string" then
            local t = r == "accent" and C.accent or TONES[r] or C.accent
            r, g, b = t[1], t[2], t[3]
        end
        fill:SetVertexColor(r or 1, g or 1, b or 1, a or 1)
    end
    function holder:SetProgress(f)
        frac = math.max(0, math.min(1, tonumber(f) or 0))
        Paint()
    end
    function holder:SetMinMax(a, b) lo, hi = a or 0, b or 1 end
    function holder:SetValue(v)
        v = tonumber(v) or lo
        self:SetProgress((v - lo) / math.max(1e-9, hi - lo))
    end
    function holder:SetText(l, c, r)
        texts[1]:SetText(l or "")
        texts[2]:SetText(c or "")
        texts[3]:SetText(r or "")
    end
    -- A leading picture left of the bar (the bar starts after it).
    function holder:SetIcon(tex, size)
        if not self.icon then
            self.icon = Kit.IconSquare(holder, size or math.max(16, (o.height or 6) + 10))
            self.icon:EnableMouse(false)
        end
        local s = self.icon:GetWidth()
        self.icon:ClearAllPoints()
        self.icon:SetPoint("LEFT", holder, "LEFT", 0, 0)
        bar:ClearAllPoints()
        bar:SetPoint("TOPLEFT", holder, "TOPLEFT", s + 6, 0)
        bar:SetPoint("BOTTOMRIGHT")
        self.icon:SetIcon(tex)
        self.icon:SetShown(tex ~= nil)
    end
    -- Over time (OnUpdate only while it runs).
    function holder:SetDuration(start, duration, onDone)
        self.start, self.duration, self.onDone = start or GetTime(), duration or 0, onDone
        if self.duration <= 0 then self:Stop() return end
        self:SetScript("OnUpdate", function(selfh)
            local t = (GetTime() - selfh.start) / selfh.duration
            if t >= 1 then
                selfh:SetProgress(o.drain and 0 or 1)
                if o.timeText then texts[3]:SetText(Clock(0)) end
                local done = selfh.onDone
                selfh:Stop()
                if done then pcall(done) end
                return
            end
            selfh:SetProgress(o.drain and (1 - t) or t)
            if o.timeText then texts[3]:SetText(Clock(selfh.duration * (1 - t))) end
        end)
    end
    function holder:Stop() self:SetScript("OnUpdate", nil) end
    holder:SetColor(o.color or "accent")
    holder:SetProgress(0)
    return holder
end

-------------------------------------------------------------------------------
--  Search box: a text box with a hint, a clear X while it holds text, and
--  onChange(text) a moment after typing stops (o.delay, 0.15 s).
-------------------------------------------------------------------------------
function Kit.SearchBox(parent, width, hint, onChange, delay)
    local eb = InputControl(parent, width, hint, nil)
    eb:SetMaxLetters(80)
    eb:SetTextInsets(10, 26, 0, 0)
    local x = CreateFrame("Button", nil, eb)
    x:SetSize(16, 16)
    x:SetPoint("RIGHT", -6, 0)
    local xt = x:CreateTexture(nil, "ARTWORK")
    xt:SetAllPoints()
    xt:SetTexture(MEDIA .. "x")
    xt:SetVertexColor(C.dim[1], C.dim[2], C.dim[3], 1)
    x:SetScript("OnEnter", function() xt:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1) end)
    x:SetScript("OnLeave", function() xt:SetVertexColor(C.dim[1], C.dim[2], C.dim[3], 1) end)
    x:Hide()
    local token = 0
    local base = eb:GetScript("OnTextChanged")
    eb:SetScript("OnTextChanged", function(self, user)
        if base then base(self, user) end
        x:SetShown(self:GetText() ~= "")
        token = token + 1
        local mine = token
        C_Timer.After(delay or 0.15, function()
            if mine == token and onChange then onChange(self:GetText()) end
        end)
    end)
    x:SetScript("OnClick", function() eb:SetText(""); eb:ClearFocus() end)
    eb:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    eb.clear = x
    return eb
end

-------------------------------------------------------------------------------
--  Empty state: a centred line (and a dim second one) for a list with
--  nothing in it. es:SetText(text, sub).
-------------------------------------------------------------------------------
function Kit.EmptyState(parent)
    local es = CreateFrame("Frame", nil, parent)
    es:SetSize(10, 40)
    local t = Kit.MakeFont(es, 13, nil, C.text[1], C.text[2], C.text[3], 0.55)
    t:SetPoint("TOPLEFT")
    t:SetPoint("TOPRIGHT")
    t:SetJustifyH("CENTER")
    t:SetWordWrap(true)
    local s = Kit.MakeFont(es, 12, nil, C.dim[1], C.dim[2], C.dim[3], 0.8)
    s:SetPoint("TOPLEFT", t, "BOTTOMLEFT", 0, -4)
    s:SetPoint("TOPRIGHT", t, "BOTTOMRIGHT", 0, -4)
    s:SetJustifyH("CENTER")
    s:SetWordWrap(true)
    function es:SetText(text, sub)
        t:SetText(text or "")
        s:SetText(sub or "")
        s:SetShown(sub ~= nil and sub ~= "")
    end
    es:Hide()
    return es
end

-------------------------------------------------------------------------------
--  Confirm: a question in the kit's look over everything, Yes / No (Escape
--  is No). One at a time; a new one replaces an open one (its No not run).
-------------------------------------------------------------------------------
local confirm
-- opts (or the yes and no labels, as before): title, yes, no, anchor (a
-- frame to stand over the middle of; the screen's when none or hidden).
function Kit.Confirm(text, onYes, onNo, a, b)
    local o = type(a) == "table" and a or { yes = a, no = b }
    if not confirm then
        local name = "SoLWidgetsConfirm" .. tostring(owner):gsub("[^%w]", "")
        confirm = Kit.Window({ name = name, width = 360, height = 150, strata = "FULLSCREEN_DIALOG",
                               title = "", onClose = function() confirm.Answer(false) end })
        confirm.closeButton:Hide()
        confirm.head = Kit.MakeFont(confirm, 15, nil, C.text[1], C.text[2], C.text[3], 1)
        confirm.head:SetPoint("TOPLEFT", PAD, -PAD)
        confirm.head:SetPoint("TOPRIGHT", -PAD, -PAD)
        confirm.head:SetJustifyH("LEFT")
        confirm.text = Kit.MakeFont(confirm, 13, nil, C.dim[1], C.dim[2], C.dim[3], 1)
        confirm.text:SetJustifyH("LEFT")
        confirm.text:SetWordWrap(true)
        confirm.text:SetSpacing(3)
        -- No on the left, Yes (the answer asked for) at the end.
        confirm.yes = Button(confirm, "Yes", 96, function() confirm.Answer(true) end)
        confirm.yes:SetHeight(26)
        confirm.yes:SetPoint("BOTTOMRIGHT", -PAD, PAD)
        confirm.no = Button(confirm, "No", 96, function() confirm.Answer(false) end)
        confirm.no:SetHeight(26)
        confirm.no:SetPoint("RIGHT", confirm.yes, "LEFT", -8, 0)
        function confirm.Answer(yes)
            local cb = yes and confirm.onYes or confirm.onNo
            confirm.onYes, confirm.onNo = nil, nil
            confirm:Hide()
            if cb then pcall(cb) end
        end
        confirm:SetScript("OnHide", function()
            -- (Escape: No.)
            if confirm.onNo or confirm.onYes then
                local cb = confirm.onNo
                confirm.onYes, confirm.onNo = nil, nil
                if cb then pcall(cb) end
            end
        end)
    end
    confirm.onYes, confirm.onNo = onYes, onNo
    local hasHead = o.title ~= nil and o.title ~= ""
    confirm.head:SetText(o.title or "")
    confirm.head:SetShown(hasHead)
    confirm.text:ClearAllPoints()
    if hasHead then
        confirm.text:SetPoint("TOPLEFT", confirm.head, "BOTTOMLEFT", 0, -8)
        confirm.text:SetPoint("TOPRIGHT", confirm.head, "BOTTOMRIGHT", 0, -8)
    else
        confirm.text:SetPoint("TOPLEFT", PAD, -PAD)
        confirm.text:SetPoint("TOPRIGHT", -PAD, -PAD)
    end
    confirm.text:SetText(text or "")
    confirm.yes:SetText(o.yes or YES or "Yes")
    confirm.no:SetText(o.no or NO or "No")
    local h = math.ceil(confirm.text:GetStringHeight() or 20) + (hasHead and (math.ceil(confirm.head:GetStringHeight() or 16) + 8) or 0)
    confirm:SetHeight(math.max(100, PAD + h + 20 + 26 + PAD))
    confirm:ClearAllPoints()
    local an = o.anchor
    if an and an.IsShown and an:IsShown() then confirm:SetPoint("CENTER", an, "CENTER", 0, 0)
    else confirm:SetPoint("CENTER", UIParent, "CENTER", 0, 120) end
    confirm:Show()
    if confirm.Raise then confirm:Raise() end
end

-------------------------------------------------------------------------------
--  Prompt: a question with a line of text to type, in the kit's look over
--  everything; OK (or Enter) gives the text, Cancel (or Escape) nothing.
--  opts: title, ok, cancel, anchor (as Confirm).
-------------------------------------------------------------------------------
local prompt
function Kit.Prompt(text, init, onOk, opts)
    opts = opts or {}
    if not prompt then
        local name = "SoLWidgetsPrompt" .. tostring(owner):gsub("[^%w]", "")
        prompt = Kit.Window({ name = name, width = 380, height = 170, strata = "FULLSCREEN_DIALOG",
                              title = "", onClose = function() prompt:Hide() end })
        prompt.closeButton:Hide()
        prompt.text = Kit.MakeFont(prompt, 13, nil, C.text[1], C.text[2], C.text[3], 1)
        prompt.text:SetPoint("TOPLEFT", PAD, -PAD)
        prompt.text:SetPoint("TOPRIGHT", -PAD, -PAD)
        prompt.text:SetJustifyH("LEFT")
        prompt.text:SetWordWrap(true)
        local box = CreateFrame("EditBox", nil, prompt)
        box:SetHeight(26)
        box:SetAutoFocus(false)
        box:SetFontObject(ChatFontNormal)
        box:SetTextInsets(8, 8, 0, 0)
        local bg = box:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0, 0, 0, 0.35)
        local ring = Kit.MakeBorder(box, 1, 1, 1, 0.2)
        box:SetScript("OnEditFocusGained", function() ring:SetColor(C.accent[1], C.accent[2], C.accent[3], 0.8) end)
        box:SetScript("OnEditFocusLost", function() ring:SetColor(1, 1, 1, 0.2) end)
        prompt.box = box
        prompt.ok = Button(prompt, "OK", 96, function() prompt.Answer(true) end)
        prompt.ok:SetPrimary(true)
        prompt.ok:SetHeight(26)
        prompt.ok:SetPoint("BOTTOMRIGHT", -PAD, PAD)
        prompt.cancel = Button(prompt, "Cancel", 96, function() prompt.Answer(false) end)
        prompt.cancel:SetHeight(26)
        prompt.cancel:SetPoint("RIGHT", prompt.ok, "LEFT", -8, 0)
        box:SetScript("OnEnterPressed", function() prompt.Answer(true) end)
        box:SetScript("OnEscapePressed", function() prompt.Answer(false) end)
        function prompt.Answer(ok)
            local cb, value = prompt.onOk, box:GetText() or ""
            prompt.onOk = nil
            box:ClearFocus()
            prompt:Hide()
            if ok and cb then pcall(cb, value) end
        end
    end
    prompt.onOk = onOk
    prompt.text:SetText(text or "")
    prompt.ok:SetText(opts.ok or OKAY or "OK")
    prompt.cancel:SetText(opts.cancel or CANCEL or "Cancel")
    local th = math.ceil(prompt.text:GetStringHeight() or 16)
    prompt.box:ClearAllPoints()
    prompt.box:SetPoint("TOPLEFT", prompt.text, "BOTTOMLEFT", 0, -12)
    prompt.box:SetPoint("TOPRIGHT", prompt.text, "BOTTOMRIGHT", 0, -12)
    prompt:SetHeight(PAD + th + 12 + 26 + 20 + 26 + PAD)
    prompt.box:SetText(init or "")
    prompt:ClearAllPoints()
    local an = opts.anchor
    if an and an.IsShown and an:IsShown() then prompt:SetPoint("CENTER", an, "CENTER", 0, 0)
    else prompt:SetPoint("CENTER", UIParent, "CENTER", 0, 120) end
    prompt:Show()
    if prompt.Raise then prompt:Raise() end
    prompt.box:SetFocus()
    prompt.box:HighlightText()
end

-------------------------------------------------------------------------------
--  Copy window: text in a box to copy (Ctrl+A, Ctrl+C), selected when shown.
-------------------------------------------------------------------------------
local copy
function Kit.CopyWindow(title, text)
    if not copy then
        local name = "SoLWidgetsCopy" .. tostring(owner):gsub("[^%w]", "")
        copy = Kit.Window({ name = name, width = 620, height = 400, strata = "FULLSCREEN_DIALOG",
                            title = title or "", subtitle = "Ctrl+A, Ctrl+C" })
        local sa = Kit.ScrollArea(copy.content)
        sa:SetAllPoints()
        local well = copy.content:CreateTexture(nil, "BACKGROUND")
        well:SetAllPoints()
        well:SetColorTexture(0, 0, 0, 0.35)
        local eb = CreateFrame("EditBox", nil, sa.child)
        eb:SetMultiLine(true)
        eb:SetAutoFocus(false)
        eb:SetMaxLetters(0)
        eb:SetFont(Kit.FONT, 11, "")
        eb:SetTextColor(C.text[1], C.text[2], C.text[3])
        eb:SetPoint("TOPLEFT", 6, -6)
        eb:SetPoint("TOPRIGHT", -10, -6)
        eb:SetScript("OnEscapePressed", function() copy:Hide() end)
        eb:SetScript("OnTextChanged", function(self)
            C_Timer.After(0, function() sa:SetContentHeight((self:GetHeight() or 0) + 12) end)
        end)
        copy.eb, copy.sa = eb, sa
    end
    copy.title:SetText(title or "")
    copy:Show()
    copy.eb:SetText(text or "")
    copy.eb:SetFocus()
    copy.eb:HighlightText()
    copy.sa:ScrollTo(0)
end

-------------------------------------------------------------------------------
--  Context menu: the kit's own (the look, the pixel scale and one padding
--  everywhere). The same build calls as the game's
--  MenuUtil, so a menu moves over by its first line only:
--      Kit.ContextMenu(owner, function(menu, root)
--          root:CreateTitle("Sort")
--          local sub = root:CreateButton("Filters")      -- items in it: a submenu
--          sub:CreateCheckbox("Unread", isOn, toggle)    -- stays open, menu rebuilt
--          root:CreateRadio("Newest", isOn, pick)        -- closes
--          root:CreateDivider()
--          root:CreateButton("Clear", onClick):SetEnabled(false)
--      end)
--  Callbacks get no arguments. Escape or a click elsewhere closes it.
-------------------------------------------------------------------------------
local MENU_PAD, MENU_ROW, MENU_DIV = 8, 22, 9
local Desc = {}
Desc.__index = Desc
local function NewDesc(kind, text) return setmetatable({ kind = kind, text = text, items = {}, enabled = true }, Desc) end
function Desc:Add(d) self.items[#self.items + 1] = d return d end
function Desc:CreateButton(text, onClick) local d = self:Add(NewDesc("button", text)); d.onClick = onClick; return d end
function Desc:CreateCheckbox(text, isOn, toggle) local d = self:Add(NewDesc("check", text)); d.isOn, d.onClick = isOn, toggle; return d end
function Desc:CreateRadio(text, isOn, pick) local d = self:Add(NewDesc("radio", text)); d.isOn, d.onClick = isOn, pick; return d end
function Desc:CreateTitle(text) return self:Add(NewDesc("title", text)) end
function Desc:CreateDivider() return self:Add(NewDesc("divider")) end
function Desc:SetEnabled(on) self.enabled = on and true or false end
function Desc:SetTooltip(fn) self.tooltip = fn end

local menuState = { levels = {}, owner = nil, build = nil, path = {} }
local levelPool = {}
local CloseMenu

local function MenuLevel(i)
    local f = levelPool[i]
    if f then return f end
    f = CreateFrame("Frame", i == 1 and ("SoLWidgetsMenu" .. tostring(owner):gsub("[^%w]", "")) or nil, UIParent)
    f:SetFrameStrata("FULLSCREEN_DIALOG")
    f:SetFrameLevel(10 + i * 5)
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    Kit.PaintBg(bg, C.bg, 0.98)
    Kit.MakeBorder(f, unpack(Kit.EDGE)):RoundFill(bg)
    Kit.UsePixelScale(f)
    f.rows = {}
    if i == 1 then
        tinsert(UISpecialFrames, f:GetName())
        f:SetScript("OnHide", function() if menuState.levels[1] then CloseMenu() end end)
    end
    f:Hide()
    levelPool[i] = f
    return f
end

local function MenuRow(f, n)
    local r = f.rows[n]
    if r then return r end
    r = CreateFrame("Button", nil, f)
    r:SetHeight(MENU_ROW)
    r.hover = r:CreateTexture(nil, "BACKGROUND")
    r.hover:SetAllPoints()
    r.hover:Hide()
    r.box = CreateFrame("Frame", nil, r)
    r.box:SetSize(12, 12)
    r.box:SetPoint("LEFT", 0, 0)
    local well = r.box:CreateTexture(nil, "BACKGROUND")
    well:SetAllPoints()
    well:SetColorTexture(0, 0, 0, 0.5)
    r.box.ring = Kit.MakeBorder(r.box, 1, 1, 1, 0.35)
    r.box.ring.noRound = true
    r.box.tick = r.box:CreateTexture(nil, "OVERLAY")
    r.box.tick:SetPoint("TOPLEFT", 3, -3)
    r.box.tick:SetPoint("BOTTOMRIGHT", -3, 3)
    r.label = Kit.MakeFont(r, 12, nil, C.text[1], C.text[2], C.text[3], 1)
    r.label:SetJustifyH("LEFT")
    r.label:SetWordWrap(false)
    r.arrow = r:CreateTexture(nil, "OVERLAY")
    r.arrow:SetSize(10, 10)
    r.arrow:SetPoint("RIGHT", 0, 0)
    r.arrow:SetTexture(MEDIA .. "chevron_right")
    r.line = r:CreateTexture(nil, "ARTWORK")
    r.line:SetHeight(1)
    r.line:SetPoint("LEFT", 0, 0)
    r.line:SetPoint("RIGHT", 0, 0)
    r.line:SetColorTexture(1, 1, 1, 0.12)
    f.rows[n] = r
    return r
end

local RenderLevel
local function CloseFrom(i)
    for k = #menuState.levels, i, -1 do
        local f = menuState.levels[k]
        menuState.levels[k] = nil
        menuState.path[k] = nil
        if f then f:Hide() end
    end
end

CloseMenu = function()
    local levels = menuState.levels
    menuState.levels = {}
    menuState.path = {}
    menuState.build, menuState.owner = nil, nil
    for k = #levels, 1, -1 do levels[k]:Hide() end
end
Kit.CloseMenu = CloseMenu

local function Rebuild()
    if not menuState.build then return end
    local root = NewDesc("root")
    local ok, err = pcall(menuState.build, nil, root)
    if not ok then geterrorhandler()(err) return end
    menuState.root = root
    -- The open levels again, along the same path.
    local d = root
    for i = 1, #menuState.levels do
        RenderLevel(i, d, menuState.levels[i].anchor)
        local k = menuState.path[i]
        d = k and d.items[k]
        if not (d and #d.items > 0) then CloseFrom(i + 1) break end
    end
end

RenderLevel = function(i, desc, anchor)
    local f = MenuLevel(i)
    f.anchor = anchor
    f.desc = desc
    menuState.levels[i] = f
    local ar, ag, ab = C.accent[1], C.accent[2], C.accent[3]
    local y, widest, anyBox, anySub = -MENU_PAD, 0, false, false
    for _, d in ipairs(desc.items) do
        if d.kind == "check" or d.kind == "radio" then anyBox = true end
        if #d.items > 0 then anySub = true end
    end
    local textX = anyBox and (12 + 8) or 0
    for n, d in ipairs(desc.items) do
        local r = MenuRow(f, n)
        r:Show()
        r:ClearAllPoints()
        local h = d.kind == "divider" and MENU_DIV or MENU_ROW
        r:SetHeight(h)
        r:SetPoint("TOPLEFT", f, "TOPLEFT", MENU_PAD, y)
        r:SetPoint("RIGHT", f, "RIGHT", -MENU_PAD, 0)
        y = y - h
        r.line:SetShown(d.kind == "divider")
        r.label:SetShown(d.kind ~= "divider")
        r.label:ClearAllPoints()
        r.label:SetPoint("LEFT", r, "LEFT", textX, 0)
        r.label:SetText(d.text or "")
        local sub = #d.items > 0
        r.arrow:SetShown(sub)
        r.arrow:SetVertexColor(C.dim[1], C.dim[2], C.dim[3], 1)
        local boxed = d.kind == "check" or d.kind == "radio"
        r.box:SetShown(boxed)
        local on = false
        if boxed and d.isOn then
            local okOn, v = pcall(d.isOn)
            on = okOn and v and true or false
        end
        if boxed then
            r.box.tick:SetColorTexture(ar, ag, ab, 1)
            r.box.tick:SetShown(on)
            if on then r.box.ring:SetColor(ar, ag, ab, 1) else r.box.ring:SetColor(1, 1, 1, 0.35) end
        end
        local live = d.enabled and d.kind ~= "title" and d.kind ~= "divider"
        if d.kind == "title" then r.label:SetTextColor(C.dim[1], C.dim[2], C.dim[3], 1)
        elseif not d.enabled then r.label:SetTextColor(C.dim[1], C.dim[2], C.dim[3], 0.5)
        else r.label:SetTextColor(C.text[1], C.text[2], C.text[3], 1) end
        r.hover:SetColorTexture(ar, ag, ab, 0.14)
        r.hover:ClearAllPoints()
        r.hover:SetPoint("TOPLEFT", r, "TOPLEFT", -MENU_PAD + 1, 0)
        r.hover:SetPoint("BOTTOMRIGHT", r, "BOTTOMRIGHT", MENU_PAD - 1, 0)
        r.hover:Hide()
        if d.kind ~= "divider" then
            widest = math.max(widest, textX + math.ceil(r.label:GetStringWidth() or 0) + (sub and (12 + 10) or 0))
        end
        r:EnableMouse(true)
        r:SetScript("OnEnter", function(self)
            if live then self.hover:Show() end
            -- Its submenu open (any deeper one closed).
            CloseFrom(i + 1)
            if live and sub then
                menuState.path[i] = n
                RenderLevel(i + 1, d, self)
            end
            if d.tooltip then
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                pcall(d.tooltip, GameTooltip)
                GameTooltip:Show()
            end
        end)
        r:SetScript("OnLeave", function(self) self.hover:Hide(); if d.tooltip then GameTooltip:Hide() end end)
        r:SetScript("OnClick", function()
            if not live or sub then return end
            if d.kind == "check" then
                if d.onClick then pcall(d.onClick) end
                Rebuild() -- (stays open: the labels and boxes as they are now)
                return
            end
            CloseMenu()
            if d.onClick then
                local okC, err = pcall(d.onClick)
                if not okC then geterrorhandler()(err) end
            end
        end)
    end
    for n = #desc.items + 1, #f.rows do f.rows[n]:Hide() end
    f:SetSize(math.max(i == 1 and 120 or 100, widest + MENU_PAD * 2), -y + MENU_PAD)
    f:ClearAllPoints()
    if i == 1 then
        f:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
    else
        f:SetPoint("TOPLEFT", anchor, "TOPRIGHT", MENU_PAD + 2, MENU_PAD)
    end
    f:Show()
    C_Timer.After(0, Kit.RealignBorders)
end

-- A click outside every open level closes the menu (checked only while one
-- is open).
local watcher = CreateFrame("Frame")
watcher:Hide()
watcher:SetScript("OnUpdate", function(self)
    if not menuState.levels[1] then self:Hide() return end
    if IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton") then
        for _, f in ipairs(menuState.levels) do if f:IsMouseOver() then return end end
        if menuState.owner and menuState.owner.IsMouseOver and menuState.owner:IsMouseOver() then return end
        CloseMenu()
    end
end)

function Kit.ContextMenu(ownerFrame, build)
    -- The same owner again: closes it (a second click on the button).
    if menuState.levels[1] and menuState.owner == ownerFrame then CloseMenu() return end
    CloseMenu()
    menuState.owner, menuState.build = ownerFrame, build
    local root = NewDesc("root")
    local ok, err = pcall(build, nil, root)
    if not ok then geterrorhandler()(err) return end
    if #root.items == 0 then return end
    RenderLevel(1, root, ownerFrame)
    watcher:Show()
end

-------------------------------------------------------------------------------
--  Progress toasts: the picture in a
--  well ringed in the toast's colour, the head in that colour over the
--  text, a line round it, a shine across once; up to Kit.toastMax at a
--  time, the oldest on top, under the top of the screen. OnUpdate only
--  while one shows (a hidden frame runs none).
--  Kit.Toast(title, text, col, icon, sound): col { r, g, b } or the accent;
--  sound a sound kit ID (or nil: none).
--  Settings on the kit: toastHold (s), toastMax, toastScale, toastY.
-------------------------------------------------------------------------------
local W_TOAST, H_TOAST, FADE, TOAST_GAP = 340, 64, 0.5, 6
Kit.toastHold, Kit.toastMax, Kit.toastScale, Kit.toastY = 4, 3, 1, 140
local toastList, toastPool = {}, {}
local function ToastLayout()
    local y = 0
    for _, t in ipairs(toastList) do
        t:ClearAllPoints()
        t:SetPoint("TOP", UIParent, "TOP", 0, (-(Kit.toastY or 140) - y) / (t:GetScale() or 1) * (UIParent:GetScale() or 1))
        y = y + (H_TOAST + TOAST_GAP) * (t:GetScale() or 1) / (UIParent:GetScale() or 1)
    end
end
local function ToastGone(t)
    t:Hide()
    for i, x in ipairs(toastList) do if x == t then table.remove(toastList, i) break end end
    toastPool[#toastPool + 1] = t
    ToastLayout()
end
local function MakeToast()
    local t = CreateFrame("Frame", nil, UIParent)
    t:SetSize(W_TOAST, H_TOAST)
    t:SetFrameStrata("HIGH")
    t:SetClipsChildren(true)
    t.bg = t:CreateTexture(nil, "BACKGROUND", nil, -8)
    t.bg:SetAllPoints()
    t.edge = Kit.MakeBorder(t, unpack(Kit.EDGE))
    t.well = CreateFrame("Frame", nil, t)
    t.well:SetSize(44, 44)
    t.well:SetPoint("LEFT", 10, 0)
    local wbg = t.well:CreateTexture(nil, "BACKGROUND")
    wbg:SetAllPoints()
    wbg:SetColorTexture(0, 0, 0, 0.55)
    t.icon = t.well:CreateTexture(nil, "ARTWORK")
    t.icon:SetPoint("TOPLEFT", 2, -2)
    t.icon:SetPoint("BOTTOMRIGHT", -2, 2)
    t.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    t.wellEdge = Kit.MakeBorder(t.well, 1, 1, 1, 0.7)
    t.title = Kit.MakeFont(t, 11, nil, 1, 1, 1, 1)
    t.title:SetPoint("TOPLEFT", t.well, "TOPRIGHT", 10, -4)
    t.title:SetPoint("RIGHT", t, "RIGHT", -12, 0)
    t.title:SetJustifyH("LEFT")
    t.title:SetWordWrap(false)
    t.text = Kit.MakeFont(t, 14, nil, C.text[1], C.text[2], C.text[3], 1)
    t.text:SetPoint("TOPLEFT", t.title, "BOTTOMLEFT", 0, -4)
    t.text:SetPoint("RIGHT", t, "RIGHT", -12, 0)
    t.text:SetJustifyH("LEFT")
    t.text:SetWordWrap(false)
    -- Shine: a soft light band that sweeps across once.
    t.shine = CreateFrame("Frame", nil, t)
    t.shine:SetSize(90, H_TOAST)
    t.shine:SetFrameLevel(t:GetFrameLevel() + 5)
    for i, side in ipairs({ { 0, 0.22 }, { 0.22, 0 } }) do
        local s = t.shine:CreateTexture(nil, "OVERLAY")
        s:SetSize(45, H_TOAST)
        s:SetPoint("LEFT", (i - 1) * 45, 0)
        s:SetColorTexture(1, 1, 1, 1)
        local ok = CreateColor and pcall(s.SetGradient, s, "HORIZONTAL", CreateColor(1, 1, 1, side[1]), CreateColor(1, 1, 1, side[2]))
        if not ok then s:SetAlpha(0.1) end
    end
    t.shine:Hide()
    t:EnableMouse(true)
    t:SetScript("OnMouseUp", function(self) self.left = 0 end)
    t:SetScript("OnUpdate", function(self, dt)
        self.left = self.left - dt
        if self.left <= 0 then ToastGone(self) return end
        self:SetAlpha(math.min(1, self.left / FADE, (self.total - self.left) / 0.15 + 0.01))
        if self.shineAt then
            local e = (GetTime() - self.shineAt) / 0.8
            if e >= 1 then
                self.shineAt = nil
                self.shine:Hide()
            elseif e >= 0 then
                self.shine:SetPoint("LEFT", self, "LEFT", Kit.Lerp(-90, W_TOAST, e), 0)
                self.shine:Show()
            end
        end
    end)
    return t
end

function Kit.Toast(title, text, col, icon, sound)
    local t = table.remove(toastPool) or MakeToast()
    local r, g, b = Kit.Accent()
    col = col or { r, g, b }
    -- The pixel scale (as the kit's windows), times the addon's toast size.
    local ue = UIParent:GetEffectiveScale()
    local s = (ue and ue > 0) and (Kit.PixelScale() / ue) or 1
    t:SetScale(s * math.max(0.6, math.min(1.5, tonumber(Kit.toastScale) or 1)))
    t.bg:SetColorTexture(C.bg[1], C.bg[2], C.bg[3], Kit.BgAlpha(0.97))
    t.edge:SetColor(col[1], col[2], col[3], 0.7)
    t.wellEdge:SetColor(col[1], col[2], col[3], 0.7)
    t.icon:SetTexture(icon or 134400)
    t.title:SetText(title or "")
    t.title:SetTextColor(col[1], col[2], col[3], 1)
    t.text:SetText(text or "")
    t.text:SetTextColor(C.text[1], C.text[2], C.text[3], 1)
    t.total = (tonumber(Kit.toastHold) or 4) + FADE
    t.left = t.total
    t.shineAt = GetTime() + 0.2
    t:SetAlpha(0)
    t:Show()
    t.edge:Align()
    t.wellEdge:Align()
    toastList[#toastList + 1] = t
    while #toastList > (tonumber(Kit.toastMax) or 3) do ToastGone(toastList[1]) end
    ToastLayout()
    if sound then pcall(PlaySound, sound, "Master") end
end

-------------------------------------------------------------------------------
--  Tooltips, one rule for every addon. A line wraps only when it is long
--  (over Kit.TIP_WRAP visible characters): short lines keep the tooltip
--  narrow. Secret text is never measured or shown.
-------------------------------------------------------------------------------
Kit.TIP_WRAP = 60
local function Scale(f) return (f and f:GetEffectiveScale()) or 1 end
local function Visible(text)
    if type(text) ~= "string" or (issecretvalue and issecretvalue(text)) then return 0 end
    local plain = text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "x"):gsub("|A.-|a", "x")
    return #plain
end
Kit.VisibleLength = Visible

function Kit.AddTooltipLine(tt, text, r, g, b, wrap)
    tt = tt or GameTooltip
    if text == nil then return end
    if issecretvalue and issecretvalue(text) then tt:AddLine("?", r, g, b) return end
    if wrap == nil then wrap = Visible(text) > Kit.TIP_WRAP end
    tt:AddLine(text, r, g, b, wrap and true or false)
end

-- Two columns while both fit side by side; the left over the right (and
-- each wrapping by the rule) when they are long.
function Kit.AddTooltipPair(tt, left, right, lr, lg, lb, rr, rg, rb)
    tt = tt or GameTooltip
    if right == nil or right == "" then Kit.AddTooltipLine(tt, left, lr, lg, lb) return end
    if Visible(left) + Visible(right) > 44 then
        Kit.AddTooltipLine(tt, left, lr, lg, lb)
        Kit.AddTooltipLine(tt, "   " .. tostring(right), rr or lr, rg or lg, rb or lb)
    else
        tt:AddDoubleLine(left, right, lr, lg, lb, rr, rg, rb)
    end
end

-- The tooltip's owner set on the side with room: right of the control,
-- left of it near the screen's right edge; never over the control itself.
-- room: the width wanted, in screen pixels at the UI scale (default 320).
function Kit.TipOwner(owner, tt, room)
    tt = tt or GameTooltip
    local us = Scale(UIParent)
    local right = (owner:GetRight() or 0) * Scale(owner)
    local screen = (UIParent:GetRight() or 0) * us
    tt:SetOwner(owner, right + (room or 320) * us <= screen and "ANCHOR_RIGHT" or "ANCHOR_LEFT")
    return tt
end

-- A window going away takes the tooltip of anything in it along.
function Kit.HideTipsOf(frame)
    for _, tt in ipairs({ GameTooltip, ItemRefTooltip }) do
        if tt and tt:IsShown() and tt.GetOwner then
            local o = tt:GetOwner()
            while o do
                if o == frame then tt:Hide() break end
                o = o.GetParent and o:GetParent() or nil
            end
        end
    end
end
function Kit.TipsGoWith(frame)
    if frame.sfTipsGoWith then return end
    frame.sfTipsGoWith = true
    frame:HookScript("OnHide", Kit.HideTipsOf)
end

-------------------------------------------------------------------------------
--  Docked windows: beside the anchor on its right when the screen has room,
--  else on the left (of opts.leftOf when given: the leftmost window of a
--  group, so a chain never folds back over itself). Returns "right",
--  "left" or "center". opts: gap (8), leftOf.
-------------------------------------------------------------------------------
function Kit.Leftmost(...)
    local best, bx
    for i = 1, select("#", ...) do
        local f = select(i, ...)
        if f and f:IsShown() and f:GetLeft() then
            local x = f:GetLeft() * Scale(f)
            if not bx or x < bx then best, bx = f, x end
        end
    end
    return best
end

function Kit.BesideSide(win, anchor, opts)
    if not (anchor and anchor:IsShown() and anchor:GetRight()) then return "center" end
    local gap = (opts and opts.gap) or 8
    local need = ((win:GetWidth() or 0) + gap) * Scale(win)
    local right = anchor:GetRight() * Scale(anchor)
    local screen = (UIParent:GetRight() or 0) * Scale(UIParent)
    if right + need <= screen then return "right" end
    local lf = (opts and opts.leftOf) or anchor
    local left = (lf:GetLeft() or 0) * Scale(lf)
    if left - need >= 0 then return "left" end
    return (screen - right) >= left and "right" or "left"
end

function Kit.PlaceBeside(win, anchor, opts, offset)
    local side = Kit.BesideSide(win, anchor, opts)
    local gap = ((opts and opts.gap) or 8) + (offset or 0)
    win:ClearAllPoints()
    if side == "right" then
        win:SetPoint("TOPLEFT", anchor, "TOPRIGHT", gap, 0)
    elseif side == "left" then
        local lf = (opts and opts.leftOf) or anchor
        win:SetPoint("TOPRIGHT", lf, "TOPLEFT", -gap, 0)
        -- (level with the anchor, not with the group's leftmost window)
        if lf ~= anchor and anchor:GetTop() and lf:GetTop() then
            win:ClearAllPoints()
            win:SetPoint("TOPRIGHT", lf, "TOPLEFT", -gap, (anchor:GetTop() * Scale(anchor) - lf:GetTop() * Scale(lf)) / Scale(win))
        end
    else
        win:SetPoint("CENTER")
    end
    return side
end

return Kit
end -- Build

-- A kit of its own for an addon (name: its folder or a short name). Asked
-- again with the same name: the same kit.
function Lib:New(name)
    name = name or "?"
    local k = self.kits[name]
    if k and k.version == MINOR then return k end
    k = Build(name)
    self.kits[name] = k
    return k
end
