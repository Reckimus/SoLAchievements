-------------------------------------------------------------------------------
--  Themes: colour sets for the window, toast and tracker, plus the
--  window opacity and the key binding.
-------------------------------------------------------------------------------
local _, ns = ...
local FA = ns.FA
local C = FA.Kit.COLORS

local THEMES = {
    { key = "wrath", label = "Wrath Classic",
      bg = { 0.10, 0.075, 0.055 }, card = { 0.18, 0.124, 0.078 }, hover = { 0.25, 0.172, 0.095 },
      accent = { 1.00, 0.77, 0.35 }, text = { 0.99, 0.93, 0.81 }, dim = { 0.81, 0.72, 0.60 } },
    { key = "teal", label = "Sea Teal",
      bg = { 0.047, 0.075, 0.106 }, card = { 0.078, 0.122, 0.168 }, hover = { 0.098, 0.150, 0.205 },
      accent = { 0.18, 0.77, 0.71 }, text = { 0.93, 0.95, 0.97 }, dim = { 0.62, 0.68, 0.74 } },
    { key = "midnight", label = "Midnight",
      bg = { 0.020, 0.025, 0.035 }, card = { 0.045, 0.055, 0.070 }, hover = { 0.065, 0.080, 0.100 },
      accent = { 0.36, 0.60, 1.00 }, text = { 0.92, 0.94, 0.97 }, dim = { 0.56, 0.61, 0.68 } },
    { key = "gold", label = "Obsidian Gold",
      bg = { 0.030, 0.030, 0.030 }, card = { 0.068, 0.066, 0.062 }, hover = { 0.098, 0.094, 0.086 },
      accent = { 1.00, 0.78, 0.22 }, text = { 0.96, 0.94, 0.90 }, dim = { 0.66, 0.63, 0.57 } },
    { key = "ember", label = "Ember",
      bg = { 0.060, 0.034, 0.028 }, card = { 0.100, 0.060, 0.048 }, hover = { 0.138, 0.084, 0.066 },
      accent = { 1.00, 0.47, 0.20 }, text = { 0.97, 0.93, 0.90 }, dim = { 0.70, 0.62, 0.57 } },
    { key = "fel", label = "Fel",
      bg = { 0.028, 0.048, 0.030 }, card = { 0.052, 0.082, 0.054 }, hover = { 0.072, 0.112, 0.074 },
      accent = { 0.48, 0.92, 0.26 }, text = { 0.92, 0.96, 0.92 }, dim = { 0.60, 0.69, 0.60 } },
    { key = "arcane", label = "Arcane",
      bg = { 0.050, 0.034, 0.080 }, card = { 0.084, 0.060, 0.124 }, hover = { 0.114, 0.082, 0.164 },
      accent = { 0.74, 0.47, 1.00 }, text = { 0.95, 0.93, 0.98 }, dim = { 0.67, 0.62, 0.74 } },
    { key = "crimson", label = "Crimson",
      bg = { 0.054, 0.024, 0.030 }, card = { 0.094, 0.044, 0.052 }, hover = { 0.130, 0.060, 0.072 },
      accent = { 0.92, 0.22, 0.28 }, text = { 0.97, 0.92, 0.93 }, dim = { 0.70, 0.60, 0.62 } },
    { key = "frost", label = "Frost",
      bg = { 0.090, 0.112, 0.140 }, card = { 0.130, 0.160, 0.200 }, hover = { 0.160, 0.198, 0.248 },
      accent = { 0.56, 0.86, 1.00 }, text = { 0.95, 0.97, 1.00 }, dim = { 0.66, 0.74, 0.82 } },
}
local BY_KEY = {}
for _, t in ipairs(THEMES) do BY_KEY[t.key] = t end
FA.THEMES = THEMES

local function Copy(dst, src, alpha)
    dst[1], dst[2], dst[3] = src[1], src[2], src[3]
    if alpha then dst[4] = alpha end
end

-- Puts a theme's colours in the shared palette; every frame built after
-- this uses them, and the open ones are rebuilt.
function FA.ApplyTheme(key, quiet)
    local t = BY_KEY[key or ""] or THEMES[1]
    local S = FA.Settings()
    Copy(C.bg, t.bg, S.opacity or 0.97)
    Copy(C.card, t.card, 0.92)
    Copy(C.cardHover, t.hover, 0.95)
    Copy(C.accent, t.accent)
    Copy(C.text, t.text)
    Copy(C.dim, t.dim)
    if quiet then return end
    FA.ResetToast()
    if FA.StyleTracker then FA.StyleTracker() end
    FA.RebuildWindow()
end

-- Window background opacity, changed live.
function FA.SetOpacity(v)
    FA.Settings().opacity = v
    C.bg[4] = v
    local win = _G.SoLAchievementsWindow
    if win and win.chromeBg then win.chromeBg:SetColorTexture(C.bg[1], C.bg[2], C.bg[3], v) end
end

-- An achievement icon in a frame: a dark well, the picture kept 2 inside
-- the frame (never under its line), the frame on top. box.icon is the
-- picture, box.edge the frame (SetColor).
-- The frame is layers, not lines: a square in the frame's colour, the dark
-- well one pixel smaller on it, the picture inside. Lines placed on whole
-- pixels could land one off on a page drawn before it had its place (cut
-- frames on Summary and Current Zone); layers are never cut.
local framedIcons = setmetatable({}, { __mode = "k" })
-- Every framed icon on screen fitted again (after a scroll or a new size).
function ns.RefitIcons()
    for box in pairs(framedIcons) do
        if box:IsVisible() and box.Fit then pcall(box.Fit) end
    end
end
function ns.FramedIcon(parent, size, r, g, b, a)
    local box = CreateFrame("Frame", nil, parent)
    box:SetSize(size, size)
    -- Every edge of both layers on a whole screen pixel, placed by Fit (the
    -- client's own rounding off: it rounded the two layers apart and one
    -- side came out 2 px). The well one screen pixel in: the frame is that
    -- one pixel on every side.
    local nosnap = FA.Kit.NoSnap or FA.Kit.Snap
    local outer = nosnap(box:CreateTexture(nil, "BACKGROUND", nil, 0))
    outer:SetAllPoints()
    local well = nosnap(box:CreateTexture(nil, "BACKGROUND", nil, 1))
    well:SetColorTexture(0.03, 0.03, 0.04, 1)
    -- One screen pixel in this frame's units, measured where it is shown (a
    -- page made before it had its place, or a new window size, had it
    -- measured at another scale: one side came out 2 px).
    local shiftX, shiftY = 0, 0
    local setX, setY -- (the offsets Fit last set: other ones mean the box was placed anew)
    local fitting = false
    local function Fit()
        if fitting then return end
        fitting = true
        local px = (FA.Kit.PixelSize and FA.Kit.PixelSize(box)) or 1
        if not px or px <= 0 or px > 2 then px = 1 end
        -- A whole number of screen pixels across (the right and bottom edges
        -- land on pixels too once the left and top do).
        local want = math.max(px * 4, math.floor(size / px + 0.5) * px)
        local w = box:GetWidth()
        if type(w) == "number" and math.abs(w - want) > 0.001 then box:SetSize(want, want) end
        well:ClearAllPoints()
        well:SetPoint("TOPLEFT", px, -px)
        well:SetPoint("BOTTOMRIGHT", -px, px)
        -- The box's left and top edges on whole screen pixels (its own
        -- anchor moved by less than a pixel): both layers then round alike.
        local okL, L, T = pcall(function() return box:GetLeft(), box:GetTop() end)
        local p, rel, rp, x, y = box:GetPoint(1)
        if okL and L and T and p and type(x) == "number" and type(y) == "number"
            and not (issecretvalue and (issecretvalue(L) or issecretvalue(T))) then
            if x ~= setX or y ~= setY then shiftX, shiftY = 0, 0 end -- (placed anew by its page)
            local baseL, baseT = L - shiftX, T - shiftY
            local nx = math.floor(baseL / px + 0.5) * px - baseL
            local ny = math.floor(baseT / px + 0.5) * px - baseT
            if math.abs(nx - shiftX) > 0.001 or math.abs(ny - shiftY) > 0.001 then
                setX, setY = x - shiftX + nx, y - shiftY + ny
                box:SetPoint(p, rel, rp, setX, setY)
                shiftX, shiftY = nx, ny
            end
        end
        fitting = false
    end
    Fit()
    box:SetScript("OnShow", Fit)
    box:SetScript("OnSizeChanged", Fit)
    if C_Timer and C_Timer.After then C_Timer.After(0, Fit) end
    box.Fit = Fit
    framedIcons[box] = true
    local icon = box:CreateTexture(nil, "ARTWORK")
    icon:SetPoint("TOPLEFT", 2, -2)
    icon:SetPoint("BOTTOMRIGHT", -2, 2)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    box.icon = icon
    -- (the frame's colour, as a border's SetColor)
    box.edge = { SetColor = function(_, cr, cg, cb, ca) outer:SetColorTexture(cr or 1, cg or 1, cb or 1, ca or 1) end }
    box.edge:SetColor(r or 1, g or 1, b or 1, a or 0.35)
    return box
end

-- Text sizes (Settings > Text Size): the kit's roles (window, settings and
-- setup) and the addon's own (achievement cards, the tracker).
FA.FONT_ROLES = {}
for _, r in ipairs(FA.Kit.FONT_ROLES or {}) do
    if not r.key:match("^wiz") then FA.FONT_ROLES[#FA.FONT_ROLES + 1] = r end
end
FA.FONT_ROLES[#FA.FONT_ROLES + 1] = { key = "achName", label = "Achievement names", size = 14 }
FA.FONT_ROLES[#FA.FONT_ROLES + 1] = { key = "achDesc", label = "Achievement details", size = 11 }
FA.FONT_ROLES[#FA.FONT_ROLES + 1] = { key = "tracker", label = "Tracker", size = 11 }

-- The picked sizes on every text on screen (the layout follows on the next
-- redraw: FA.WhenReleased does it once a slider is let go).
function FA.ApplyFontSizes()
    local sizes = FA.Settings().fontSizes or {}
    for _, r in ipairs(FA.FONT_ROLES) do
        if FA.Kit.SetFontSize then FA.Kit.SetFontSize(r.key, sizes[r.key], r.size) end
    end
    if FA.Kit.RefreshFonts then FA.Kit.RefreshFonts() end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function()
    FA.ApplyFontSizes()
    FA.ApplyTheme(FA.Settings().theme, true)
    FA.Kit.animate = FA.Settings().animations ~= false
    if FA.StyleTracker then FA.StyleTracker() end
end)

-- Key binding (Key Bindings > AddOns > SoLAchievements).
BINDING_HEADER_SOLACHIEVEMENTS = "SoLAchievements"
BINDING_NAME_SOLACHIEVEMENTS_TOGGLE = "Open or close the window"
function SoLAchievements_Toggle()
    if FA.IsShown() then FA.Hide() else FA.Open() end
end
