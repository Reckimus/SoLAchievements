-------------------------------------------------------------------------------
--  SoLAchievements
--
--  The WotLK General achievements that the WoW Forever world still allows,
--  tracked per character. State that the game can report (level, riding,
--  mounts, pets, tabard) is read at any time; everything that happens
--  (money looted, critters loved, pests killed, books read, food and drink,
--  falls, loot rolls) counts from the moment the addon is installed.
-------------------------------------------------------------------------------

local ADDON, ns = ...
local FAC = ns.Split_SoLAchievements -- (what the parts of SoLAchievements.lua share)
local Count, DB, IsQuestDone, QUEST_SECTIONS, SECTIONS, StatNumber, secret = FAC.Count, FAC.DB, FAC.IsQuestDone, FAC.QUEST_SECTIONS, FAC.SECTIONS, FAC.StatNumber, FAC.secret
-------------------------------------------------------------------------------
--  Professions (classic cap 300: Journeyman, Expert and Artisan ranks)
-------------------------------------------------------------------------------
local PRIMARY = { Alchemy = true, Blacksmithing = true, Enchanting = true, Engineering = true, Herbalism = true,
    Leatherworking = true, Mining = true, Skinning = true, Tailoring = true, Jewelcrafting = true, Inscription = true }
local SECONDARY = { "Cooking", "Fishing", "First Aid" }
local SKILL_LINES = { [171] = "Alchemy", [164] = "Blacksmithing", [333] = "Enchanting", [202] = "Engineering",
    [182] = "Herbalism", [165] = "Leatherworking", [186] = "Mining", [393] = "Skinning", [197] = "Tailoring",
    [755] = "Jewelcrafting", [773] = "Inscription", [185] = "Cooking", [356] = "Fishing", [129] = "First Aid" }

-- Best rank ever reached per skill, so dropping a profession keeps the record.
local function Skills()
    local best = DB().skills
    if GetNumSkillLines and GetSkillLineInfo then
        for i = 1, (GetNumSkillLines() or 0) do
            local name, isHeader, _, rank = GetSkillLineInfo(i)
            if name and not isHeader and rank and not secret(rank) then
                best[name] = math.max(best[name] or 0, rank)
            end
        end
    end
    -- The Forever client has no skill line list: professions come from the
    -- profession slots, named by skill line so the names match any locale.
    if GetProfessions and GetProfessionInfo then
        local slots = { GetProfessions() }
        for i = 1, 6 do
            local index = slots[i]
            if index then
                local name, _, rank, _, _, _, line = GetProfessionInfo(index)
                name = SKILL_LINES[line] or name
                if name and rank and not secret(rank) then
                    best[name] = math.max(best[name] or 0, rank)
                end
            end
        end
    end
    return best
end

local function BestPrimary()
    local top = 0
    for name, rank in pairs(Skills()) do if PRIMARY[name] then top = math.max(top, rank) end end
    return top
end

local function PrimariesAt(n)
    local c = 0
    for name, rank in pairs(Skills()) do if PRIMARY[name] and rank >= n then c = c + 1 end end
    return c
end

local function SkillRank(name) return Skills()[name] or 0 end

local function RankAch(key, id, series, name, desc, skill, n, icon)
    return { key = key, id = id, icon = icon, series = series, name = name, desc = desc, pts = 10,
             progress = function()
                 local r = skill and SkillRank(skill) or BestPrimary()
                 return math.min(r, n), n
             end }
end

local STAT_FISHED, STAT_FISH, STAT_RECIPES = 1456, 1518, 1745
-- The client's catch statistic can lag far behind (it lost catches during the
-- beta), so the skill sets a floor: every point above 1 took at least one catch.
local function FishedCount()
    local floor = math.max(0, SkillRank("Fishing") - 1)
    return math.max(StatNumber(STAT_FISHED) or 0, StatNumber(STAT_FISH) or 0, DB().fished or 0, floor)
end

local function FishAch(key, id, n)
    return { key = key, id = id, series = "fished", name = n .. " Fish", desc = "Fish up " .. n .. " items.", pts = 10,
             progress = function() return math.min(FishedCount(), n), n end }
end

local function RecipeAch(key, id, name, n)
    return { key = key, id = id, series = "recipes", name = name, desc = "Learn " .. n .. " cooking recipes.", pts = 10,
             progress = function() return math.min(StatNumber(STAT_RECIPES) or 0, n), n end }
end

local DIPLOMAT = { "Orgrimmar", "Stormwind City" }
local RARE_NAMES = {}
for _, f in ipairs(ns.RARE_FISH) do RARE_NAMES[#RARE_NAMES + 1] = f[1] end

local function HasRareFish(name)
    for _, f in ipairs(ns.RARE_FISH) do
        if f[1] == name then
            local count = (C_Item and C_Item.GetItemCount) or GetItemCount
            return DB().rareFish[f[2]] or (count and (count(f[2], true) or 0) > 0)
        end
    end
end

-- Optional fishing integration uses the public API.
-- These achievements show only while Fishing is loaded. The totals are
-- asked at most once a second and never in combat (the last numbers stand).
local QF = { stats = { catches = 0, zones = 0, kinds = 0, rares = 0, collection = 0, known = 0, zonesFull = 0 }, at = -10 }
ns.QF = QF -- (the one way to Fishing for the other files: QF.API())

function QF.API()
    local api = rawget(_G, "QuickFishAPI")
    if type(api) == "table" then return api end
end

function QF.Loaded()
    local loaded = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    if loaded then
        local ok, yes = pcall(loaded, "QuickFish")
        if ok and yes then return true end
    end
    return QF.API() ~= nil
end

function QF.Stats()
    local now = GetTime()
    if now - QF.at < 1 then return QF.stats end
    local fighting = InCombatLockdown and InCombatLockdown()
    if secret(fighting) or fighting then return QF.stats end
    QF.at = now
    -- Fishing's own numbers (its API, "statistics").
    local api = QF.API()
    if api and type(api.capabilities) == "table" and api.capabilities.statistics and type(api.Stats) == "function" then
        local ok, s = pcall(api.Stats)
        if ok and type(s) == "table" then
            QF.stats = s
            return s
        end
    end
    -- (an older Fishing: the parts its API had then, the rest unknown)
    local s = { catches = 0, zones = 0, kinds = 0, rares = 0, collection = 0, known = 0, zonesFull = 0 }
    if api then
        if type(api.Catches) == "function" then
            local ok, n = pcall(api.Catches)
            if ok then s.catches = tonumber(n) or 0 end
        end
        if type(api.Collection) == "function" then
            local ok, caught, known = pcall(api.Collection)
            if ok then s.collection, s.known = tonumber(caught) or 0, tonumber(known) or 0 end
        end
        if type(api.ZonesComplete) == "function" then
            local ok2, full = pcall(api.ZonesComplete)
            if ok2 then s.zonesFull = tonumber(full) or 0 end
        end
    end
    QF.stats = s
    return s
end

-- Fishing's milestones (its API's Milestones, 0.7 and later):
-- Quick Fish defines them (names, steps, what counts), these show them as
-- achievements, and Quick Fish leaves the unlock to us (QuickFishMilestones
-- below). Their name, description and icon are read from Quick Fish when
-- it is there; the ones given here only stand in until then.
function QF.Milestones()
    local now = GetTime()
    if QF.msAt and now - QF.msAt < 1 and QF.ms then return QF.ms end
    QF.msAt = now
    local api = QF.API()
    local by = {}
    if type(api) == "table" and type(api.Milestones) == "function" then
        local ok, list = pcall(api.Milestones)
        if ok and type(list) == "table" then
            for _, m in ipairs(list) do if type(m) == "table" and m.id then by[m.id] = m end end
        end
    end
    QF.ms = by
    return by
end
function QF.HasMilestones()
    local api = QF.API()
    return QF.Loaded() and type(api) == "table" and type(api.Milestones) == "function"
end
function QF.MS(id, name, desc, icon, pts)
    local base = { key = "qf_" .. id, series = "qf" .. id:match("^(%a+)"), pts = pts or 10, requires = QF.HasMilestones,
                   progress = function()
                       local m = QF.Milestones()[id]
                       if not m then return 0, 1 end
                       local need = tonumber(m.need) or 1
                       -- (a step not known yet, as "all" with no zone data: never met)
                       if need == math.huge then return 0, 1 end
                       if m.blocked then return 0, need end
                       return math.min(tonumber(m.have) or 0, need), need
                   end }
    local fallback = { name = name, desc = desc, icon = icon }
    return setmetatable(base, { __index = function(_, k)
        if k == "name" or k == "desc" or k == "icon" then
            local m = QF.Milestones()[id]
            if m then
                if k == "name" then return m.name end
                if k == "desc" then return m.desc and (m.desc:sub(1, 1):upper() .. m.desc:sub(2) .. " (Quick Fish).") or fallback.desc end
                if k == "icon" then return m.icon or fallback.icon end
            end
            return fallback[k]
        end
    end })
end
-- Earned under the keys these had before (Quick Fish's own series then).
QF.OLD_KEYS = { qfcoll10 = "qf_collection_10", qfcollall = "qf_collection_all", qfzonefull1 = "qf_zones_1",
                qfzonefull5 = "qf_zones_5", qfrares1 = "qf_rares_1", qfrares10 = "qf_rares_10" }

function QF.Ach(key, series, stat, name, desc, n, icon)
    return { key = key, series = series, icon = icon, name = name, desc = desc, pts = 10, requires = QF.Loaded,
             progress = function() return math.min(QF.Stats()[stat], n), n end }
end

local PROF_SECTIONS = {
    { title = "PROFESSIONS", list = {
        RankAch("prof75", nil, "prof", "Professional Apprentice", "Reach 75 in a profession.", nil, 75, 134327),
        RankAch("prof150", 116, "prof", "Professional Journeyman", "Reach 150 in a profession.", nil, 150),
        RankAch("prof225", 731, "prof", "Professional Expert", "Reach 225 in a profession.", nil, 225),
        RankAch("prof300", 732, "prof", "Professional Artisan", "Reach 300 in a profession.", nil, 300),
        { key = "dayandnight", id = 735, name = "Working Day and Night", pts = 10,
          desc = "Become an Artisan (300) in two professions.",
          progress = function() return math.min(PrimariesAt(300), 2), 2 end },
        { key = "paythebills", id = 730, name = "Skills to Pay the Bills", pts = 10,
          desc = "Become an Artisan (300) in fishing, first aid and cooking.",
          list = SECONDARY, has = function(n) return SkillRank(n) >= 300 end,
          progress = function()
              local c = 0
              for _, s in ipairs(SECONDARY) do if SkillRank(s) >= 300 then c = c + 1 end end
              return c, #SECONDARY
          end },
    } },
    { title = "COOKING", list = {
        RankAch("cook75", nil, "cook", "Apprentice Cook", "Become an Apprentice Cook.", "Cooking", 75, 133971),
        RankAch("cook150", 121, "cook", "Journeyman Cook", "Become a Journeyman Cook.", "Cooking", 150),
        RankAch("cook225", 122, "cook", "Expert Cook", "Become an Expert Cook.", "Cooking", 225),
        RankAch("cook300", 123, "cook", "Artisan Cook", "Become an Artisan Cook.", "Cooking", 300),
        RecipeAch("recipes25", 1795, "Lunch Lady", 25),
        RecipeAch("recipes50", 1796, "Short Order Cook", 50),
        RecipeAch("recipes75", 1797, "Chef de Partie", 75),
    } },
    { title = "FISHING", list = {
        RankAch("fish75", nil, "fishing", "Apprentice Fisherman", "Become an Apprentice Fisherman.", "Fishing", 75, 136245),
        RankAch("fish150", 126, "fishing", "Journeyman Fisherman", "Become a Journeyman Fisherman.", "Fishing", 150),
        RankAch("fish225", 127, "fishing", "Expert Fisherman", "Become an Expert Fisherman.", "Fishing", 225),
        RankAch("fish300", 128, "fishing", "Artisan Fisherman", "Become an Artisan Fisherman.", "Fishing", 300),
        FishAch("fished25", 1556, 25), FishAch("fished50", 1557, 50), FishAch("fished100", 1558, 100),
        FishAch("fished250", 1559, 250), FishAch("fished500", 1560, 500), FishAch("fished1000", 1561, 1000),
        { key = "oldgnome", id = 153, name = "The Old Gnome and the Sea", desc = "Successfully fish from a school.", pts = 10,
          progress = function() return DB().school and 1 or 0, 1 end },
        { key = "diplomat", id = 150, name = "The Fishing Diplomat", desc = "Fish something up in Orgrimmar and Stormwind.", pts = 10,
          list = DIPLOMAT, has = function(n) return DB().fishedIn[n] end,
          progress = function()
              local c = 0
              for _, z in ipairs(DIPLOMAT) do if DB().fishedIn[z] then c = c + 1 end end
              return c, #DIPLOMAT
          end },
        { key = "masterangler", id = 306, name = "Master Angler of Azeroth", desc = "Win the Booty Bay fishing contest.", pts = 20,
          progress = function() return IsQuestDone(8193) and 1 or 0, 1 end },
        { key = "rarefish", id = 878, name = "One That Didn't Get Away", desc = "Catch one of the rare fish in the list below.", pts = 10,
          list = RARE_NAMES, has = HasRareFish,
          progress = function()
              for _, n in ipairs(RARE_NAMES) do if HasRareFish(n) then return 1, 1 end end
              return 0, 1
          end },
    } },
    { title = "QUICK FISH", list = {
        -- No catch-count series here: the Fishing section's "X Fish" already
        -- counts every catch (game statistic), Quick Fish's log only since install.
        QF.Ach("qfzones5", "qfzones", "zones", "Wandering Angler", "Fish something up in 5 zones (Quick Fish catch log).", 5, 237381),
        QF.Ach("qfzones10", "qfzones", "zones", "Travelling Angler", "Fish something up in 10 zones (Quick Fish catch log).", 10, 237381),
        QF.Ach("qfzones20", "qfzones", "zones", "Angler of Azeroth", "Fish something up in 20 zones (Quick Fish catch log).", 20, 237381),
        QF.Ach("qfkinds15", "qfkinds", "kinds", "Mixed Bag", "Fish up 15 different items (Quick Fish catch log).", 15, 133892),
        QF.Ach("qfkinds30", "qfkinds", "kinds", "Fish of Every Kind", "Fish up 30 different items (Quick Fish catch log).", 30, 133892),
        -- Quick Fish's milestones (fish caught past 1000 and the skill are the
        -- Fishing section's: the game's own series).
        QF.MS("fish_2500", "School's Out", "2500 fish caught (Quick Fish).", 133888),
        QF.MS("fish_5000", "Deep Water", "5000 fish caught (Quick Fish).", 133888),
        QF.MS("fish_10000", "Sea Legs", "10000 fish caught (Quick Fish).", 133888),
        QF.MS("fish_25000", "The Old Angler and the Sea", "25000 fish caught (Quick Fish).", 133888, 20),
        QF.MS("collection_10", "Collector", "10 kinds of fish caught (Quick Fish).", 133739),
        QF.MS("collection_25", "Curator", "25 kinds of fish caught (Quick Fish).", 133739),
        QF.MS("collection_50", "Ichthyologist", "50 kinds of fish caught (Quick Fish).", 133739),
        QF.MS("collection_all", "Every Fish in the Sea", "Every kind of fish caught (Quick Fish).", 133739, 20),
        QF.MS("zones_1", "Fished Out", "1 zone with every fish caught (Quick Fish).", 134269),
        QF.MS("zones_5", "Local Angler", "5 zones with every fish caught (Quick Fish).", 134269),
        QF.MS("zones_10", "Well Travelled", "10 zones with every fish caught (Quick Fish).", 134269),
        QF.MS("goals_1", "Goal Getter", "1 session goal reached (Quick Fish).", 134327),
        QF.MS("goals_10", "On Target", "10 session goals reached (Quick Fish).", 134327),
        QF.MS("goals_25", "Driven", "25 session goals reached (Quick Fish).", 134327),
        QF.MS("sessions_10", "Weekend Angler", "10 fishing sessions (Quick Fish).", 134376),
        QF.MS("sessions_50", "Dedicated", "50 fishing sessions (Quick Fish).", 134376),
        QF.MS("sessions_100", "Lifer", "100 fishing sessions (Quick Fish).", 134376),
        QF.MS("value_10", "Worth the Bait", "10g worth of fish (Quick Fish).", 133784),
        QF.MS("value_50", "Market Catch", "50g worth of fish (Quick Fish).", 133784),
        QF.MS("value_100", "Fishmonger", "100g worth of fish (Quick Fish).", 133784),
        QF.MS("value_500", "Golden Tackle", "500g worth of fish (Quick Fish).", 133784, 20),
        QF.MS("rares_1", "Lucky Find", "1 rare find (Quick Fish).", 134124),
        QF.MS("rares_5", "Treasure Hunter", "5 rare finds (Quick Fish).", 134124),
        QF.MS("rares_10", "Rare Hand", "10 rare finds (Quick Fish).", 134124),
        QF.MS("rares_25", "Legend of the Deep", "25 rare finds (Quick Fish).", 134124, 20),
    } },
    { title = "FIRST AID", list = {
        RankAch("aid75", nil, "firstaid", "Apprentice in First Aid", "Become an Apprentice in first aid.", "First Aid", 75, 135966),
        RankAch("aid150", 131, "firstaid", "Journeyman in First Aid", "Become a Journeyman in first aid.", "First Aid", 150),
        RankAch("aid225", 132, "firstaid", "Expert in First Aid", "Become an Expert in first aid.", "First Aid", 225),
        RankAch("aid300", 133, "firstaid", "Artisan in First Aid", "Become an Artisan in first aid.", "First Aid", 300),
    } },
}

-------------------------------------------------------------------------------
--  Dungeons & Raids (classic instances; a kill counts once per character)
-------------------------------------------------------------------------------
local BOSS_IDS, BOSS_BY_NAME = {}, {}

local function BossKilled(boss) return DB().bosses[boss[2]] or DB().bosses[boss[1]] end

local BOSS_ACH = {} -- [boss name] = achievement name, for the tooltips

local function DungeonAch(d)
    -- Bosses without a known creature ID are tracked by name.
    for _, b in ipairs(d.bosses) do
        if b[2] then BOSS_IDS[b[2]] = b[1] end
        BOSS_BY_NAME[b[1]] = b[2] or b[1]
        BOSS_ACH[b[1]] = d.name
    end
    local names = {}
    for _, b in ipairs(d.bosses) do names[#names + 1] = b[1] end
    local function Killed(b)
        if BossKilled(b) then return true end
        -- The kill statistic names the first boss: it covers kills from before the addon.
        if d.stat and b == d.bosses[1] and (StatNumber(d.stat) or 0) > 0 then return true end
        for _, id in ipairs(ns.BOSS_STATS[b[1]] or {}) do
            if (StatNumber(id) or 0) > 0 then return true end
        end
        return false
    end
    -- kill: checked in combat too, right after a kill (see CheckAll).
    return { key = d.key or ("dungeon" .. d.id), id = d.id, icon = d.icon, name = d.name, desc = d.desc, pts = 10, kill = true,
             list = (d.all and #names > 1) and names or nil,
             has = function(n)
                 for _, b in ipairs(d.bosses) do if b[1] == n then return Killed(b) end end
             end,
             progress = function()
                 local c = 0
                 for _, b in ipairs(d.bosses) do if Killed(b) then c = c + 1 end end
                 if not d.all then
                     -- The boss's head quests also prove the kill.
                     if c == 0 then
                         for _, q in ipairs(d.quests or {}) do if IsQuestDone(q) then c = 1 break end end
                     end
                     return math.min(c, 1), 1
                 end
                 return c, #d.bosses
             end }
end

local dungeonList, raidList = {}, {}
for _, d in ipairs(ns.DUNGEONS) do dungeonList[#dungeonList + 1] = DungeonAch(d) end
raidList[1] = DungeonAch({ key = "onyxia60", id = 684, icon = 254650, name = "Onyxia's Lair", desc = "Defeat Onyxia.",
    bosses = { { "Onyxia", 10184 } }, stat = 1098 })
for _, d in ipairs(ns.RAIDS) do raidList[#raidList + 1] = DungeonAch(d) end
-- Naxxramas (40): no classic version in WotLK, which only had the level 80 raid.
raidList[#raidList + 1] = DungeonAch({ key = "naxx40", icon = 236493, name = "Naxxramas", desc = "Defeat Kel'Thuzad.",
    bosses = { { "Kel'Thuzad", 15990 } } })

-- Dungeons new in WoW Forever (no WotLK achievement): the final boss, by
-- name, plus the kill statistic the Forever client keeps for it.
local FOREVER_DUNGEONS = {
    -- Final bosses: creature IDs from the Spelunker criteria; a name only where
    -- the client gives none. Kill statistics where the client keeps them.
    { key = "dungeonThanes", icon = ns.ICONS[642], name = "The Hall of Thanes", desc = "Defeat Durgen Dirgehammer.",
      bosses = { { "Durgen Dirgehammer", 261319 } }, quests = { 96393 }, stat = 63573 },
    { key = "dungeonLordaeron", icon = ns.ICONS[631], name = "Ruins of Lordaeron", desc = "Defeat Rath'mael.",
      bosses = { { "Rath'mael", 250657 } }, stat = 63571 },
    { key = "dungeonExcavation", icon = ns.ICONS[638], name = "Excavation Site: Wetlands", desc = "Defeat the Relic Guardian.",
      bosses = { { "Relic Guardian", 260326 } } },
    { key = "dungeonDalaran", icon = ns.ICONS[645], name = "City of Dalaran", desc = "Defeat the Shade of the Archmage.",
      bosses = { { "Shade of the Archmage", 246020 } }, stat = 63572 },
    { key = "dungeonDrowned", icon = ns.ICONS[632], name = "The Drowned City", desc = "Defeat Min'loth the Serpent.",
      bosses = { { "Min'loth the Serpent", 260274 } } },
    { key = "dungeonKroldok", icon = ns.ICONS[639], name = "Krol'dok Stronghold", desc = "Defeat Overlord Mugg.",
      bosses = { { "Overlord Mugg", 258968 } } },
    { key = "dungeonAlcaz", icon = ns.ICONS[642], name = "Alcaz Prison", desc = "Defeat Blazeroar.",
      bosses = { { "Blazeroar", 255702 } }, stat = 63575 },
    { key = "dungeonBlackmaw", icon = ns.ICONS[640], name = "Blackmaw Hold", desc = "Defeat Varrox Bleakhoof.",
      bosses = { { "Varrox Bleakhoof", 247234 } } },
    { key = "dungeonShaper", icon = ns.ICONS[641], name = "The Shaper's Terrace", desc = "Defeat Nanaya.",
      bosses = { { "Nanaya", 261809 } }, stat = 63574 },
}
local foreverList = {}
for _, d in ipairs(FOREVER_DUNGEONS) do foreverList[#foreverList + 1] = DungeonAch(d) end

local DUNGEON_SECTIONS = {
    { title = "DUNGEONS", list = dungeonList },
    { title = "FOREVER DUNGEONS", list = foreverList },
    { title = "RAIDS", list = raidList },
}

-- Reputation, PvP, Feats and the Forever tab; their helpers stay inside the
-- block (a Lua chunk allows 200 locals at a time).
-- (FAC.REP_SECTIONS, FAC.PVP_SECTIONS, FAC.FEAT_SECTIONS: shared, set below)
do
-------------------------------------------------------------------------------
--  World bosses and rare enemies
-------------------------------------------------------------------------------
-- Icons of their own (no WotLK achievement had them): the blue dragon, the
-- demon lord, the green dragons of the Emerald Dream.
local WB_ICON = "Interface\\Icons\\"
local WB_GREEN = WB_ICON .. "INV_Misc_Head_Dragon_Green"
local WORLD_BOSSES = {
    { key = "wbAzuregos", name = "Azuregos", desc = "Defeat Azuregos in Azshara.", icon = WB_ICON .. "INV_Misc_Head_Dragon_Blue", bosses = { { "Azuregos", 6109 } } },
    { key = "wbKazzak", name = "Lord Kazzak", desc = "Defeat Lord Kazzak.", icon = WB_ICON .. "Spell_Shadow_SummonFelGuard", bosses = { { "Lord Kazzak", 12397 } } },
    { key = "wbYsondre", name = "Ysondre", desc = "Defeat Ysondre, a Dragon of Nightmare.", icon = WB_GREEN, bosses = { { "Ysondre", 14887 } } },
    { key = "wbLethon", name = "Lethon", desc = "Defeat Lethon, a Dragon of Nightmare.", icon = WB_GREEN, bosses = { { "Lethon", 14888 } } },
    { key = "wbEmeriss", name = "Emeriss", desc = "Defeat Emeriss, a Dragon of Nightmare.", icon = WB_GREEN, bosses = { { "Emeriss", 14889 } } },
    { key = "wbTaerar", name = "Taerar", desc = "Defeat Taerar, a Dragon of Nightmare.", icon = WB_GREEN, bosses = { { "Taerar", 14890 } } },
}
local worldBossList = {}
for _, d in ipairs(WORLD_BOSSES) do
    d.icon = d.icon or ns.ICONS[686]
    worldBossList[#worldBossList + 1] = DungeonAch(d)
end
worldBossList[#worldBossList + 1] = DungeonAch({ key = "wbNightmare", icon = WB_ICON .. "Spell_Nature_Sleep", name = "Nightmare's End",
    desc = "Defeat the four Dragons of Nightmare.", all = true,
    bosses = { { "Ysondre", 14887 }, { "Lethon", 14888 }, { "Emeriss", 14889 }, { "Taerar", 14890 } } })
for _, a in ipairs(worldBossList) do a.pts = (a.key == "wbNightmare") and 25 or 10 end
table.insert(DUNGEON_SECTIONS, { title = "WORLD BOSSES", list = worldBossList })

-- Rares: any rare or rare elite you kill, counted once per name.
local function RareAch(key, n, name)
    return { key = key, series = "rares", name = name, icon = 136147, pts = 10, kill = true,
             desc = ("Slay %d different rare enemies."):format(n),
             progress = function() return math.min(Count(DB().rares), n), n end }
end
table.insert(SECTIONS, { title = "RARE ENEMIES", list = {
    RareAch("rare1", 1, "Something Rare"), RareAch("rare10", 10, "Rare Hunter"),
    RareAch("rare25", 25, "Seasoned Rare Hunter"), RareAch("rare50", 50, "Rare Collector"),
    RareAch("rare100", 100, "Rarely Seen, Always Slain"),
} })

-------------------------------------------------------------------------------
--  Reputation
-------------------------------------------------------------------------------
local EXALTED = 42000
local GetFactionDataByID = C_Reputation and C_Reputation.GetFactionDataByID

-- Standing as a number on the classic scale: 0 neutral, 42000 exalted.
local function Standing(id)
    if GetFactionDataByID then
        local data = GetFactionDataByID(id)
        if data and data.currentStanding and not secret(data.currentStanding) then return data.currentStanding end
    end
    if GetFactionInfoByID then
        local _, _, _, _, _, value = GetFactionInfoByID(id)
        if value and not secret(value) then return value end
    end
    return 0
end

-- Best standing ever seen, so a dip after a hostile kill keeps the record.
local function BestStanding(id)
    local d = DB()
    local now = Standing(id)
    if now > (d.reps[id] or -99999) then d.reps[id] = now end
    return d.reps[id]
end

local function IsExalted(id) return BestStanding(id) >= EXALTED end

local function ExaltedCount()
    local n = 0
    for _, f in ipairs(ns.FACTIONS) do if IsExalted(f[1]) then n = n + 1 end end
    return n
end

local FACTION_NAME = {}
for _, f in ipairs(ns.FACTIONS) do FACTION_NAME[f[1]] = f[2] end

local function ExaltedSeries(key, id, n, name)
    return { key = key, id = id, series = "exalted", name = name, pts = 10,
             desc = n == 1 and "Raise a reputation to Exalted." or ("Raise %d reputations to Exalted."):format(n),
             progress = function() return math.min(ExaltedCount(), n), n end }
end

-- Exalted with every faction listed; one faction shows its standing.
local function RepAch(key, id, name, desc, factions, pts, extra)
    local names = {}
    for _, fid in ipairs(factions) do names[#names + 1] = FACTION_NAME[fid] or ("Faction " .. fid) end
    local a = { key = key, id = id, name = name, desc = desc, pts = pts or 10 }
    if #factions == 1 then
        a.progress = function() return math.max(0, math.min(BestStanding(factions[1]), EXALTED)), EXALTED end
    else
        a.list = names
        a.has = function(n)
            for i, fid in ipairs(factions) do if names[i] == n then return IsExalted(fid) end end
        end
        a.progress = function()
            local c = 0
            for _, fid in ipairs(factions) do if IsExalted(fid) then c = c + 1 end end
            return c, #factions
        end
    end
    for k, v in pairs(extra or {}) do a[k] = v end
    return a
end

local INSANE = { 21, 577, 369, 470, 349, 909 }
local insane = RepAch("insane", 2336, "Insane in the Membrane",
    "Honored with the Bloodsail Buccaneers, and Exalted with Booty Bay, Everlook, Gadgetzan, Ratchet, Ravenholdt and the Darkmoon Faire.",
    INSANE, 10, { title = "%s the Insane" })
-- The Bloodsail part is Honored, not Exalted.
local insaneNames = { "Bloodsail Buccaneers (Honored)" }
for _, fid in ipairs(INSANE) do insaneNames[#insaneNames + 1] = FACTION_NAME[fid] end
insane.list = insaneNames
insane.has = function(n)
    if n:find("Bloodsail", 1, true) then return BestStanding(87) >= 9000 end
    for _, fid in ipairs(INSANE) do if FACTION_NAME[fid] == n then return IsExalted(fid) end end
end
insane.progress = function()
    local c = BestStanding(87) >= 9000 and 1 or 0
    for _, fid in ipairs(INSANE) do if IsExalted(fid) then c = c + 1 end end
    return c, #INSANE + 1
end

FAC.REP_SECTIONS = {
    { title = "EXALTED", list = {
        ExaltedSeries("ex1", 522, 1, "Somebody Likes Me"), ExaltedSeries("ex5", 523, 5, "5 Exalted Reputations"),
        ExaltedSeries("ex10", 524, 10, "10 Exalted Reputations"), ExaltedSeries("ex15", 521, 15, "15 Exalted Reputations"),
        ExaltedSeries("ex20", 520, 20, "20 Exalted Reputations"), ExaltedSeries("ex25", 519, 25, "25 Exalted Reputations"),
        ExaltedSeries("ex30", 518, 30, "30 Exalted Reputations"),
    } },
    { title = "HOME CITIES", list = {
        RepAch("ambAlliance", 948, "Ambassador of the Alliance", "Earn exalted reputation with the Alliance home cities.",
            { 72, 47, 69, 54 }, 10, { faction = "Alliance", title = "Ambassador %s" }),
        RepAch("ambHorde", 762, "Ambassador of the Horde", "Earn exalted reputation with the Horde home cities.",
            { 76, 81, 68, 530 }, 10, { faction = "Horde", title = "Ambassador %s" }),
    } },
    { title = "CLASSIC FACTIONS", list = {
        RepAch("repTimbermaw", 944, "They Love Me In That Tunnel", "Earn exalted status with Timbermaw Hold.", { 576 }, 15),
        RepAch("repArgent", 946, "The Argent Dawn", "Earn exalted status with the Argent Dawn.", { 529 }, 15),
        RepAch("repCenarius", 953, "Guardian of Cenarius", "Earn exalted status with the Cenarion Circle.", { 609 }, 25,
            { title = "%s, Guardian of Cenarius" }),
        RepAch("repHydraxian", 955, "Hydraxian Waterlords", "Earn exalted status with the Hydraxian Waterlords.", { 749 }),
        RepAch("repBrood", 956, "Brood of Nozdormu", "Earn exalted status with the Brood of Nozdormu.", { 910 }),
        RepAch("repZandalar", 957, "Hero of the Zandalar Tribe", "Earn exalted status with the Zandalar Tribe.", { 270 }),
        RepAch("repThorium", nil, "Thorium Brotherhood", "Earn exalted status with the Thorium Brotherhood.", { 59 }, 10,
            { icon = 236681 }),
        RepAch("repShendralar", nil, "Shen'dralar", "Earn exalted status with the Shen'dralar.", { 809 }, 10, { icon = 236681 }),
        RepAch("repWintersaber", nil, "Wintersaber Trainers", "Earn exalted status with the Wintersaber Trainers.", { 589 }, 10,
            { icon = 132252, faction = "Alliance" }),
        RepAch("repDarkmoon", nil, "Darkmoon Faire", "Earn exalted status with the Darkmoon Faire.", { 909 }, 10, { icon = 236681 }),
        insane,
    } },
}

-- Factions new in WoW Forever: exalted with each.
local foreverReps = {}
for _, f in ipairs(ns.FACTIONS) do
    if f[1] >= 2586 and f[1] ~= 2798 and f[1] ~= 2799 then
        foreverReps[#foreverReps + 1] = RepAch("rep" .. f[1], nil, f[2], "Earn exalted status with " .. f[2] .. ".",
            { f[1] }, 10, { icon = 236681 })
    end
end
table.insert(FAC.REP_SECTIONS, { title = "FOREVER FACTIONS", list = foreverReps })

-------------------------------------------------------------------------------
--  Player vs. Player
-------------------------------------------------------------------------------
local STAT_HK = 588
local function HonorKills()
    local life = GetPVPLifetimeStats and GetPVPLifetimeStats()
    if secret(life) then life = nil end
    return math.max(StatNumber(STAT_HK) or 0, tonumber(life) or 0)
end

local function HKAch(key, id, n)
    return { key = key, id = id, series = "hk", pts = 10,
             name = n == 1 and "An Honorable Kill" or (n .. " Honorable Kills"),
             desc = n == 1 and "Achieve an honorable kill." or ("Get %d honorable kills."):format(n),
             progress = function() return math.min(HonorKills(), n), n end }
end

local function StatAch(key, id, name, desc, stat, n, extra)
    local a = { key = key, id = id, name = name, desc = desc, pts = 10,
                progress = function() return math.min(StatNumber(stat) or 0, n), n end }
    for k, v in pairs(extra or {}) do a[k] = v end
    return a
end

local function Flag(key, id, name, desc, extra)
    local a = { key = key, id = id, name = name, desc = desc, pts = 10,
                progress = function() return DB().flags[key] and 1 or 0, 1 end }
    for k, v in pairs(extra or {}) do a[k] = v end
    return a
end

local STAT_WSG, STAT_AB, STAT_AV, STAT_DI = 105, 51, 49, 64176
local DI_ICON = 441150

local battlemaster = { key = "battlemaster", id = 230, name = "Battlemaster", pts = 50, title = "Battlemaster %s",
    desc = "Win Warsong Gulch, Arathi Basin, Alterac Valley and Darkspear Islands.",
    list = { "Warsong Gulch", "Arathi Basin", "Alterac Valley", "Darkspear Islands" } }
local BM_STATS = { ["Warsong Gulch"] = STAT_WSG, ["Arathi Basin"] = STAT_AB, ["Alterac Valley"] = STAT_AV,
    ["Darkspear Islands"] = STAT_DI }
battlemaster.has = function(n) return (StatNumber(BM_STATS[n]) or 0) > 0 end
battlemaster.progress = function()
    local c = 0
    for _, n in ipairs(battlemaster.list) do if battlemaster.has(n) then c = c + 1 end end
    return c, #battlemaster.list
end

-- The other faction's leaders, as the classic capitals have them.
local LEADERS_H = { { "Thrall", 4949 }, { "Cairne Bloodhoof", 3057 }, { "Lady Sylvanas Windrunner", 10181 }, { "Vol'jin", 10540 } }
local LEADERS_A = { { "Highlord Bolvar Fordragon", 1748 }, { "King Magni Bronzebeard", 2784 },
    { "Tyrande Whisperwind", 7999 }, { "High Tinker Mekkatorque", 7937 } }
local forAlliance = DungeonAch({ key = "forAlliance", id = 614, name = "For The Alliance!", all = true,
    desc = "Slay the leaders of the Horde.", bosses = LEADERS_H })
forAlliance.faction, forAlliance.pts = "Alliance", 20
local forHorde = DungeonAch({ key = "forHorde", id = 619, name = "For The Horde!", all = true,
    desc = "Slay the leaders of the Alliance.", bosses = LEADERS_A })
forHorde.faction, forHorde.pts = "Horde", 20

FAC.PVP_SECTIONS = {
    { title = "HONORABLE KILLS", list = {
        HKAch("hk1", 238, 1), HKAch("hk100", 513, 100), HKAch("hk500", 515, 500), HKAch("hk1000", 516, 1000),
        HKAch("hk5000", 512, 5000), HKAch("hk10000", 509, 10000), HKAch("hk25000", 239, 25000),
        HKAch("hk50000", 869, 50000), HKAch("hk100000", 870, 100000),
    } },
    { title = "BATTLEGROUNDS", list = {
        StatAch("wsgWin", 166, "Warsong Gulch Victory", "Win Warsong Gulch.", STAT_WSG, 1, { series = "wsg" }),
        StatAch("wsgVet", 167, "Warsong Gulch Veteran", "Complete 100 victories in Warsong Gulch.", STAT_WSG, 100, { series = "wsg" }),
        StatAch("abWin", 154, "Arathi Basin Victory", "Win Arathi Basin.", STAT_AB, 1, { series = "ab" }),
        StatAch("abVet", 155, "Arathi Basin Veteran", "Complete 100 victories in Arathi Basin.", STAT_AB, 100, { series = "ab" }),
        StatAch("avWin", 218, "Alterac Valley Victory", "Win Alterac Valley.", STAT_AV, 1, { series = "av" }),
        StatAch("avVet", 219, "Alterac Valley Veteran", "Complete 100 victories in Alterac Valley.", STAT_AV, 100, { series = "av" }),
        StatAch("diWin", nil, "Darkspear Islands Victory", "Win Darkspear Islands.", STAT_DI, 1, { series = "di", icon = DI_ICON }),
        StatAch("diVet", nil, "Darkspear Islands Veteran", "Complete 100 victories in Darkspear Islands.", STAT_DI, 100,
            { series = "di", icon = DI_ICON }),
        battlemaster,
    } },
    { title = "IN THE BATTLE", list = {
        StatAch("captureFlag", 199, "Capture the Flag", "Personally carry and capture the flag in Warsong Gulch.", 395, 1),
        StatAch("persistent", 200, "Persistent Defender", "Return 50 flags as a defender in Warsong Gulch.", 586, 50),
        StatAch("towerDefense", 222, "Tower Defense", "Defend 50 towers in Alterac Valley.", 393, 50),
        Flag("grimReaper", 229, "The Grim Reaper", "Get 30 honorable kills in a single battle in any battleground."),
        Flag("wreckingBall", 231, "Wrecking Ball", "Get 20 killing blows without dying in a single battle in any battleground."),
        Flag("wsgFast", 201, "Warsong Expedience", "Win Warsong Gulch in under 7 minutes."),
        Flag("abFast", 159, "Let's Get This Done", "Win Arathi Basin in 6 minutes."),
        Flag("avFast", 226, "The Alterac Blitz", "Win Alterac Valley in 6 minutes.", { pts = 20 }),
    } },
    { title = "BATTLEGROUND REPUTATION", list = {
        RepAch("repFrostwolf", 708, "Hero of the Frostwolf Clan", "Gain exalted reputation with the Frostwolf Clan.", { 729 }, 10, { faction = "Horde" }),
        RepAch("repStormpike", 709, "Hero of the Stormpike Guard", "Gain exalted reputation with the Stormpike Guard.", { 730 }, 10, { faction = "Alliance" }),
        RepAch("repDefilers", 710, "The Defiler", "Gain exalted reputation with The Defilers.", { 510 }, 10, { faction = "Horde" }),
        RepAch("repArathor", 711, "Knight of Arathor", "Gain exalted reputation with The League of Arathor.", { 509 }, 10, { faction = "Alliance" }),
        RepAch("repOutriders", 712, "Warsong Outrider", "Gain exalted reputation with the Warsong Outriders.", { 889 }, 10, { faction = "Horde" }),
        RepAch("repSilverwing", 713, "Silverwing Sentinel", "Gain exalted reputation with the Silverwing Sentinels.", { 890 }, 10, { faction = "Alliance" }),
        RepAch("repRaiders", nil, "Darkspear Raider", "Gain exalted reputation with the Darkspear Raiders.", { 2798 }, 10,
            { faction = "Horde", icon = DI_ICON }),
        RepAch("repTheramore", nil, "Theramore Expeditionary", "Gain exalted reputation with the Theramore Expeditionary Force.",
            { 2799 }, 10, { faction = "Alliance", icon = DI_ICON }),
        RepAch("conqueror", 714, "The Conqueror", "Exalted with the Frostwolf Clan, The Defilers and the Warsong Outriders.",
            { 729, 510, 889 }, 20, { faction = "Horde", title = "Conqueror %s" }),
        RepAch("justicar", 907, "The Justicar", "Exalted with the Stormpike Guard, The League of Arathor and the Silverwing Sentinels.",
            { 730, 509, 890 }, 20, { faction = "Alliance", title = "Justicar %s" }),
    } },
    { title = "WORLD PVP", list = {
        StatAch("duel", 1157, "Duel-icious", "Win a duel against another player.", 319, 1),
        Flag("hugDead", 247, "Make Love, Not Warcraft", "Emote /hug on a dead enemy before they release corpse."),
        forAlliance, forHorde,
    } },
}

-------------------------------------------------------------------------------
--  Feats of Strength (no points, as in WotLK)
-------------------------------------------------------------------------------
-- Owned once counts for good: selling or banking the item later keeps it.
local function Owns(items, spells)
    local d = DB()
    local count = (C_Item and C_Item.GetItemCount) or GetItemCount
    for _, id in ipairs(items or {}) do
        if d.owned[id] then return true end
        if (count and (count(id, true) or 0) > 0) or (IsEquippedItem and IsEquippedItem(id)) then
            d.owned[id] = true
            return true
        end
    end
    for _, id in ipairs(spells or {}) do
        if IsPlayerSpell and IsPlayerSpell(id) then return true end
        -- Mounts live in the mount journal on this client.
        if C_MountJournal and C_MountJournal.GetMountFromSpell then
            local mountID = C_MountJournal.GetMountFromSpell(id)
            if mountID and select(11, C_MountJournal.GetMountInfoByID(mountID)) then return true end
        end
    end
    return false
end

ns.Owns = Owns -- (World Events, outside this block)

local function Feat(key, id, name, desc, items, spells, extra)
    local a = { key = key, id = id, name = name, desc = desc, pts = 0,
                reward = (spells and #spells > 0) and { type = "mount" } or ((items and #items > 0) and { type = "item", item = items[1] } or nil),
                progress = function() return Owns(items, spells) and 1 or 0, 1 end }
    for k, v in pairs(extra or {}) do a[k] = v end
    return a
end


FAC.FEAT_SECTIONS = {
    { title = "LEGENDARY", list = {
        Feat("thunderfury", 428, "Thunderfury, Blessed Blade of the Windseeker", "Wielder of Thunderfury, Blessed Blade of the Windseeker.", { 19019 }),
        Feat("sulfuras", 429, "Sulfuras, Hand of Ragnaros", "Wielder of Sulfuras, Hand of Ragnaros.", { 17182 }),
        Feat("atiesh", 425, "Atiesh, Greatstaff of the Guardian", "Wielder of Atiesh, Greatstaff of the Guardian.",
            { 22589, 22630, 22631, 22632 }),
    } },
    { title = "MOUNTS", list = {
        Feat("deathcharger", 729, "Deathcharger's Reins", "Obtain the Deathcharger's Reins from Baron Rivendare in Stratholme.",
            { 13335 }, { 17481 }),
        Feat("zulianTiger", 880, "Swift Zulian Tiger", "Obtain the Swift Zulian Tiger from High Priest Thekal in Zul'Gurub.",
            { 19902 }, { 24252 }),
        Feat("razzashi", 881, "Swift Razzashi Raptor", "Obtain the Swift Razzashi Raptor from Bloodlord Mandokir in Zul'Gurub.",
            { 19872 }, { 24242 }),
        Feat("frostsaber", 3356, "Winterspring Frostsaber", "Obtain a Winterspring Frostsaber.", { 13086 }, { 17229 }),
        Feat("dreadsteed", 2357, "Dreadsteed of Xoroth", "Completed the Dreadsteed of Xoroth warlock quest.", nil, { 23161 }),
        Feat("charger", 2358, "Charger", "Completed the paladin quest to obtain a Charger.", nil, { 23214 }),
        Feat("redQiraji", 424, "Why? Because It's Red", "Obtain a Red Qiraji Resonating Crystal.", { 21321 }, { 26054 }),
    } },
    { title = "TITLES & RARE FINDS", list = {
        Feat("scarabLord", 416, "Scarab Lord", "Opened the gates of Ahn'Qiraj.", { 21176 }, { 26656 },
            { title = "Scarab Lord %s" }),
        Feat("admiral", 871, "Avast Ye, Admiral!", "Obtain the Bloodsail Admiral's Hat.", { 12185 }, nil,
            { title = "Bloodsail Admiral %s" }),
        Feat("fifthElement", 2496, "The Fifth Element", "Obtain an Aqual Quintessence.", { 17333 }),
    } },
}

-------------------------------------------------------------------------------
--  The Forever client's own achievements, read from the game
-------------------------------------------------------------------------------
local function FvInfo(ids)
    if not GetAchievementInfo then return nil end
    local best
    for _, id in ipairs(ids) do
        local ok, aid, _, _, completed = pcall(GetAchievementInfo, id)
        if ok and aid then
            if completed then return id, true end
            best = best or id
        end
    end
    return best, false
end

local function FvCriteria(id)
    local out = {}
    if not (id and GetAchievementNumCriteria and GetAchievementCriteriaInfo) then return out end
    local ok, n = pcall(GetAchievementNumCriteria, id)
    if not ok or not n then return out end
    for i = 1, n do
        local ok2, name, _, done = pcall(GetAchievementCriteriaInfo, id, i)
        if ok2 and name and name ~= "" then out[#out + 1] = { name, done } end
    end
    return out
end

-- The Forever client's own achievements go into the matching categories;
-- the ones that repeat an addon achievement are left out.
local FV_SKIP = { ["Conqueror of the Lair"] = true, -- the addon's Onyxia's Lair
    ["Explore Azeroth"] = true, ["Explore Eastern Kingdoms"] = true, ["Explore Kalimdor"] = true,
    ["Explorer"] = true }
local FV_SKIP_GROUP = { Reputations = true } -- Master of <battleground>: the addon's BG reputations
local function SectionIn(sections, title, atStart)
    for _, sec in ipairs(sections) do if sec.title == title then return sec end end
    local sec = { title = title, list = {} }
    if atStart then table.insert(sections, 1, sec) else sections[#sections + 1] = sec end
    return sec
end
local function FvAch(e)
    -- 10 points like the rest of the addon (the client stores 0 for these).
    local a = { key = "fv" .. e.ids[1], icon = e.icon, name = e.name, desc = e.desc, pts = 10, native = true, nativeIDs = e.ids }
    a.progress = function()
        local id, done = FvInfo(e.ids)
        if done then return 1, 1 end
        local crit = FvCriteria(id)
        if #crit > 1 then
            local c = 0
            for _, it in ipairs(crit) do if it[2] then c = c + 1 end end
            return c, #crit
        end
        return 0, 1
    end
    a.dynamicList = function() return FvCriteria((FvInfo(e.ids))) end
    return a
end
for _, sec in ipairs(ns.FOREVER_ACH) do
    for _, e in ipairs(sec.list) do
        if not FV_SKIP[e.name] and not FV_SKIP_GROUP[e.group] then
            local a = FvAch(e)
            local target
            if sec.title == "CLASSES" then
                a.series = "fvclass" .. e.group
                target = SectionIn(SECTIONS, "CLASSES")
            elseif sec.title == "TRADESKILLS" then
                a.series = "fvprof" .. e.group
                target = SectionIn(PROF_SECTIONS, "PROFESSION RANKS")
                -- Right after the general ranks, not after First Aid.
                if PROF_SECTIONS[#PROF_SECTIONS] == target and #target.list == 0 then
                    table.remove(PROF_SECTIONS)
                    table.insert(PROF_SECTIONS, 2, target)
                end
            elseif sec.title == "DUNGEONS" then
                a.series = "fvspelunker"
                target = SectionIn(DUNGEON_SECTIONS, "SPELUNKER")
                -- With the dungeons, before the raids.
                if #target.list == 0 then
                    for i, sec in ipairs(DUNGEON_SECTIONS) do
                        if sec == target then table.remove(DUNGEON_SECTIONS, i) break end
                    end
                    for i, sec in ipairs(DUNGEON_SECTIONS) do
                        if sec.title == "RAIDS" then table.insert(DUNGEON_SECTIONS, i, target) break end
                    end
                end
            elseif sec.title == "RAIDS" then
                target = SectionIn(DUNGEON_SECTIONS, "RAIDS")
            elseif e.group == "Ranks" then
                a.series = "fvrank"
                target = SectionIn(FAC.PVP_SECTIONS, "HONOR RANKS")
            elseif e.group == "Season Journey" then
                a.series = "fvseason"
                target = SectionIn(FAC.PVP_SECTIONS, "SEASON JOURNEY")
            elseif sec.title == "PLAYER VS. PLAYER" then
                target = SectionIn(FAC.PVP_SECTIONS, "WORLD PVP")
            elseif e.group == "Beta" then
                -- A feat of strength: no points, like the other feats.
                a.pts = 0
                target = SectionIn(FAC.FEAT_SECTIONS, "FOREVER BETA")
            else
                target = SectionIn(QUEST_SECTIONS, "QUEST LINES")
            end
            target.list[#target.list + 1] = a
        end
    end
end
end

-- Shared with the next parts.
FAC.QF = QF
FAC.PROF_SECTIONS = PROF_SECTIONS
FAC.BOSS_IDS = BOSS_IDS
FAC.BOSS_BY_NAME = BOSS_BY_NAME
FAC.BOSS_ACH = BOSS_ACH
FAC.DUNGEON_SECTIONS = DUNGEON_SECTIONS
