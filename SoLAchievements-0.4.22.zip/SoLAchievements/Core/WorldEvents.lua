-------------------------------------------------------------------------------
--  SoLAchievements
--
--  The WotLK General achievements that the WoW Forever world still allows,
--  tracked per character. State that the game can report (level, riding,
--  mounts, pets, tabard) is read at any time; everything that happens
--  (money looted, critters loved, pests killed, books read, food and drink,
--  falls, loot rolls) counts from the moment the addon is installed.
-------------------------------------------------------------------------------

local ADDON, ns = ...
local FAC = ns.Split_SoLAchievements -- (what the parts of SoLAchievements.lua share)
local BOSS_BY_NAME, BOSS_IDS, CRITTERS, Count, CountLore, DB, DUNGEON_SECTIONS, EXPLORE_SECTIONS, GetItemInfoInstant, NoteSubzone, PESTS, PEST_ORDER, PROF_SECTIONS, QF, QUEST_SECTIONS, SECTIONS, TAG, TrackDailies, secret = FAC.BOSS_BY_NAME, FAC.BOSS_IDS, FAC.CRITTERS, FAC.Count, FAC.CountLore, FAC.DB, FAC.DUNGEON_SECTIONS, FAC.EXPLORE_SECTIONS, FAC.GetItemInfoInstant, FAC.NoteSubzone, FAC.PESTS, FAC.PEST_ORDER, FAC.PROF_SECTIONS, FAC.QF, FAC.QUEST_SECTIONS, FAC.SECTIONS, FAC.TAG, FAC.TrackDailies, FAC.secret
-------------------------------------------------------------------------------
--  World Events: the seasonal holidays. Which one is on comes from the
--  game's calendar (its holiday ID, else its title); without a calendar the
--  state is unknown, never guessed. Each achievement is the event's own
--  item, owned once (kept for good, as for the Feats), and shows only when
--  this client knows the item: content Forever does not have stays hidden.
-------------------------------------------------------------------------------
local EV = {}
do
local EVENTS = {
    { key = "hallowsend", name = "Hallow's End", ids = { 324 }, titles = { "Hallow's End" } },
    { key = "winterveil", name = "Feast of Winter Veil", ids = { 141 }, titles = { "Feast of Winter Veil" } },
    { key = "lunar", name = "Lunar Festival", ids = { 327 }, titles = { "Lunar Festival" } },
    { key = "childrens", name = "Children's Week", ids = { 201 }, titles = { "Children's Week" } },
    { key = "darkmoon", name = "Darkmoon Faire", ids = { 374, 375, 376 }, titles = { "Darkmoon Faire" } },
    -- (no holiday id known for it here: found by the calendar's title only)
    { key = "fishingcontest", name = "Stranglethorn Fishing Extravaganza", ids = {},
      titles = { "Stranglethorn Fishing Extravaganza", "Fishing Extravaganza" } },
}
local EVENT_BY_KEY = {}
for _, e in ipairs(EVENTS) do EVENT_BY_KEY[e.key] = e end
ns.EVENTS, ns.EVENT_BY_KEY = EVENTS, EVENT_BY_KEY

-- Whether this client knows an item at all (Forever may not have it).
local function ItemKnown(id)
    return C_Item and C_Item.GetItemInfoInstant and C_Item.GetItemInfoInstant(id) ~= nil
end
local function AnyKnown(items)
    for _, id in ipairs(items) do if ItemKnown(id) then return true end end
    return false
end
local function ItemIcon(id) return C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(id) or nil end

-- One item (or one of several) owned once.
local function EventItem(key, eventKey, name, desc, items, pts)
    return { key = key, event = eventKey, name = name, desc = desc, pts = pts or 10, icon = ItemIcon(items[1]),
             tracking = "Owned once (bags, bank, equipped), from the day the addon saw it.",
             requires = function() return AnyKnown(items) end,
             progress = function() return ns.Owns(items) and 1 or 0, 1 end }
end
-- A collection: each named item owned once.
local function EventSet(key, eventKey, name, desc, set, pts)
    local names, byName = {}, {}
    for _, it in ipairs(set) do names[#names + 1] = it[2]; byName[it[2]] = it[1] end
    local items = {}
    for _, it in ipairs(set) do items[#items + 1] = it[1] end
    return { key = key, event = eventKey, name = name, desc = desc, pts = pts or 10, icon = ItemIcon(items[1]), list = names,
             tracking = "Each one owned once (bags, bank, equipped), from the day the addon saw it.",
             requires = function() return AnyKnown(items) end,
             has = function(n) return ns.Owns({ byName[n] }) end,
             progress = function()
                 local n = 0
                 for _, id in ipairs(items) do if ns.Owns({ id }) then n = n + 1 end end
                 return n, #items
             end }
end

local HALLOWED_WANDS = {
    { 20397, "Pirate" }, { 20398, "Ninja" }, { 20399, "Leper Gnome" }, { 20409, "Ghost" },
    { 20410, "Bat" }, { 20411, "Skeleton" }, { 20413, "Random" }, { 20414, "Wisp" },
}
local FLIMSY_MASKS = {
    { 20561, "Male Dwarf" }, { 20562, "Female Dwarf" }, { 20391, "Male Gnome" }, { 20392, "Female Gnome" },
    { 20566, "Male Human" }, { 20565, "Female Human" }, { 20564, "Male Night Elf" }, { 20563, "Female Night Elf" },
    { 20570, "Male Orc" }, { 20569, "Female Orc" }, { 20572, "Male Tauren" }, { 20571, "Female Tauren" },
    { 20568, "Male Troll" }, { 20567, "Female Troll" }, { 20573, "Male Undead" }, { 20574, "Female Undead" },
}

local EVENT_SECTIONS = {
    { title = "HALLOW'S END", event = "hallowsend", list = {
        EventItem("hallowTreat", "hallowsend", "Trick or Treat!", "Get a Treat Bag from an innkeeper during Hallow's End.", { 20393 }),
        EventSet("hallowWands", "hallowsend", "Wand Waver", "Collect every Hallowed Wand.", HALLOWED_WANDS),
        EventSet("hallowMasks", "hallowsend", "A Mask for All Occasions", "Collect the Flimsy mask of every race.", FLIMSY_MASKS),
    } },
    { title = "FEAST OF WINTER VEIL", event = "winterveil", list = {
        EventItem("veilSnowball", "winterveil", "Snow Day", "Get a Snowball during the Feast of Winter Veil.", { 17202 }),
    } },
    { title = "LUNAR FESTIVAL", event = "lunar", list = {
        EventItem("lunarCoin", "lunar", "Honoring the Ancestors", "Honor an Elder and receive a Coin of Ancestry.", { 21100 }),
    } },
    { title = "CHILDREN'S WEEK", event = "childrens", list = {
        EventItem("childOrphan", "childrens", "A Week of Kindness", "Look after an orphan during Children's Week.", { 18597, 18598 }),
    } },
    { title = "DARKMOON FAIRE", event = "darkmoon", list = {
        EventItem("dmfTicket", "darkmoon", "Step Right Up", "Earn a Darkmoon Faire Prize Ticket.", { 19182 }),
    } },
    { title = "FISHING EXTRAVAGANZA", event = "fishingcontest", list = {
        EventItem("stvTastyfish", "fishingcontest", "Tastyfish", "Catch a Speckled Tastyfish during the Stranglethorn Fishing Extravaganza.", { 19807 }),
    } },
}

-- Which events are on today: [key] = { state = "active" | "inactive" |
-- "unknown", source }. Read from the calendar once it has its data.
local eventState = {}
ns.eventState = eventState
local function ReadCalendar()
    if not (C_Calendar and C_Calendar.GetNumDayEvents and C_Calendar.GetDayEvent and C_DateAndTime
        and C_DateAndTime.GetCurrentCalendarTime) then
        for _, e in ipairs(EVENTS) do eventState[e.key] = { state = "unknown", source = "no calendar on this client" } end
        return
    end
    local ok = pcall(function()
        local now = C_DateAndTime.GetCurrentCalendarTime()
        -- (the calendar's own month, put back on today's when its window is
        -- closed: only when it differs, since setting it updates the calendar
        -- again and that would bring us back here)
        local shown = C_Calendar.GetMonthInfo and C_Calendar.GetMonthInfo(0)
        if shown and (shown.month ~= now.month or shown.year ~= now.year) then
            if not (CalendarFrame and CalendarFrame:IsShown()) and C_Calendar.SetAbsMonth then
                C_Calendar.SetAbsMonth(now.month, now.year)
            end
            return
        end
        local found = {}
        for i = 1, C_Calendar.GetNumDayEvents(0, now.monthDay) or 0 do
            local ev = C_Calendar.GetDayEvent(0, now.monthDay, i)
            if ev and ev.calendarType == "HOLIDAY" then
                for _, e in ipairs(EVENTS) do
                    for _, id in ipairs(e.ids) do if ev.eventID == id then found[e.key] = "calendar ID " .. id end end
                    if not found[e.key] and type(ev.title) == "string" and not secret(ev.title) then
                        for _, t in ipairs(e.titles) do if ev.title:find(t, 1, true) then found[e.key] = "calendar title" end end
                    end
                end
            end
        end
        -- The next 14 days: an event starting soon is upcoming (in days).
        local soon = {}
        local info = C_Calendar.GetMonthInfo and C_Calendar.GetMonthInfo(0)
        local numDays = (info and info.numDays) or 31
        for ahead = 1, 14 do
            local day, off = now.monthDay + ahead, 0
            if day > numDays then day, off = day - numDays, 1 end
            for i = 1, C_Calendar.GetNumDayEvents(off, day) or 0 do
                local ev = C_Calendar.GetDayEvent(off, day, i)
                if ev and ev.calendarType == "HOLIDAY" then
                    for _, e in ipairs(EVENTS) do
                        local hit = false
                        for _, id in ipairs(e.ids) do if ev.eventID == id then hit = true end end
                        if not hit and type(ev.title) == "string" and not secret(ev.title) then
                            for _, t in ipairs(e.titles) do if ev.title:find(t, 1, true) then hit = true end end
                        end
                        if hit and not soon[e.key] then soon[e.key] = ahead end
                    end
                end
            end
        end
        for _, e in ipairs(EVENTS) do
            if found[e.key] then eventState[e.key] = { state = "active", source = found[e.key] }
            elseif soon[e.key] then eventState[e.key] = { state = "upcoming", source = "calendar", inDays = soon[e.key] }
            else eventState[e.key] = { state = "inactive", source = "calendar" } end
        end
    end)
    if not ok then
        for _, e in ipairs(EVENTS) do eventState[e.key] = { state = "unknown", source = "calendar error" } end
    end
end
ns.ReadEventCalendar = ReadCalendar
local function EventActive(key) return eventState[key] and eventState[key].state == "active" end
ns.EventActive = EventActive
EV.EVENTS, EV.SECTIONS, EV.ReadCalendar, EV.Active = EVENTS, EVENT_SECTIONS, ReadCalendar, EventActive
ns.EVENT_SECTIONS = EVENT_SECTIONS -- (the selftest checks their mapping)
end
local EVENT_SECTIONS = EV.SECTIONS

-- Categories, one per tab.
local CATEGORY_SECTIONS = {
    general = SECTIONS,
    quests = QUEST_SECTIONS,
    exploration = EXPLORE_SECTIONS,
    professions = PROF_SECTIONS,
    dungeons = DUNGEON_SECTIONS,
    reputation = FAC.REP_SECTIONS,
    pvp = FAC.PVP_SECTIONS,
    events = EVENT_SECTIONS,
    feats = FAC.FEAT_SECTIONS,
    native = {},
}
local CATEGORY_ORDER = { "general", "quests", "exploration", "professions", "dungeons", "reputation", "pvp", "events", "feats", "native" }

local ALL = {}
local SERIES = {} -- [series] = achievements in order
for _, catKey in ipairs(CATEGORY_ORDER) do
    for _, sec in ipairs(CATEGORY_SECTIONS[catKey]) do
        for _, a in ipairs(sec.list) do
            ALL[#ALL + 1] = a
            if a.series then
                SERIES[a.series] = SERIES[a.series] or {}
                table.insert(SERIES[a.series], a)
            end
        end
    end
end

-- Account-wide data (characters, settings), saved for every character.
local function AccountDB()
    SoLAchievementsDB = SoLAchievementsDB or {}
    local a = SoLAchievementsDB
    a.chars = a.chars or {}
    a.settings = a.settings or {}
    return a
end

local function Settings() return AccountDB().settings end

-- Faction-only achievements show for that faction alone; ones that need
-- another addon (requires) only while it is loaded.
local function Available(a)
    if a.requires then
        local ok, yes = pcall(a.requires)
        if not ok or not yes then return false end
    end
    return not a.faction or a.faction == UnitFactionGroup("player")
end

-- Earned on this character, or on any character with the account view on.
local function Earned(key)
    local t = DB().done[key]
    if t or not Settings().accountView then return t end
    local best, bestExact, bestName
    for name, c in pairs(AccountDB().chars) do
        local ct = c.done and c.done[key]
        if ct then
            local meta = c.doneMeta and c.doneMeta[key]
            local exact = not (meta and meta.exact == false)
            -- (an exact date wins over an unknown one; then the earlier; then the name)
            if not best or (exact and not bestExact) or (exact == bestExact and (ct < best or (ct == best and name < bestName))) then
                best, bestExact, bestName = ct, exact, name
            end
        end
    end
    return best
end

-- How an achievement was earned: { time, exact, source, character } or nil.
-- source: "observed" (seen happen), "backfill" (found in the history, date
-- unknown), "manual", "native"; character: who, in the account view.
do
    local function Meta(d, key) return d.doneMeta and d.doneMeta[key] end
    function ns.Completion(key)
        local d = DB()
        local t = d.done[key]
        if t then
            local m = Meta(d, key) or {}
            return { time = t, exact = m.exact ~= false, source = m.source or "observed", character = UnitName("player") }
        end
        if not Settings().accountView then return nil end
        local best
        for name, c in pairs(AccountDB().chars) do
            local ct = c.done and c.done[key]
            if ct then
                local m = Meta(c, key) or {}
                local exact = m.exact ~= false
                if not best or (exact and not best.exact) or (exact == best.exact and (ct < best.time or (ct == best.time and name < best.key))) then
                    best = { time = ct, exact = exact, source = m.source or "observed", character = c.name or name, key = name }
                end
            end
        end
        return best
    end
    -- "10-12-2026", or "Previously earned" when the date is not known.
    function ns.EarnedText(key, t)
        local c = ns.Completion(key)
        if c and not c.exact then return "Previously earned" end
        t = t or (c and c.time)
        return t and date("%m-%d-%Y", t) or ""
    end
    -- Marks how this character earned it (Complete and the history pass).
    function ns.NoteEarned(key, source, exact)
        local d = DB()
        d.doneMeta = d.doneMeta or {}
        d.doneMeta[key] = { source = source, exact = exact and true or false }
    end

    -- The evaluator: one achievement's state, each part under pcall, kept for
    -- the frame (the list, the sort, the tracker and tooltips ask the same
    -- thing in one refresh). A failure is reported once, never thrown.
    local cache, cacheAt = {}, -1
    local reported = {}
    -- How far the number can be trusted, and whether it can be rebuilt from
    -- the game alone (a new install, another computer):
    --   exact       read from the game each time        recover: full
    --   integration another addon's data (API)  recover: full
    --   observed    seen as it happens (kills, criteria) recover: partial
    --               (owned items, lists) or none (kills)
    local function Reliability(a)
        if tostring(a.key):match("^qf_") then return "integration", "full" end
        -- (a meta: as good as its children, which are mostly kills)
        if a.meta then return "observed", "partial" end
        if a.kill then return "observed", "none" end
        if a.list or a.tracking then return "observed", "partial" end
        return "exact", "full"
    end
    ns.Reliability = Reliability
    function ns.Evaluate(a)
        local now = GetTime()
        if now ~= cacheAt then wipe(cache); cacheAt = now end
        local r = cache[a]
        if r then return r end
        r = { available = Available(a) }
        local ok, cur, need = pcall(a.progress)
        if not ok then
            r.error, r.blocked, cur, need = tostring(cur), true, 0, 1
            if not reported[a.key] then
                reported[a.key] = true
                if FAC.debugOn then print(TAG .. " progress error for " .. a.key .. ": " .. r.error) end
            end
        elseif secret(cur) or secret(need) or type(cur) ~= "number" or type(need) ~= "number" then
            r.blocked, cur, need = true, 0, 1
        end
        need = math.max(1, need)
        r.current, r.required = cur, need
        r.percent = math.min(1, cur / need)
        r.remaining = math.max(0, need - cur)
        r.completed = Earned(a.key) and true or false
        r.reliability, r.recoverability = Reliability(a)
        cache[a] = r
        return r
    end
    function ns.ClearEvaluations() wipe(cache); cacheAt = -1 end
end

local EARN_HOOKS, CHECK_HOOKS = {}, {} -- filled by the modules
local VIEWS = {}                        -- [tab] = function(child, width) return height
local SLASH = {}                        -- [command] = function(rest)
local COMPARE = {}                      -- name, done: another player's earned keys
local LINK = { fn = function(a) return "|cffffd100[" .. a.name .. "]|r" end }

-- World Events: the calendar read at login (and when it updates); during an
-- event, once a day, a line with what is left of it.
function EV.Counts(key)
    local left, total = 0, 0
    for _, sec in ipairs(EV.SECTIONS) do
        if sec.event == key then
            for _, a in ipairs(sec.list) do
                if Available(a) then
                    total = total + 1
                    if not Earned(a.key) then left = left + 1 end
                end
            end
        end
    end
    return left, total
end
ns.EventCounts = EV.Counts
function EV.Remind()
    local S = Settings()
    if S.eventReminder ~= true then return end
    S.eventReminded = S.eventReminded or {}
    local today = date("%Y-%m-%d")
    for _, e in ipairs(EV.EVENTS) do
        if EV.Active(e.key) and S.eventReminded[e.key] ~= today then
            local left, total = EV.Counts(e.key)
            if total > 0 then
                S.eventReminded[e.key] = today
                print(TAG .. (" %s is on: %d of %d event %s still to earn (World Events)."):format(e.name, left, total,
                    total == 1 and "achievement" or "achievements"))
            end
        end
    end
end
do
    local f = CreateFrame("Frame")
    f:RegisterEvent("PLAYER_LOGIN")
    pcall(f.RegisterEvent, f, "CALENDAR_UPDATE_EVENT_LIST")
    local pending
    f:SetScript("OnEvent", function(_, event)
        if event == "PLAYER_LOGIN" then
            if C_Calendar and C_Calendar.OpenCalendar then pcall(C_Calendar.OpenCalendar) end
            C_Timer.After(8, function() EV.ReadCalendar(); EV.Remind() end)
            return
        end
        if pending then return end
        pending = true
        C_Timer.After(1, function()
            pending = nil
            -- The window redrawn only when an event's state changed.
            local before = {}
            for k, v in pairs(ns.eventState) do before[k] = v.state end
            EV.ReadCalendar()
            local changed = false
            for k, v in pairs(ns.eventState) do if before[k] ~= v.state then changed = true end end
            EV.Remind()
            if changed and ns.FA and ns.FA.Refresh then ns.FA.Refresh() end
        end)
    end)
end

-------------------------------------------------------------------------------
--  Completion and the toast
-------------------------------------------------------------------------------
-- (FAC.RefreshWindow: shared, set below) -- the window, below
-- (FAC.toast: shared, set below)

-- Shared widgets for this addon.
local Kit = ns.Alpha

local function Accent() return Kit.Accent() end

local queue; queue, FAC.showing = {}, false
local function ShowNextToast()
    local a = table.remove(queue, 1)
    if not a then FAC.showing = false return end
    FAC.showing = true
    if not FAC.toast then
        FAC.toast = CreateFrame("Button", nil, UIParent)
        ns.WrathStyle.Toast(FAC.toast, Kit)
        -- Size and place on whole pixels (PixelUtil), so the 1 px border is even.
        if PixelUtil then
            PixelUtil.SetSize(FAC.toast, 360, 68)
            PixelUtil.SetPoint(FAC.toast, "BOTTOM", UIParent, "BOTTOM", 0, Settings().toastBottom or 158)
        else
            FAC.toast:SetSize(360, 68)
            FAC.toast:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, Settings().toastBottom or 158)
        end
        FAC.toast:SetFrameStrata("HIGH")
        FAC.toast:SetScript("OnClick", function(self)
            if self.achievementKey and ns.FA then ns.FA.OpenSearch(self.achievementName) end
        end)
    end
    FAC.toast.achievementKey, FAC.toast.achievementName = a.key, a.name
    FAC.toast.icon:SetTexture((a.icon or ns.ICONS[a.id] or 236376))
    FAC.toast.name:SetText(a.name)
    FAC.toast.pts:SetText(tostring(a.pts))
    -- In: rises 18 units while fading in.
    local baseY = Settings().toastBottom or 158
    local function Place(y)
        if PixelUtil then PixelUtil.SetPoint(FAC.toast, "BOTTOM", UIParent, "BOTTOM", 0, y)
        else FAC.toast:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, y) end
    end
    FAC.toast:Show()
    if ns.FireAPI then ns.FireAPI("TOAST_SHOWN", FAC.toast) end
    Kit.Tween("toastIn", 0.35, function(e)
        FAC.toast:SetAlpha(e)
        Place(baseY - 18 * (1 - e))
    end, function()
        Place(baseY)
        Kit.RealignBorders()
    end)
    if Settings().sound ~= false and PlaySound and SOUNDKIT then
        local kit = ns.FA.ToastSoundKit()
        if kit then PlaySound(kit, "Master") end
    end
    -- Out: fades away, then the next one in the queue.
    C_Timer.After(Settings().toastTime or 4, function()
        Kit.Tween("toastOut", 0.4, function(e) FAC.toast:SetAlpha(1 - e) end, function()
            FAC.toast:Hide()
            C_Timer.After(0.2, ShowNextToast)
        end)
    end)
end

local function Complete(a)
    local d = DB()
    if d.done[a.key] then return end
    d.done[a.key] = time()
    ns.NoteEarned(a.key, "observed", true)
    ns.earnedSinceView = true
    d.tracked[a.key] = nil
    print(TAG .. " earned: " .. LINK.fn(a))
    if not a.native and Settings().toasts ~= false then
        queue[#queue + 1] = a
        if not FAC.showing then ShowNextToast() end
    end
    for _, fn in ipairs(EARN_HOOKS) do pcall(fn, a) end
    if Settings().screenshot and Screenshot then C_Timer.After(1, Screenshot) end
end

-- Until the first quiet pass over the character's history has run, every
-- check is quiet: events fire right after login (entering the world, bags)
-- and would otherwise toast everything the character already had.
local historyReady = false

-- Events ask for a check; the asks are gathered and one pass runs a moment
-- later (bags, money and zone events often come in bursts). In combat only
-- a kill gets its pass (kill achievements only); the rest waits for the end
-- of combat (PLAYER_REGEN_ENABLED queues it).
local checks = { dirty = false, kill = false, quiet = false, queued = false }
local QueueChecks
do
local CHECK_DELAY = 0.5

-- One pass over every achievement (killsOnly: just the ones a kill earns).
local function RunChecks(quiet, killsOnly)
    if not historyReady then quiet = true end
    ns.ClearEvaluations()
    for _, a in ipairs(ALL) do
        if not a.nativeID and (not killsOnly or a.kill) and not DB().done[a.key] and Available(a) then
            local ev = ns.Evaluate(a)
            if ns.NoteProgress and not ev.blocked then ns.NoteProgress(a, ev, quiet) end
            if not ev.blocked and ev.current >= ev.required then
                -- (found in the history: earned, the date not known)
                if quiet then DB().done[a.key] = time(); ns.NoteEarned(a.key, "backfill", false) else Complete(a) end
            end
        end
    end
    if FAC.RefreshWindow then FAC.RefreshWindow("checks") end
    for _, fn in ipairs(CHECK_HOOKS) do pcall(fn) end
end

local function Fighting()
    local f = (InCombatLockdown and InCombatLockdown()) or (UnitAffectingCombat and UnitAffectingCombat("player"))
    if secret(f) then return true end
    return f and true or false
end

local function FlushChecks()
    checks.queued = false
    if not (checks.dirty or checks.kill) then return end
    if Fighting() then
        if checks.kill then
            checks.kill = false
            RunChecks(checks.quiet, true)
        end
        return -- the full pass runs once combat ends
    end
    local quiet = checks.quiet
    checks.dirty, checks.kill, checks.quiet = false, false, false
    RunChecks(quiet)
end

QueueChecks = function()
    if checks.queued then return end
    checks.queued = true
    C_Timer.After(CHECK_DELAY, FlushChecks)
end

-- quiet: earned without toasts, right away (login and reset passes).
-- kill: asked by a kill, so it may run in combat.
FAC.CheckAll = function(quiet, kill)
    if quiet then RunChecks(true) return end
    -- Asked before the history pass: quiet, as it would have been then.
    if not historyReady then checks.quiet = true end
    checks.dirty = true
    if kill then checks.kill = true end
    QueueChecks()
end
end

-------------------------------------------------------------------------------
--  Trackers
-------------------------------------------------------------------------------
local ev = CreateFrame("Frame")
local handlers = {}
-- Registration is guarded: an event this client does not have would stop
-- the whole file from loading.
local function On(event, fn)
    if pcall(ev.RegisterEvent, ev, event) then handlers[event] = fn end
end
ev:SetScript("OnEvent", function(_, event, ...) handlers[event](...) end)

-- Login: anything already true counts quietly (no toast storm), then checks.
On("PLAYER_LOGIN", function()
    TrackDailies()
    CountLore()
    NoteSubzone()
    -- Achievements added in a new version are taken in quietly once (no
    -- toast storm for what was already true); two passes so the continent
    -- and Loremaster metas see the zones and continents earned in the first.
    local DATA_VERSION = 11 -- Hall of Thanes quest history
    local d = DB()
    if (d.dataVersion or (d.initialised and 1 or 0)) < DATA_VERSION then
        local before = Count(d.done)
        -- The map knows explored areas only once the player is in the world.
        C_Timer.After(3, function()
            FAC.CheckAll(true)
            FAC.CheckAll(true)
            d.initialised = true
            d.dataVersion = DATA_VERSION
            historyReady = true
            print(TAG .. " ready: " .. Count(d.done) .. " earned (" .. (Count(d.done) - before)
                .. " new from your history). /solach to open.")
            if ns.FA and ns.FA.OnReady then ns.FA.OnReady(Count(d.done) - before) end
        end)
    else
        historyReady = true
        FAC.CheckAll(false)
        if ns.FA and ns.FA.OnReady then ns.FA.OnReady() end
    end
end)
On("PLAYER_LEVEL_UP", function() C_Timer.After(1, function() FAC.CheckAll() end) end)
On("QUEST_TURNED_IN", function()
    C_Timer.After(1, function() TrackDailies(); CountLore(); FAC.CheckAll() end)
end)
for _, e in ipairs({ "ZONE_CHANGED", "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA" }) do
    On(e, function() if NoteSubzone() then FAC.CheckAll() end end)
end
On("PLAYER_EQUIPMENT_CHANGED", function() FAC.CheckAll() end)
On("BAG_UPDATE_DELAYED", function() FAC.CheckAll() end)
On("SKILL_LINES_CHANGED", function() FAC.CheckAll() end)
On("LEARNED_SPELL_IN_TAB", function() FAC.CheckAll() end)
On("LEARNED_SPELL_IN_SKILL_LINE", function() FAC.CheckAll() end)
if C_MountJournal then On("NEW_MOUNT_ADDED", function() FAC.CheckAll() end) end
if C_PetJournal then On("NEW_PET_ADDED", function() FAC.CheckAll() end) end
On("COMPANION_LEARNED", function() FAC.CheckAll() end)

-- Money looted, from the loot money messages (solo loot and party shares).
local function ParseMoney(msg)
    local function amount(word)
        local n = msg:match("(%d+)%s*" .. word)
        return tonumber(n) or 0
    end
    local g = amount(_G.GOLD or "Gold")
    local s = amount(_G.SILVER or "Silver")
    local c = amount(_G.COPPER or "Copper")
    return g * 10000 + s * 100 + c
end
-- The client keeps a "Gold looted" statistic (ID 333) for the whole life of
-- the character, as a money string with coin icons. When it is there it is
-- the better number; our own count covers clients without it.
local STAT_GOLD_LOOTED = 333
local function StatMoney()
    local text = GetStatistic and GetStatistic(STAT_GOLD_LOOTED)
    if type(text) ~= "string" or secret(text) then return nil end
    local total, found = 0, false
    for n, coin in text:gmatch("(%d+)%s*|T[^|]-UI%-(%a+)Icon") do
        local v = tonumber(n) or 0
        coin = coin:lower()
        if coin == "gold" then total = total + v * 10000
        elseif coin == "silver" then total = total + v * 100
        else total = total + v end
        found = true
    end
    if not found then
        local plain = tonumber((text:gsub("%D", "")))
        if plain then return plain end
        return nil
    end
    return total
end

local function SyncMoney()
    local stat = StatMoney()
    if stat and stat > DB().money then DB().money = stat end
end

On("CHAT_MSG_MONEY", function(msg)
    if not msg or secret(msg) then return end
    local copper = ParseMoney(msg)
    if copper > 0 then
        DB().money = DB().money + copper
        SyncMoney()
        FAC.CheckAll()
    end
end)
On("PLAYER_ENTERING_WORLD", function()
    bgSeen = false
    C_Timer.After(2, function() SyncMoney(); FAC.CheckAll() end)
end)

-- /love on critters: the emote echo names the target.
-- /love on critters. Two ways in: the emote call itself, and the chat echo
-- of it. The target just has to be a creature (not a player) named like a
-- critter on the list; creature types read differently on this client.
FAC.debugOn = false -- /fach debug
local lastLove = 0

local function LoveTarget(source)
    if GetTime() - lastLove < 0.5 then return end
    local target = UnitExists("target") and UnitName("target")
    if FAC.debugOn then
        print(TAG .. (" /love seen (%s), target: %s"):format(source, tostring(target)))
    end
    if not target or secret(target) then return end
    local isPlayer = UnitIsPlayer("target")
    if isPlayer and not secret(isPlayer) then return end
    for _, name in ipairs(CRITTERS) do
        if target == name then
            lastLove = GetTime()
            if not DB().critters[name] then
                DB().critters[name] = true
                print(TAG .. " loved a " .. name .. " (" .. Count(DB().critters) .. "/" .. #CRITTERS .. ")")
                FAC.CheckAll()
            elseif FAC.debugOn then
                print(TAG .. " " .. name .. " already loved")
            end
            return
        end
    end
    if FAC.debugOn then print(TAG .. " " .. target .. " is not on the critter list") end
end

if DoEmote then
    hooksecurefunc("DoEmote", function(token)
        if type(token) == "string" and token:upper() == "LOVE" then LoveTarget("emote") end
    end)
end
if C_ChatInfo and C_ChatInfo.PerformEmote then
    hooksecurefunc(C_ChatInfo, "PerformEmote", function(token)
        if type(token) == "string" and token:upper() == "LOVE" then LoveTarget("emote") end
    end)
end

On("CHAT_MSG_TEXT_EMOTE", function(msg, sender)
    if not msg or secret(msg) then return end
    local me = UnitName("player")
    if sender and not secret(sender) and sender ~= me and not sender:find("^" .. me .. "%-") then return end
    local lower = msg:lower()
    if lower:find("love", 1, true) or lower:find("adore", 1, true) then LoveTarget("chat") end
end)

-- Pest Control: your target dying in front of you.
local function NpcID(guid)
    if not guid or secret(guid) then return nil end
    local kind, _, _, _, _, id = strsplit("-", guid)
    if kind ~= "Creature" then return nil end
    return tonumber(id)
end

-- By creature ID, or by name when Forever numbers the creature differently.
local PEST_NAMES = {}
for _, n in pairs(PESTS) do PEST_NAMES[n] = true end

local function NotePest(id, unitName)
    local name = id and PESTS[id]
    if not name and unitName and PEST_NAMES[unitName] then name = unitName end
    if FAC.debugOn then
        print(TAG .. (" kill seen: %s, id %s, counted as %s"):format(tostring(unitName), tostring(id), tostring(name)))
    end
    if name and not DB().pests[name] then
        DB().pests[name] = true
        print(TAG .. " pest slain: " .. name .. " (" .. Count(DB().pests) .. "/" .. #PEST_ORDER .. ")")
        FAC.CheckAll(nil, true)
    end
end

-- The combat log is off limits to addons on this client (registering for it
-- is a blocked action), so a pest counts when your target dies.
-- Event driven, so a one-hit kill right after targeting is still seen: the
-- target is remembered the moment it is picked, and checked on every health
-- change. A slow tick backs the events up.
local watchedTarget, watchedAlive, watchedName, watchedID

-- When the target vanishes on its own in combat (dead targets are cleared
-- automatically on many setups), a pest that was alive counts as slain:
-- in combat the client does not say whether it died.
local function NoteBoss(id, unitName)
    local key = (id and BOSS_IDS[id]) and id or (unitName and BOSS_BY_NAME[unitName])
    if not key or DB().bosses[key] then return end
    DB().bosses[key] = time()
    print(TAG .. " boss slain: " .. (BOSS_IDS[key] or unitName))
    FAC.CheckAll(nil, true)
end

local watchedRare

local function NoteRare(unitName)
    if not unitName or DB().rares[unitName] then return end
    DB().rares[unitName] = time()
    print(TAG .. " rare slain: " .. unitName .. " (" .. Count(DB().rares) .. ")")
    FAC.CheckAll(nil, true)
end

local function NoteKill(id, unitName)
    NotePest(id, unitName)
    NoteBoss(id, unitName)
    if watchedRare then NoteRare(unitName) end
end

local function Tracked(id, name)
    return (id and (PESTS[id] or BOSS_IDS[id])) or PEST_NAMES[name or ""] or BOSS_BY_NAME[name or ""] or watchedRare
end

local function TargetGone()
    if watchedTarget and watchedAlive and Tracked(watchedID, watchedName) then
        local fighting = InCombatLockdown() or UnitAffectingCombat("player")
        if secret(fighting) then fighting = true end
        if fighting then
            if FAC.debugOn then print(TAG .. " target cleared in combat: counting the kill") end
            NoteKill(watchedID, watchedName)
        end
    end
    watchedTarget, watchedAlive = nil, false
end

local function WatchTarget()
    if not UnitExists("target") then TargetGone() return end
    local guid = UnitGUID("target")
    if guid == nil or secret(guid) then
        if FAC.debugOn then print(TAG .. " target GUID is hidden by the client") end
        return
    end
    local dead = UnitIsDead("target")
    -- In combat the client hides whether the target is dead: wait, the
    -- check runs again the moment combat ends.
    if secret(dead) then
        if FAC.debugOn then print(TAG .. " target state hidden in combat, checking after combat") end
        return
    end
    if guid ~= watchedTarget then
        local name = UnitName("target")
        watchedTarget, watchedAlive = guid, not dead
        watchedName = (name and not secret(name)) and name or nil
        watchedID = NpcID(guid)
        local class = UnitClassification("target")
        watchedRare = watchedID and not secret(class) and (class == "rare" or class == "rareelite") or nil
        if FAC.debugOn then
            print(TAG .. (" target: %s, id %s, %s"):format(tostring(watchedName), tostring(watchedID),
                dead and "dead" or "alive"))
        end
        return
    end
    if watchedAlive and dead then
        watchedAlive = false
        -- Yours if nobody else had tagged it.
        local denied = UnitIsTapDenied and UnitIsTapDenied("target")
        if denied and not (secret(denied)) then
            if FAC.debugOn then print(TAG .. " kill not yours (tagged by someone else)") end
            return
        end
        NoteKill(watchedID, watchedName)
    end
end

-- Make Love, Not Warcraft: /hug on a dead enemy player.
local function HugTarget()
    if not UnitExists("target") then return end
    local isPlayer, enemy, dead = UnitIsPlayer("target"), UnitIsEnemy("player", "target"), UnitIsDead("target")
    if secret(isPlayer) or secret(enemy) or secret(dead) then return end
    if isPlayer and enemy and dead and not DB().flags.hugDead then
        DB().flags.hugDead = true
        FAC.CheckAll()
    end
end
if DoEmote then
    hooksecurefunc("DoEmote", function(token)
        if type(token) == "string" and token:upper() == "HUG" then HugTarget() end
    end)
end
if C_ChatInfo and C_ChatInfo.PerformEmote then
    hooksecurefunc(C_ChatInfo, "PerformEmote", function(token)
        if type(token) == "string" and token:upper() == "HUG" then HugTarget() end
    end)
end

-- Battlegrounds: the final scoreboard, read once per battle.
local bgSeen = false
local function MyScore()
    local me = UnitName("player")
    local n = GetNumBattlefieldScores and GetNumBattlefieldScores() or 0
    for i = 1, n do
        local name, kb, hk, deaths
        if C_PvP and C_PvP.GetScoreInfo then
            local info = C_PvP.GetScoreInfo(i)
            if info then name, kb, hk, deaths = info.name, info.killingBlows, info.honorableKills, info.deaths end
        else
            name, kb, hk, deaths = GetBattlefieldScore(i)
        end
        if name and not secret(name) and (name == me or name:match("^([^%-]+)") == me) then return kb or 0, hk or 0, deaths or 0 end
    end
end

On("UPDATE_BATTLEFIELD_SCORE", function()
    local winner = GetBattlefieldWinner and GetBattlefieldWinner()
    if winner == nil or bgSeen then return end
    bgSeen = true
    local flags = DB().flags
    local kb, hk, deaths = MyScore()
    if hk and hk >= 30 then flags.grimReaper = true end
    if kb and kb >= 20 and deaths == 0 then flags.wreckingBall = true end
    local team = UnitFactionGroup("player") == "Horde" and 0 or 1
    if winner == team then
        local mins = (GetBattlefieldInstanceRunTime and GetBattlefieldInstanceRunTime() or 0) / 60000
        local zone = GetRealZoneText()
        if mins > 0 then
            if zone == "Warsong Gulch" and mins < 7 then flags.wsgFast = true end
            if zone == "Arathi Basin" and mins <= 6 then flags.abFast = true end
            if zone == "Alterac Valley" and mins <= 6 then flags.avFast = true end
        end
    end
    C_Timer.After(2, function() FAC.CheckAll() end)
end)
On("UPDATE_BATTLEFIELD_STATUS", function()
    if GetBattlefieldWinner and GetBattlefieldWinner() ~= nil and RequestBattlefieldScoreData then RequestBattlefieldScoreData() end
end)

for _, e in ipairs({ "UPDATE_FACTION", "PLAYER_PVP_KILLS_CHANGED", "PLAYER_PVP_RANK_CHANGED", "ACHIEVEMENT_EARNED",
    "NEW_MOUNT_ADDED" }) do
    On(e, function() C_Timer.After(0.5, function() FAC.CheckAll() end) end)
end

-- Boss fights the client reports (the target may not be the boss at the end).
On("ENCOUNTER_END", function(_, name, _, _, success)
    if success == 1 and name and not secret(name) then NoteBoss(nil, name) end
end)
On("BOSS_KILL", function(_, name)
    if name and not secret(name) then NoteBoss(nil, name) end
end)

-- Fishing: schools, the city diplomat and the rare fish, from the loot window.
local BOBBER = 35591
local SCHOOLSET = {}
for _, id in ipairs(ns.SCHOOLS) do SCHOOLSET[id] = true end
local RARESET = {}
for _, f in ipairs(ns.RARE_FISH) do RARESET[f[2]] = true end

local fishLoot = false -- the open loot window is a catch (Quick Fish logs it)

On("LOOT_OPENED", function()
    if not (IsFishingLoot and IsFishingLoot()) then return end
    fishLoot = true
    local d = DB()
    d.fished = (d.fished or 0) + 1
    local zone = GetRealZoneText and GetRealZoneText() or GetZoneText()
    if zone and not secret(zone) then d.fishedIn[zone] = true end
    for slot = 1, (GetNumLootItems() or 0) do
        local link = GetLootSlotLink(slot)
        local item = link and tonumber(link:match("item:(%d+)"))
        if item and RARESET[item] then d.rareFish[item] = true end
        if GetLootSourceInfo then
            local guid = GetLootSourceInfo(slot)
            if guid and not secret(guid) then
                local kind, _, _, _, _, id = strsplit("-", guid)
                id = tonumber(id)
                -- Pools are game objects; plain casts loot from the bobber.
                if kind == "GameObject" and id and (SCHOOLSET[id] or id ~= BOBBER) then d.school = true end
            end
        end
    end
    FAC.CheckAll()
end)

-- Quick Fish writes its catch log while the loot window is open: once it
-- closes, its totals are summed again for the Quick Fish achievements.
On("LOOT_CLOSED", function()
    if not fishLoot then return end
    fishLoot = false
    if not QF.Loaded() then return end
    QF.at = -10
    C_Timer.After(0.2, function() FAC.CheckAll() end)
end)

On("PLAYER_TARGET_CHANGED", WatchTarget)
On("PLAYER_REGEN_ENABLED", function()
    C_Timer.After(0.2, WatchTarget)
    -- The checks held back during combat.
    if checks.dirty or checks.kill then QueueChecks() end
end)
local healthWatch = CreateFrame("Frame")
healthWatch:RegisterUnitEvent("UNIT_HEALTH", "target")
healthWatch:SetScript("OnEvent", WatchTarget)
-- (a backup tick, twice a second, only while a creature is targeted: the
-- events catch most, the tick a one-hit kill that came with no update)
do
    local ticker
    local function Lifecycle()
        local want = UnitExists("target") and not UnitIsPlayer("target")
        if secret(want) then want = true end
        if want and not ticker then ticker = C_Timer.NewTicker(0.5, WatchTarget)
        elseif not want and ticker then ticker:Cancel(); ticker = nil end
    end
    local f = CreateFrame("Frame")
    f:RegisterEvent("PLAYER_TARGET_CHANGED")
    f:RegisterEvent("PLAYER_ENTERING_WORLD")
    f:SetScript("OnEvent", function() C_Timer.After(0, Lifecycle) end)
end

-- Well Read: the title of any book or plaque you open.
local BOOKSET = {}
for _, b in ipairs(ns.BOOKS) do BOOKSET[b:lower()] = b end
On("ITEM_TEXT_BEGIN", function()
    local title = ItemTextGetItem and ItemTextGetItem()
    if not title or secret(title) then return end
    local b = BOOKSET[title:lower()]
    if b and not DB().books[b] then
        DB().books[b] = true
        print(TAG .. " read: " .. b .. " (" .. Count(DB().books) .. "/" .. #ns.BOOKS .. ")")
        FAC.CheckAll()
    end
end)

-- Food and drink: a Food & Drink item leaving the bags while you eat or
-- drink. Beverages are told apart by the item's spell or its name.
local DRINK_WORDS = { "water", "juice", "milk", "ale", "wine", "brew", "rum", "grog", "mead", "cider", "tea",
    "coffee", "stout", "beer", "lager", "whiskey", "vodka", "punch", "nectar", "tonic", "beverage", "drink",
    "cocoa", "spirits", "port", "draught", "pilsner", "sherry", "liquor", "moonshine", "bubbly" }
local function IsDrink(id, name)
    local spell = (C_Item and C_Item.GetItemSpell and C_Item.GetItemSpell(id)) or (GetItemSpell and GetItemSpell(id))
    if spell == "Drink" or spell == "Refreshment" then return true end
    if spell == "Food" then return false end
    local lower = (name or ""):lower()
    for _, w in ipairs(DRINK_WORDS) do
        if lower:find(w, 1, true) then return true end
    end
    return false
end

local foodSnap = {}
local function SnapFood()
    local snap = {}
    for bag = 0, 4 do
        for slot = 1, (C_Container.GetContainerNumSlots(bag) or 0) do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID then
                local _, _, _, _, _, c, s = GetItemInfoInstant(info.itemID)
                if c == 0 and s == 5 then
                    snap[info.itemID] = (snap[info.itemID] or 0) + (info.stackCount or 1)
                end
            end
        end
    end
    return snap
end

local busy = false -- vendor, mail, trade or bank open: items leave for other reasons
for _, e in ipairs({ "MERCHANT_SHOW", "MAIL_SHOW", "TRADE_SHOW", "BANKFRAME_OPENED", "AUCTION_HOUSE_SHOW" }) do
    On(e, function() busy = true end)
end
for _, e in ipairs({ "MERCHANT_CLOSED", "MAIL_CLOSED", "TRADE_CLOSED", "BANKFRAME_CLOSED", "AUCTION_HOUSE_CLOSED" }) do
    On(e, function() busy = false; foodSnap = SnapFood() end)
end

local function OnBags()
    local now = SnapFood()
    if not busy and not CursorHasItem() then
        for id, n in pairs(foodSnap) do
            if (now[id] or 0) == n - 1 then
                local name = (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(id)) or ("item " .. id)
                local d = DB()
                local book = IsDrink(id, name) and d.drinks or d.foods
                if not book[id] then
                    book[id] = name
                    print(TAG .. ((book == d.drinks) and " new drink: " or " new dish: ") .. name
                        .. " (" .. Count(book) .. "/" .. ((book == d.drinks) and 25 or 50) .. ")")
                end
            end
        end
    end
    foodSnap = now
    FAC.CheckAll()
end
handlers.BAG_UPDATE_DELAYED = OnBags
C_Timer.After(2, function() foodSnap = SnapFood() end)

-- Going Down?: a fall of about 2.6 seconds (65 yards) that you survive.
local fallStart
local faller = CreateFrame("Frame")
faller.tick = 0 -- (a field, not a local: the main chunk is at Lua's 200-local limit)
faller:SetScript("OnUpdate", function(self, elapsed)
    self.tick = self.tick + elapsed
    if self.tick < 0.1 then return end
    self.tick = 0
    if DB().fall then self:SetScript("OnUpdate", nil); self:UnregisterAllEvents(); self:Hide() return end
    -- (standing still and on the ground: asleep until the next move or jump)
    if not self.moving and not fallStart and not IsFalling() then self:Hide() return end
    if IsFalling() then
        fallStart = fallStart or GetTime()
    elseif fallStart then
        local t = GetTime() - fallStart
        fallStart = nil
        if t >= 2.6 then
            C_Timer.After(0.5, function()
                if not UnitIsDeadOrGhost("player") and not DB().fall then
                    DB().fall = true
                    FAC.CheckAll()
                end
            end)
        end
    end
end)

-- (it watches only while you move or jump: a fall needs one or the other)
faller:Hide()
faller:RegisterEvent("PLAYER_STARTED_MOVING")
faller:RegisterEvent("PLAYER_STOPPED_MOVING")
faller:SetScript("OnEvent", function(self, event)
    self.moving = event == "PLAYER_STARTED_MOVING"
    if self.moving and not DB().fall then self:Show() end
end)
if JumpOrAscendStart then hooksecurefunc("JumpOrAscendStart", function() if not DB().fall then faller:Show() end end) end

-- Greedy / Needy: a 100 on a superior or better item, then winning it.
local function Pattern(fmt)
    if not fmt then return nil end
    fmt = fmt:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")
    fmt = fmt:gsub("%%%%s", "(.+)"):gsub("%%%%d", "(%%d+)")
    return "^" .. fmt .. "$"
end
local P_NEED = Pattern(_G.LOOT_ROLL_ROLLED_NEED)
local P_GREED = Pattern(_G.LOOT_ROLL_ROLLED_GREED)
local P_WON = Pattern(_G.LOOT_ROLL_YOU_WON)
local pending = {} -- [link] = "needy" | "greedy"

local function Quality(link)
    local q = link and select(3, ((C_Item and C_Item.GetItemInfo) or GetItemInfo)(link))
    return q or 0
end

On("CHAT_MSG_LOOT", function(msg)
    if not msg or secret(msg) then return end
    local me = UnitName("player")
    for kind, pat in pairs({ needy = P_NEED, greedy = P_GREED }) do
        if pat then
            local roll, link, who = msg:match(pat)
            if roll and tonumber(roll) == 100 and (who == me or who == _G.YOU) and Quality(link) >= 3 then
                pending[link] = kind
            end
        end
    end
    if P_WON then
        local link = msg:match(P_WON)
        if link and pending[link] then
            DB()[pending[link]] = true
            pending[link] = nil
            FAC.CheckAll()
        end
    end
end)

-- Shared with the next parts.
FAC.EV = EV
FAC.CATEGORY_SECTIONS = CATEGORY_SECTIONS
FAC.CATEGORY_ORDER = CATEGORY_ORDER
FAC.ALL = ALL
FAC.SERIES = SERIES
FAC.AccountDB = AccountDB
FAC.Settings = Settings
FAC.Available = Available
FAC.Earned = Earned
FAC.EARN_HOOKS = EARN_HOOKS
FAC.CHECK_HOOKS = CHECK_HOOKS
FAC.VIEWS = VIEWS
FAC.SLASH = SLASH
FAC.COMPARE = COMPARE
FAC.LINK = LINK
FAC.Kit = Kit
FAC.Accent = Accent
FAC.queue = queue
FAC.ShowNextToast = ShowNextToast
FAC.NpcID = NpcID
FAC.PEST_NAMES = PEST_NAMES
FAC.BOOKSET = BOOKSET
FAC.IsDrink = IsDrink
