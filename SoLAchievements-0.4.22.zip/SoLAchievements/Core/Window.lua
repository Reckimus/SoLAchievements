-------------------------------------------------------------------------------
--  SoLAchievements
--
--  The WotLK General achievements that the WoW Forever world still allows,
--  tracked per character. State that the game can report (level, riding,
--  mounts, pets, tabard) is read at any time; everything that happens
--  (money looted, critters loved, pests killed, books read, food and drink,
--  falls, loot rolls) counts from the moment the addon is installed.
-------------------------------------------------------------------------------

local ADDON, ns = ...
local Skin = ns.WrathStyle
local FAC = ns.Split_SoLAchievements -- (what the parts of SoLAchievements.lua share)
local ALL, Accent, AccountDB, Available, BOOKSET, BOSS_ACH, BOSS_BY_NAME, BOSS_IDS, CATEGORY_ORDER, CATEGORY_SECTIONS, CHECK_HOOKS, COMPARE, CRITTERS, Count, DB, EARN_HOOKS, EV, Earned, IsDrink, Kit, LINK, NpcID, PESTS, PEST_NAMES, QF = FAC.ALL, FAC.Accent, FAC.AccountDB, FAC.Available, FAC.BOOKSET, FAC.BOSS_ACH, FAC.BOSS_BY_NAME, FAC.BOSS_IDS, FAC.CATEGORY_ORDER, FAC.CATEGORY_SECTIONS, FAC.CHECK_HOOKS, FAC.COMPARE, FAC.CRITTERS, FAC.Count, FAC.DB, FAC.EARN_HOOKS, FAC.EV, FAC.Earned, FAC.IsDrink, FAC.Kit, FAC.LINK, FAC.NpcID, FAC.PESTS, FAC.PEST_NAMES, FAC.QF
local SERIES, SLASH, Settings, ShowNextToast, StatText, TAG, VIEWS, ekZones, kalZones, otherZones, queue, secret = FAC.SERIES, FAC.SLASH, FAC.Settings, FAC.ShowNextToast, FAC.StatText, FAC.TAG, FAC.VIEWS, FAC.ekZones, FAC.kalZones, FAC.otherZones, FAC.queue, FAC.secret
-------------------------------------------------------------------------------
--  Window
-------------------------------------------------------------------------------
local WIN_W, WIN_H = 780, 550
-- Leave room for the header art above the frame and the footer tabs below it.
local COLLECTIONS_TOP_PAD, FOOTER_CLEARANCE = 16, 31
-- Categories in a sidebar on the left, as in the WotLK achievement window.
local SIDE_W = 196
local CONTENT_X = 20 + SIDE_W + 14            -- left edge of the cards
local PAD = 20                                -- one padding on every side
local CHILD_W = WIN_W - (CONTENT_X - 20) - 9      -- scroll child (cards sit 20 in, end PAD from the edge)
local CATEGORIES = {
    { key = "summary", label = "Summary" },
    { key = "zone", label = "Current Zone" },
    { key = "general", label = "General" },
    { key = "quests", label = "Quests" },
    { key = "exploration", label = "Exploration" },
    { key = "professions", label = "Professions" },
    { key = "dungeons", label = "Dungeons & Raids" },
    { key = "reputation", label = "Reputation" },
    { key = "pvp", label = "PvP" },
    { key = "events", label = "World Events" },
    { key = "feats", label = "Feats of Strength" },
    { key = "native", label = "Game Records" },
}
local ROW_H = 68
local win
local expanded = {}

local function Money(c)
    return (GetCoinTextureString and GetCoinTextureString(c)) or (math.floor(c / 10000) .. "g")
end

local function TotalPoints()
    local done, all = 0, 0
    local n, avail = 0, 0
    for _, a in ipairs(ALL) do
        if Available(a) then
            avail = avail + 1
            all = all + a.pts
            if Earned(a.key) then done, n = done + a.pts, n + 1 end
        end
    end
    return done, all, n, avail
end

-- Search across every tab: achievement name, description, and the entries
-- of its list (critters, pests, books, food and drink seen).
local search = ""

local function ListMatches(a)
    if search == "" then return false end
    if a.list then
        for _, n in ipairs(a.list) do
            if n:lower():find(search, 1, true) then return true end
        end
    elseif a.seen then
        for _, n in pairs(a.seen()) do
            if tostring(n):lower():find(search, 1, true) then return true end
        end
    end
    return false
end

local function Matches(a)
    if search == "" then return true end
    if a.name:lower():find(search, 1, true) or a.desc:lower():find(search, 1, true) then return true end
    return ListMatches(a)
end

-- What the list shows, as in the WotLK achievement window: from a series,
-- the highest earned tier and the next one; the filter keeps all, the
-- completed or the incomplete cards. A search shows every tier that matches.
local function VisibleOf(list)
    local filter = DB().filter or "all"
    local out = {}
    local bySeries = {}
    for _, a in ipairs(list) do
        if a.series then
            local s = bySeries[a.series]
            if not s then
                s = {}
                bySeries[a.series] = s
            end
            if Earned(a.key) then s.top = a elseif not s.next then s.next = a end
        end
    end
    for _, a in ipairs(list) do
        local done = Earned(a.key) and true or false
        local show = Available(a) -- another faction's achievements stay hidden
        if not show then
            show = false
        elseif search ~= "" then
            show = Matches(a)
        elseif a.series and filter ~= "all" and filter ~= "completed" and filter ~= "incomplete" then
            local s = bySeries[a.series]
            show = (a == s.top) or (a == s.next)
        else
            show = true
        end
        if show and filter == "completed" then show = done end
        if show and filter == "incomplete" then show = not done end
        -- Near completion, the watch list, the excluded ones (Browser.lua);
        -- an excluded one is hidden by every other filter.
        if show and ns.SmartFilter then
            local smart = ns.SmartFilter(filter, a, done)
            if smart ~= nil then show = smart end
        end
        if show then out[#out + 1] = a end
    end
    local sort = Settings().sort
    if sort == "name" then
        table.sort(out, function(p, q) return p.name < q.name end)
    elseif sort == "progress" then
        -- Closest to done first; earned ones last.
        local frac = {}
        for _, a in ipairs(out) do
            if Earned(a.key) then
                frac[a] = 2
            else
                -- (the evaluator: safe, cached for the pass)
                frac[a] = 1 - ns.Evaluate(a).percent
            end
        end
        table.sort(out, function(p, q)
            if frac[p] ~= frac[q] then return frac[p] < frac[q] end
            return p.name < q.name
        end)
    end
    return out
end

-- Points shown on an earned series tier: the whole series up to it.
local function SeriesPoints(a)
    if not a.series then return a.pts end
    local sum = 0
    for _, t in ipairs(SERIES[a.series]) do
        sum = sum + t.pts
        if t == a then break end
    end
    return sum
end

local function ToggleTrack(a)
    local d = DB()
    if Earned(a.key) then
        print(TAG .. " " .. a.name .. " is already earned.")
        return
    end
    if not d.tracked[a.key] and Count(d.tracked) >= 10 then
        print(TAG .. " you can track up to 10 achievements.")
        return
    end
    d.tracked[a.key] = (not d.tracked[a.key]) or nil
    if ns.FireAPI then ns.FireAPI("PINNED_CHANGED", a.key, d.tracked[a.key] and true or false) end
    if FAC.RefreshWindow then FAC.RefreshWindow() end
    for _, fn in ipairs(CHECK_HOOKS) do pcall(fn) end
end

-- Shift-click: the achievement as text into the open chat box. Readable for
-- everyone; players with the addon see it as a link.
local function InsertLink(a)
    local box = ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()
    if not box then return false end
    if LINK.insert then LINK.insert(box, a) else box:Insert("[ach:" .. a.name .. "]") end
    return true
end

local function CardTooltip(owner, a)
    local r, g, b = Accent()
    Kit.TipOwner(owner, GameTooltip, 330)
    GameTooltip:AddLine(a.name, 1, 1, 1)
    ns.Alpha.AddTooltipLine(GameTooltip, a.desc, nil, nil, nil)
    if a.title then
        ns.Alpha.AddTooltipLine(GameTooltip, "Reward: title \"" .. a.title:format(UnitName("player")) .. "\"", r, g, b)
    end
    if COMPARE.name then
        local t = COMPARE.done and COMPARE.done[a.key]
        GameTooltip:AddLine(COMPARE.name .. (t and ": earned" or ": not earned"), t and r or 0.6, t and g or 0.6, t and b or 0.6)
    end
    if Settings().showIDs then
        GameTooltip:AddLine("key " .. a.key .. (a.id and ("   WotLK ID " .. a.id) or ""), 0.55, 0.55, 0.55)
    end
    -- How it is earned and tracked, the series around it (Browser.lua).
    if ns.TooltipExtra then pcall(ns.TooltipExtra, GameTooltip, a) end
    GameTooltip:AddLine(" ")
    ns.Alpha.AddTooltipLine(GameTooltip, "Right-click: pin, watch, exclude, explain   Shift-click: link in chat", 0.55, 0.55, 0.55)
    GameTooltip:Show()
end

-- Grows or shrinks one card; everything listed after it slides along.
-- win.placed holds each element's spot as built (cards at their full height).
local function AnimateCard(entry, fromH, toH, done)
    local placed, idx = win.placed or {}, nil
    for i, e in ipairs(placed) do if e == entry then idx = i break end end
    if not idx then if done then done() end return end
    local card = entry.frame
    Kit.Tween("cardExpand", 0.22, function(e)
        local h = Kit.Lerp(fromH, toH, e)
        card:SetHeight(h)
        local shift = h - entry.fullH
        for i = idx + 1, #placed do
            local p = placed[i]
            p.frame:ClearAllPoints()
            p.frame:SetPoint("TOPLEFT", p.x, p.y - shift)
        end
    end, function()
        Kit.RealignBorders()
        if done then done() end
    end)
end

-- The cards' pool: one set of cards per list, each card's pieces made once
-- and filled on every refresh (no frame is made per refresh: WoW never
-- frees one). Section headers likewise, by title.
do
    local pools = setmetatable({}, { __mode = "k" })
    local function MakeCard(child)
        local C = Kit.COLORS
        local card = CreateFrame("Button", nil, child)
        -- Always clipped: switching clipping on only for the animation
        -- redraws the card and nudges the icon by a pixel.
        card:SetClipsChildren(true)
        card:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        card.bg = card:CreateTexture(nil, "BACKGROUND")
        card.bg:SetAllPoints()
        card.edge = Kit.MakeBorder(card, unpack(C.edge))
        card.tr = Kit.MakeFont(card, 9, nil, 1, 1, 1, 1)
        card.tr:SetPoint("TOPRIGHT", -12, -5)
        card.tr:SetText("TRACKED")
        card.cmp = Kit.MakeFont(card, 10, nil, C.dim[1], C.dim[2], C.dim[3], 1)
        card.cmp:SetPoint("BOTTOMRIGHT", -12, 5)
        -- The icon in a frame of its own (the accent once earned).
        card.iconBox = ns.FramedIcon(card, 40)
        card.icon = card.iconBox.icon
        card.iconEdge = card.iconBox.edge
        card.name = Kit.RoleFont(card, "achName", 14, nil, 1, 1, 1, 1)
        card.name:SetPoint("TOPLEFT", card.icon, "TOPRIGHT", 12, 0)
        card.desc = Kit.RoleFont(card, "achDesc", 11, nil, C.dim[1], C.dim[2], C.dim[3], 1)
        card.desc:SetPoint("TOPLEFT", card.name, "BOTTOMLEFT", 0, -4)
        card.desc:SetPoint("RIGHT", card, "RIGHT", -160, 0)
        card.desc:SetMaxLines(2)
        card.name:SetPoint("RIGHT", card, "RIGHT", -170, 0)
        card.name:SetJustifyH("LEFT")
        card.name:SetWordWrap(false)
        card.desc:SetJustifyH("LEFT")
        card.desc:SetWordWrap(true)
        card.badge = CreateFrame("Frame", nil, card)
        card.badge:SetSize(30, 20)
        card.bbg = card.badge:CreateTexture(nil, "BACKGROUND")
        card.bbg:SetAllPoints()
        card.pts = Kit.MakeFont(card.badge, 12, nil, 1, 1, 1, 1)
        card.pts:SetPoint("CENTER")
        card.right = Kit.MakeFont(card, 12, nil, 1, 1, 1, 1)
        card.track = card:CreateTexture(nil, "ARTWORK")
        card.track:SetColorTexture(1, 1, 1, 0.1)
        card.track:SetSize(84, 4)
        card.track:SetPoint("TOPRIGHT", card.right, "BOTTOMRIGHT", 0, -5)
        card.fill = card:CreateTexture(nil, "OVERLAY")
        card.fill:SetPoint("LEFT", card.track, "LEFT")
        card.chev = CreateFrame("Frame", nil, card)
        card.chev:SetSize(10, 10)
        card.chev:SetPoint("LEFT", card.name, "RIGHT", 8, 0)
        card.chevBars = { card.chev:CreateTexture(nil, "OVERLAY"), card.chev:CreateTexture(nil, "OVERLAY") }
        for _, bar in ipairs(card.chevBars) do bar:SetSize(6, 1.5) end
        card.sep = card:CreateTexture(nil, "ARTWORK")
        card.sep:SetHeight(1)
        card.sep:SetColorTexture(1, 1, 1, 0.08)
        Skin.Card(card)
        card.minis, card.marks, card.lines = {}, {}, {}
        return card
    end
    function ns.ReleaseCards(child)
        local p = pools[child]
        if p then
            p.used = 0
            for _, c in ipairs(p.cards) do c:Hide() end
        end
        for _, h in pairs(child.__headers or {}) do h:Hide() end
        if child.__empty then child.__empty:Hide() end
    end
    function ns.AcquireCard(child)
        local p = pools[child]
        if not p then p = { cards = {}, used = 0 }; pools[child] = p end
        p.used = p.used + 1
        local c = p.cards[p.used]
        if not c then c = MakeCard(child); p.cards[p.used] = c end
        c:Show()
        return c
    end
    -- A series tier's small icon (pooled on its card).
    function ns.CardMini(card, k)
        local m = card.minis[k]
        if not m then
            m = CreateFrame("Frame", nil, card)
            m:SetSize(30, 30)
            local well = m:CreateTexture(nil, "BACKGROUND")
            well:SetAllPoints()
            well:SetColorTexture(0, 0, 0, 0.5)
            m.tex = m:CreateTexture(nil, "ARTWORK")
            m.tex:SetPoint("TOPLEFT", 2, -2)
            m.tex:SetPoint("BOTTOMRIGHT", -2, 2)
            m.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
            m.edge = Kit.MakeBorder(m, 1, 1, 1, 0.6)
            m.pts = Kit.MakeFont(card, 11, nil, 1, 1, 1, 1)
            m.pts:SetPoint("TOP", m, "BOTTOM", 0, -3)
            m:EnableMouse(true)
            m:SetScript("OnLeave", function() GameTooltip:Hide() end)
            card.minis[k] = m
        end
        m:Show()
        m.pts:Show()
        return m
    end
    -- A criterion line of an open list (pooled on its card).
    function ns.CardLine(card, k)
        local l = card.lines[k]
        if not l then
            l = { mark = card:CreateTexture(nil, "OVERLAY"), fs = Kit.RoleFont(card, "achDesc", 12, nil, 1, 1, 1, 1) }
            l.mark:SetSize(6, 6)
            l.fs:SetPoint("LEFT", l.mark, "RIGHT", 8, 0)
            l.fs:SetJustifyH("LEFT")
            l.fs:SetWordWrap(false)
            card.lines[k] = l
        end
        l.mark:Show()
        l.fs:Show()
        return l
    end
    -- A section header, made once per title.
    function ns.CardHeader(child, title, y)
        child.__headers = child.__headers or {}
        local h = child.__headers[title]
        if not h then
            h = Kit.W:SectionHeader(child, title, y)
            child.__headers[title] = h
        end
        h:ClearAllPoints()
        h:SetPoint("TOPLEFT", child, "TOPLEFT", 20, y)
        h:Show()
        return h, 34
    end
end

local function BuildList(child, width)
    ROW_H = Settings().compact and 55 or 68
    local placed = {}
    win.placed = placed
    win.barFrac = win.barFrac or {}
    local barFrac = win.barFrac
    local r, g, b = Accent()
    local C = Kit.COLORS
    local W = Kit.W
    local GAP = 6
    local y = 0
    local _, h
    local any = false
    local sections = {}
    -- Summary, Statistics and Settings draw their own page.
    if search == "" and VIEWS[win.cat or ""] then
        child:SetHeight(math.max(1, VIEWS[win.cat](child, width) or 1))
        return
    end
    if search ~= "" then
        for _, catKey in ipairs(CATEGORY_ORDER) do
            for _, sec in ipairs(CATEGORY_SECTIONS[catKey]) do sections[#sections + 1] = sec end
        end
    elseif win.cat == "zone" and ns.ZoneSections then
        sections = ns.ZoneSections()
    else
        sections = CATEGORY_SECTIONS[win.cat or "general"]
    end
    local seen = {}
    for _, sec in ipairs(sections) do
        local visible = VisibleOf(sec.list)
        if search ~= "" then
            local unique = {}
            for _, a in ipairs(visible) do
                if not seen[a.key] then
                    seen[a.key] = true
                    unique[#unique + 1] = a
                end
            end
            visible = unique
        end
        if #visible > 0 then
            any = true
            local header
            local title = sec.title
            if sec.event and ns.eventState[sec.event] then
                local st = ns.eventState[sec.event].state
                local es = ns.eventState[sec.event]
                -- The name as words (never in capitals), the one on now in the accent.
                local name = Kit.TitleCase(title)
                if st == "active" then
                    title = ("|cff%02x%02x%02x%s|r  ·  on now"):format(math.floor(r * 255 + 0.5), math.floor(g * 255 + 0.5),
                        math.floor(b * 255 + 0.5), name)
                else
                    title = name .. ((st == "upcoming" and ("  ·  in " .. tostring(es.inDays) .. (es.inDays == 1 and " day" or " days")))
                        or (st == "inactive" and "  ·  not running" or ""))
                end
            end
            header, h = ns.CardHeader(child, title, y)
            placed[#placed + 1] = { frame = header, x = 20, y = y }
            y = y - h
        end
        for _, a in ipairs(visible) do
            local done = Earned(a.key)
            local evr = ns.Evaluate(a)
            local cur, need = evr.current, evr.required
            local dyn = a.dynamicList and a.dynamicList()
            if dyn and #dyn < 2 then dyn = nil end
            local hasList = a.list or a.seen or dyn
            -- An earned tier of a series expands to the series strip.
            local hasSeries = a.series and done and SERIES[a.series][1] ~= a
            local expandable = hasList or hasSeries
            local open = expandable and (expanded[a.key] or (hasList and ListMatches(a)))

            -- One card holds the row and, when open, what it expands to.
            local items, listH = nil, 0
            if open and hasList then
                items = {}
                if a.list then
                    -- (third: whether it is found in this zone, when the list knows)
                    for _, n in ipairs(a.list) do
                        local here
                        if a.here then
                            local okH, v = pcall(a.here, n)
                            if okH then here = v end
                        end
                        items[#items + 1] = { n, a.has(n), here }
                    end
                elseif dyn then
                    items = dyn
                else
                    for _, n in pairs(a.seen()) do items[#items + 1] = { n, true } end
                    table.sort(items, function(p, q) return p[1] < q[1] end)
                    if #items == 0 then items[1] = { "Nothing yet: eat or drink something new.", false } end
                end
                listH = math.ceil(#items / 3) * 18 + 20
            elseif open and hasSeries then
                listH = 62
            end
            local card = ns.AcquireCard(child)
            card:SetSize(width - 40, ROW_H + listH)
            card:ClearAllPoints()
            card:SetPoint("TOPLEFT", 20, y)
            local entry = { frame = card, x = 20, y = y, key = a.key, fullH = ROW_H + listH }
            placed[#placed + 1] = entry
            local bg, edge = card.bg, card.edge
            bg:SetColorTexture(C.card[1], C.card[2], C.card[3], C.card[4])
            if done then edge:SetColor(r, g, b, 0.35) else edge:SetColor(unpack(C.edge)) end
            -- Hover: lighter card and a brighter edge.
            card:SetScript("OnEnter", function(self)
                bg:SetColorTexture(C.cardHover[1], C.cardHover[2], C.cardHover[3], C.cardHover[4])
                edge:SetColor(r, g, b, done and 0.7 or 0.4)
                Skin.PaintCard(card, done, true)
                -- (not while the cards move: a card sliding under the cursor
                -- would flash its tooltip at the place it moves away from)
                if GetTime() >= (win.tipQuiet or 0) then CardTooltip(self, a) end
            end)
            card:SetScript("OnLeave", function()
                bg:SetColorTexture(C.card[1], C.card[2], C.card[3], C.card[4])
                if done then edge:SetColor(r, g, b, 0.35) else edge:SetColor(unpack(C.edge)) end
                Skin.PaintCard(card, done, false)
                GameTooltip:Hide()
            end)
            card:SetScript("OnClick", function(self, button)
                if button == "RightButton" then
                    if ns.CardMenu then ns.CardMenu(self, a) else ToggleTrack(a) end
                    return
                end
                if IsShiftKeyDown() and InsertLink(a) then return end
                if expandable then
                    -- Quiet tooltips while the list moves; then the card under
                    -- the cursor gets its own.
                    GameTooltip:Hide()
                    win.tipQuiet = GetTime() + 0.45
                    C_Timer.After(0.5, function()
                        if not (win and win:IsShown()) then return end
                        for _, e in ipairs(win.placed or {}) do
                            local f = e.frame
                            if f and f:IsVisible() and f:IsMouseOver() and f.GetScript and f:GetScript("OnEnter") then
                                f:GetScript("OnEnter")(f)
                                break
                            end
                        end
                    end)
                    if expanded[a.key] and open then
                        -- Fold up, then rebuild without the list.
                        AnimateCard(entry, entry.fullH, ROW_H, function()
                            expanded[a.key] = nil
                            FAC.RefreshWindow()
                        end)
                    else
                        expanded[a.key] = true
                        win.animOpen = a.key
                        FAC.RefreshWindow()
                    end
                end
            end)
            card.tr:SetTextColor(r, g, b, 1)
            card.tr:SetText(DB().tracked[a.key] and "TRACKED" or ((ns.IsWatched and ns.IsWatched(a.key)) and "WATCHED" or ""))
            card.tr:SetShown(card.tr:GetText() ~= "")
            if COMPARE.name then
                local t = COMPARE.done and COMPARE.done[a.key]
                card.cmp:SetText(COMPARE.name .. (t and ": earned" or ": not yet"))
                if t then card.cmp:SetTextColor(r, g, b, 1) else card.cmp:SetTextColor(C.dim[1], C.dim[2], C.dim[3], 1) end
                card.cmp:Show()
            else
                card.cmp:Hide()
            end

            local icon = card.icon
            card.iconBox:ClearAllPoints()
            card.iconBox:SetPoint("TOPLEFT", 12, -(ROW_H - 40) / 2)
            if done then card.iconEdge:SetColor(r, g, b, 0.8) else card.iconEdge:SetColor(1, 1, 1, 0.35) end
            icon:SetTexture((a.icon or ns.ICONS[a.id] or 236376))
            icon:SetDesaturated(not done)
            icon:SetAlpha(done and 1 or 0.55)

            local name = card.name
            name:SetText(a.name)
            if done then name:SetTextColor(r, g, b, 1) else name:SetTextColor(C.text[1], C.text[2], C.text[3], 0.8) end
            card.desc:SetTextColor(C.dim[1], C.dim[2], C.dim[3], 1)
            card.desc:SetText(a.desc)
            card.desc:SetMaxLines(Settings().compact and 1 or 2)

            -- Points badge: an earned series tier shows the series total.
            local badge = card.badge
            badge:ClearAllPoints()
            badge:SetPoint("TOPRIGHT", -8, -(ROW_H - 42) / 2)
            card.bbg:SetColorTexture(r, g, b, done and 0.85 or 0.12)
            card.pts:SetText(tostring(done and SeriesPoints(a) or a.pts))
            if done then card.pts:SetTextColor(0.03, 0.07, 0.09) else card.pts:SetTextColor(r, g, b, 1) end

            local right = card.right
            right:ClearAllPoints()
            right:SetPoint("RIGHT", badge, "LEFT", -5, (not done and need > 1) and 5 or 0)
            if done then
                right:SetText(ns.EarnedText(a.key, done))
                right:SetTextColor(r, g, b, 1)
            else
                right:SetTextColor(C.text[1], C.text[2], C.text[3], 0.85)
                if a.money then right:SetText(Money(cur) .. " / " .. Money(need))
                else right:SetText(cur .. " / " .. need) end
            end
            if not done and need > 1 then
                card.track:Show()
                local fill = card.fill
                fill:SetColorTexture(r, g, b, 1)
                fill:Show()
                local frac = math.min(1, cur / need)
                local prev = barFrac[a.key]
                if win.fillFromZero then prev = 0 end
                barFrac[a.key] = frac
                fill:SetSize(math.max(1, 84 * (prev or frac)), 4)
                if prev and prev ~= frac then
                    Kit.Tween("bar" .. a.key, 0.6, function(e)
                        fill:SetWidth(math.max(1, 84 * Kit.Lerp(prev, frac, e)))
                    end)
                end
            else
                card.track:Hide()
                card.fill:Hide()
            end

            Skin.PaintCard(card, done, false)

            -- Chevron after the name: right when closed, down when open.
            card.chev:SetShown(expandable and true or false)
            if expandable then
                for i, bar in ipairs(card.chevBars) do
                    local side = i == 1 and -1 or 1
                    bar:SetColorTexture(r, g, b, 1)
                    bar:ClearAllPoints()
                    if open then
                        bar:SetPoint("CENTER", card.chev, "CENTER", side * 2, 0)
                        bar:SetRotation(side * math.pi / 4)
                    else
                        bar:SetPoint("CENTER", card.chev, "CENTER", 0, side * 2)
                        bar:SetRotation(-side * math.pi / 4)
                    end
                end
            end

            card.sep:ClearAllPoints()
            card.sep:SetPoint("TOPLEFT", 12, -ROW_H)
            card.sep:SetPoint("TOPRIGHT", -12, -ROW_H)
            card.sep:SetShown(open and true or false)

            local usedMinis, usedLines = 0, 0
            if open and hasSeries then
                -- The series up to this tier: icon, points under it, date in the tooltip.
                local k = 0
                for _, t in ipairs(SERIES[a.series]) do
                    k = k + 1
                    local tdone = Earned(t.key)
                    local mini = ns.CardMini(card, k)
                    mini:ClearAllPoints()
                    mini:SetPoint("TOPLEFT", 58 + (k - 1) * 40, -ROW_H - 10)
                    mini.tex:SetTexture(t.icon or ns.ICONS[t.id] or 236376)
                    mini.edge:SetColor(r, g, b, 0.6)
                    mini.pts:SetTextColor(0.28, 0.14, 0.06, 1)
                    mini.pts:SetText(tostring(t.pts))
                    mini:SetScript("OnEnter", function(self)
                        GameTooltip:SetOwner(self, "ANCHOR_TOP")
                        GameTooltip:AddLine(t.name, 1, 1, 1)
                        ns.Alpha.AddTooltipLine(GameTooltip, t.desc, nil, nil, nil)
                        if tdone then GameTooltip:AddLine("Earned: " .. ns.EarnedText(t.key, tdone), r, g, b) end
                        GameTooltip:Show()
                    end)
                    usedMinis = k
                    if t == a then break end
                end
            elseif open and hasList then
                local colW = math.floor((width - 80) / 3)
                for idx, it in ipairs(items) do
                    local col = (idx - 1) % 3
                    local line = math.floor((idx - 1) / 3)
                    local l = ns.CardLine(card, idx)
                    l.mark:ClearAllPoints()
                    l.mark:SetPoint("TOPLEFT", 22 + col * colW, -ROW_H - 15 - line * 18)
                    -- Done in full; still to do here a little brighter; not in
                    -- this zone darker (it[3] false: known to live elsewhere).
                    local away = not it[2] and it[3] == false
                    if it[2] then l.mark:SetColorTexture(r, g, b, 1) else l.mark:SetColorTexture(1, 1, 1, away and 0.07 or 0.2) end
                    l.fs:SetTextColor(C.text[1], C.text[2], C.text[3], it[2] and 1 or (away and 0.2 or (it[3] and 0.6 or 0.45)))
                    do
                        if it[2] then
                            l.mark:SetColorTexture(0.24, 0.40, 0.13, 1)
                            l.fs:SetTextColor(0.19, 0.32, 0.09, 1)
                        else
                            l.mark:SetColorTexture(0.33, 0.22, 0.13, away and 0.45 or 0.7)
                            l.fs:SetTextColor(0.29, 0.18, 0.09, away and 0.68 or 1)
                        end
                    end
                    l.fs:SetWidth(colW - 26)
                    l.fs:SetText(it[1])
                    usedLines = idx
                end
            end
            for k = usedMinis + 1, #card.minis do card.minis[k]:Hide(); card.minis[k].pts:Hide() end
            for k = usedLines + 1, #card.lines do card.lines[k].mark:Hide(); card.lines[k].fs:Hide() end
            y = y - ROW_H - listH - GAP
        end
        if #visible > 0 then y = y - 6 end
    end
    if not any then
        if not child.__empty then
            child.__empty = Kit.MakeFont(child, 13, nil, C.dim[1], C.dim[2], C.dim[3], 1)
            child.__empty:SetPoint("TOPLEFT", 30, -10)
        end
        child.__empty:SetText(search ~= "" and "No achievement matches the search."
            or (win.cat == "zone" and "Nothing left to earn in this zone." or "Nothing here with this filter."))
        child.__empty:Show()
        y = -40
    end
    child:SetHeight(-y)
    win.fillFromZero = nil
    -- A card just opened: grow it from the collapsed height.
    if win.animOpen then
        local key = win.animOpen
        win.animOpen = nil
        for _, e in ipairs(placed) do
            if e.key == key and e.fullH > ROW_H then AnimateCard(e, ROW_H, e.fullH) break end
        end
    end
end

FAC.RefreshWindow = function(reason)
    if not (win and win:IsVisible()) then return end
    local isView = search == "" and VIEWS[win.cat or ""] and true or false
    -- A page of its own (Summary, Settings...) is drawn again by a check pass
    -- only when something was earned since (it is made anew each time).
    if reason == "checks" and isView and not ns.earnedSinceView then return end
    -- A page of its own is kept per tab (frames are never freed): a tab
    -- switch shows it as it was; changed data (any refresh but a tab
    -- switch, or something earned) or another zone draws it again.
    win.viewScrolls = win.viewScrolls or {}
    if (reason ~= "tab" and reason ~= "checks") or ns.earnedSinceView then win.viewGen = (win.viewGen or 0) + 1 end
    ns.earnedSinceView = nil
    local zoneNow = GetRealZoneText and GetRealZoneText() or ""
    if issecretvalue and issecretvalue(zoneNow) then zoneNow = "" end
    for k, sc in pairs(win.viewScrolls) do if not (isView and k == win.cat) then sc:Hide() end end
    local done, all, n, avail = TotalPoints()
    local function Summary(pts)
        local text = ("%d / %d earned"):format(n, avail)
        if COMPARE.name then text = text .. "   |   comparing with " .. COMPARE.name end
        win.summary:SetText(text)
        win.totalPoints:SetText(pts)
    end
    local frac = all > 0 and done / all or 0
    local barW = WIN_W - PAD - CONTENT_X
    local prevPts, prevFrac = win.shownPoints, win.shownFrac
    win.shownPoints, win.shownFrac = done, frac
    if win.fillFromZero and frac > 0 then
        Summary(done)
        Kit.Tween("summaryBar", 0.7, function(e) win.progFill:SetWidth(math.max(1, barW * frac * e)) end)
    elseif prevPts and prevPts ~= done then
        -- New points: the number counts up and the bar slides to it.
        Kit.Tween("summaryPoints", 0.9, function(e)
            Summary(math.floor(Kit.Lerp(prevPts, done, e) + 0.5))
            win.progFill:SetWidth(math.max(1, barW * Kit.Lerp(prevFrac, frac, e)))
        end)
    else
        Summary(done)
        win.progFill:SetWidth(math.max(1, barW * frac))
    end
    for _, t in ipairs(win.tabs) do
        if CATEGORY_SECTIONS[t.key] then
            local en, ea = 0, 0
            for _, sec in ipairs(CATEGORY_SECTIONS[t.key]) do
                for _, a in ipairs(sec.list) do
                    if Available(a) then
                        ea = ea + 1
                        if Earned(a.key) then en = en + 1 end
                    end
                end
            end
            t.count:SetText(en .. "/" .. ea)
        end
    end

    -- The card lists: one scroll kept for good, its cards pooled. A page of
    -- its own: a scroll of its own, made for it.
    local scroll = (not isView) and win.listScroll or nil
    if isView then
        local kept = win.viewScrolls[win.cat]
        if kept and kept.gen == win.viewGen and kept.zone == zoneNow then
            if win.listScroll then win.listScroll:Hide() end
            kept:Show()
            win.scroll = kept
            kept:SetVerticalScroll(math.min(win.scrollPos or 0, math.max(0, kept.child:GetHeight() - kept:GetHeight())))
            C_Timer.After(0, Kit.RealignBorders)
            return
        end
        if kept then kept:Hide(); kept:SetParent(nil); win.viewScrolls[win.cat] = nil end
    end
    local child = scroll and scroll.child
    if not scroll then
        scroll = CreateFrame("ScrollFrame", nil, win)
        scroll:SetPoint("TOPLEFT", win.contentTop, "TOPLEFT", CONTENT_X - 20, -39)
        scroll:SetPoint("BOTTOMRIGHT", 0, PAD)
        child = CreateFrame("Frame", nil, scroll)
        child:SetWidth(CHILD_W)
        child:SetHeight(1)
        scroll:SetScrollChild(child)
        scroll.child = child
        scroll:EnableMouseWheel(true)
        scroll:SetScript("OnMouseWheel", function(self, delta)
            local max = math.max(0, child:GetHeight() - self:GetHeight())
            self:SetVerticalScroll(math.min(max, math.max(0, self:GetVerticalScroll() - delta * 60)))
        end)
        Skin.Scrollbar(scroll)
        if isView then
            win.viewScrolls[win.cat] = scroll
            scroll.gen, scroll.zone = win.viewGen, zoneNow
        else
            win.listScroll = scroll
        end
    end
    if isView then
        if win.listScroll then win.listScroll:Hide() end
    else
        scroll:Show()
        ns.ReleaseCards(child)
    end
    win.scroll = scroll
    BuildList(child, CHILD_W)
    if win.scrollPos then
        scroll:SetVerticalScroll(math.min(win.scrollPos, math.max(0, child:GetHeight() - scroll:GetHeight())))
    end
    if scroll.SyncWrathScroll then scroll:SyncWrathScroll() end
    -- The frames' lines on whole pixels once the page has its place (made
    -- before that, a small frame's lines can land a pixel off and look cut).
    C_Timer.After(0, Kit.RealignBorders)
    C_Timer.After(0.1, Kit.RealignBorders)
    scroll:SetScript("OnVerticalScroll", function(self, offset)
        win.scrollPos = offset
        if self.SyncWrathScroll then self:SyncWrathScroll() end
        Kit.RealignBorders()
        if ns.RefitIcons then ns.RefitIcons() end
    end)
end

local function PlaceWindow(window, host)
    window.dockHost = host
    window:SetParent(host or UIParent)
    window:ClearAllPoints()
    window:SetFrameStrata(host and "HIGH" or "DIALOG")
    window:SetFrameLevel(host and host:GetFrameLevel() + 1 or UIParent:GetFrameLevel() + 1)
    window:SetClampedToScreen(not host)
    window:SetMovable(not host)
    local special
    for i, name in ipairs(UISpecialFrames) do
        if name == window:GetName() then special = i; break end
    end
    if host then
        if special then table.remove(UISpecialFrames, special) end
        window:SetPoint("TOPRIGHT", host, "TOPRIGHT", 0, -COLLECTIONS_TOP_PAD)
    else
        if not special then tinsert(UISpecialFrames, window:GetName()) end
        local pos = Settings().winPos
        if type(pos) == "table" and pos.x and pos.y then
            window:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", pos.x, pos.y)
        else
            window:SetPoint("CENTER")
        end
    end
    window:ApplyScale()
    if window.scroll and window.scroll.SyncWrathScroll then window.scroll:SyncWrathScroll() end
end

local function Open(host)
    host = host or (win and win.dockHost and win.dockHost:IsVisible() and win.dockHost) or nil
    if not win then
        local r, g, b = Accent()
        win = CreateFrame("Frame", "SoLAchievementsWindow", UIParent)
        win:SetSize(WIN_W, WIN_H)
        win:Hide()
        local background = win:CreateTexture(nil, "BACKGROUND")
        background:SetAllPoints()
        background:SetColorTexture(0.13, 0.085, 0.047, 1)
        -- The kit's pixel scale (times the window's own size setting), and
        -- its corner on a whole pixel: 1 px lines never fall between two.
        Kit.UsePixelScale(win, function() return Settings().scale or 1 end)
        local applyStandaloneScale = win.ApplyScale
        function win:ApplyScale()
            self:SetHeight(WIN_H)
            if self.dockHost then
                local scale = math.min(self.dockHost:GetWidth() / WIN_W,
                    (self.dockHost:GetHeight() - COLLECTIONS_TOP_PAD) / (WIN_H + FOOTER_CLEARANCE))
                if scale <= 0 then return end
                self:SetScale(scale)
                Kit.QueueRealign()
            else
                applyStandaloneScale(self)
            end
        end
        local window = win
        C_Timer.After(0, function() Kit.SnapFrame(window); Kit.RealignBorders() end)
        win:SetClampRectInsets(0, 0, 18, -27)
        win:EnableMouse(true)
        win:RegisterForDrag("LeftButton")
        win:SetScript("OnDragStart", function(self)
            if not self.dockHost then self:StartMoving() end
        end)
        win:SetScript("OnDragStop", function(self)
            if self.dockHost then return end
            self:StopMovingOrSizing()
            Kit.SnapFrame(self)
            local l, t = self:GetLeft(), self:GetTop()
            if l and t then Settings().winPos = { x = l, y = t } end
            Kit.RealignBorders()
        end)
        if Kit.TipsGoWith then Kit.TipsGoWith(win) end
        local function Close()
            if window.dockHost then ns.CloseCollectionsAchievements(true)
            else window:Hide() end
        end
        local chrome, plaque = Skin.Chrome(win, Close, Kit)
        local points = CreateFrame("Frame", nil, win)
        points:SetAllPoints()
        points:SetFrameLevel(chrome:GetFrameLevel() + 1)
        win.totalPoints = Kit.MakeFont(points, 19, "OUTLINE", 1, 0.91, 0.66, 1)
        win.totalPoints:SetPoint("CENTER", plaque, "CENTER", 0, 2)
        win.contentTop = CreateFrame("Frame", nil, win)
        win.contentTop:SetSize(1, 1)
        win.contentTop:SetPoint("TOPLEFT", 0, -83)
        PlaceWindow(win, host)

        -- Category rows sit to the left of the scrolling achievements.
        win.cat = DB().tab or "summary"
        -- (Timeline and Guild are tabs of Statistics now)
        if win.cat == "timeline" or win.cat == "guild" then DB().statTab = win.cat; win.cat = "statistics"; DB().tab = win.cat end
        if not CATEGORY_SECTIONS[win.cat] and not VIEWS[win.cat] and win.cat ~= "statistics" and win.cat ~= "settings" then
            win.cat = "summary"
        end
        win.tabs = {}
        local C = Kit.COLORS
        local side = CreateFrame("Frame", nil, win)
        side:SetPoint("TOPLEFT", win.contentTop, "TOPLEFT", PAD, 0)
        side:SetPoint("BOTTOMLEFT", PAD, PAD)
        side:SetWidth(SIDE_W)
        local sbg = side:CreateTexture(nil, "BACKGROUND")
        sbg:SetAllPoints()
        sbg:SetColorTexture(C.card[1], C.card[2], C.card[3], 0.55)
        Skin.Sidebar(side)
        local sy = -7
        for _, cat in ipairs(CATEGORIES) do
            local item = CreateFrame("Button", nil, side)
            item:SetSize(SIDE_W - 12, 29)
            item:SetPoint("TOPLEFT", 6, sy)
            sy = sy - 30
            local ibg = item:CreateTexture(nil, "BACKGROUND")
            ibg:SetAllPoints()
            local label = Kit.RoleFont(item, "tab", 12, nil, C.dim[1], C.dim[2], C.dim[3], 1)
            label:SetPoint("LEFT", 12, 0)
            label:SetPoint("RIGHT", -47, 0)
            label:SetJustifyH("LEFT")
            label:SetWordWrap(false)
            label:SetText(cat.label)
            item.count = Kit.RoleFont(item, "tab", 10, nil, C.dim[1], C.dim[2], C.dim[3], 0.8)
            item.count:SetPoint("RIGHT", -12, 0)
            item.key = cat.key
            function item:SetActive(on)
                Skin.Category(self, ibg, label, self.count, on)
            end
            item:SetActive(cat.key == win.cat)
            item:SetScript("OnClick", function()
                win.cat = cat.key
                DB().tab = cat.key
                win.scrollPos = 0
                win.fillFromZero = true
                for _, t in ipairs(win.tabs) do t:SetActive(t.key == cat.key) end
                win.UpdateFooter()
                FAC.RefreshWindow("tab")
            end)
            win.tabs[#win.tabs + 1] = item
        end

        local achievementsTab = Skin.FooterTab(win, "Achievements", 20, Kit, function()
            ns.FA.ShowTab(win.lastAchievementTab or "summary")
        end)
        local statsTab = Skin.FooterTab(win, "Statistics", 142, Kit, function() ns.FA.ShowTab("statistics") end)
        local settingsTab = Skin.FooterTab(win, "Settings", 264, Kit, function() ns.FA.ShowTab("settings") end)
        function win.UpdateFooter()
            local achievements = win.cat ~= "statistics" and win.cat ~= "settings"
            if achievements then win.lastAchievementTab = win.cat end
            achievementsTab:SetActive(achievements)
            statsTab:SetActive(win.cat == "statistics")
            settingsTab:SetActive(win.cat == "settings")
        end
        win.UpdateFooter()

        -- Overall progress, the search and the filter on the row under the tabs.
        win.summary = Kit.MakeFont(win, 12, nil, Kit.COLORS.dim[1], Kit.COLORS.dim[2], Kit.COLORS.dim[3], 1)
        local filters = { all = "All", completed = "Completed", incomplete = "Incomplete", near = "Near completion",
                          watch = "Watch list", rewards = "With a reward", excluded = "Excluded" }
        local filterDD = Kit.Dropdown(win, 128, filters, { "all", "completed", "incomplete", "near", "watch", "rewards", "excluded" },
            function() return DB().filter or "all" end,
            function(v) DB().filter = v; win.scrollPos = 0; FAC.RefreshWindow() end)

        -- Search box left of the filter.
        local C = Kit.COLORS
        local box = CreateFrame("EditBox", nil, win, "InputBoxTemplate")
        box:SetSize(132, 26)
        box:SetPoint("RIGHT", filterDD, "LEFT", -8, 0)
        box:SetAutoFocus(false)
        box:SetFont(Kit.FONT, 12, "")
        box:SetTextColor(C.text[1], C.text[2], C.text[3])
        box:SetTextInsets(10, 24, 0, 0)
        box:SetMaxLetters(40)
        local sbg = box:CreateTexture(nil, "BACKGROUND")
        sbg:SetAllPoints()
        sbg:SetColorTexture(0, 0, 0, 0.35)
        local sborder = Kit.MakeBorder(box, 1, 1, 1, 0.2)
        local hint = Kit.MakeFont(box, 12, nil, C.dim[1], C.dim[2], C.dim[3], 0.7)
        hint:SetPoint("LEFT", 10, 0)
        hint:SetText("Search")
        local clear = CreateFrame("Button", nil, box)
        clear:SetSize(18, 18)
        clear:SetPoint("RIGHT", -4, 0)
        for _, angle in ipairs({ math.pi / 4, -math.pi / 4 }) do
            local bar = clear:CreateTexture(nil, "OVERLAY")
            bar:SetSize(9, 1.5)
            bar:SetPoint("CENTER")
            bar:SetColorTexture(C.dim[1], C.dim[2], C.dim[3], 1)
            bar:SetRotation(angle)
        end
        clear:SetScript("OnClick", function() box:SetText(""); box:ClearFocus() end)
        clear:Hide()
        local pending
        box:SetScript("OnTextChanged", function(self)
            local text = self:GetText() or ""
            hint:SetShown(text == "")
            clear:SetShown(text ~= "")
            local token = {}
            pending = token
            C_Timer.After(0.2, function()
                if pending ~= token or win ~= window then return end
                search = text:lower():match("^%s*(.-)%s*$")
                win.scrollPos = 0
                FAC.RefreshWindow()
            end)
        end)
        box:SetScript("OnEditFocusGained", function() sborder:SetColor(r, g, b, 0.8) end)
        box:SetScript("OnEditFocusLost", function() sborder:SetColor(1, 1, 1, 0.2) end)
        box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        win.searchBox = box
        if search ~= "" then
            box:SetText(search)
            hint:Hide()
            clear:Show()
        end
        box:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
        local track = win:CreateTexture(nil, "ARTWORK")
        track:SetColorTexture(1, 1, 1, 0.08)
        track:SetHeight(5)
        win.progFill = win:CreateTexture(nil, "OVERLAY")
        win.progFill:SetColorTexture(r, g, b, 1)
        win.progFill:SetHeight(5)
        win.progFill:SetPoint("LEFT", track, "LEFT")

        -- Summary, search and filter in line with the top of the sidebar,
        -- the progress bar under them.
        filterDD:SetPoint("TOPRIGHT", win.contentTop, "TOPLEFT", WIN_W - PAD, 0)
        win.summary:SetPoint("LEFT", win.contentTop, "TOPLEFT", CONTENT_X, -13)
        win.summary:SetPoint("RIGHT", box, "LEFT", -12, 0)
        win.summary:SetJustifyH("LEFT")
        win.summary:SetWordWrap(false)
        track:SetPoint("TOPLEFT", win.contentTop, "TOPLEFT", CONTENT_X, -36)
        track:SetPoint("TOPRIGHT", win.contentTop, "TOPLEFT", WIN_W - PAD, -36)
    end
    local moved = win.dockHost ~= host
    if moved then PlaceWindow(win, host) end
    local wasShown = win:IsShown()
    if not wasShown then
        win.fillFromZero = true
        win:SetAlpha(0)
        win:Show()
        Kit.Tween("windowFade", 0.18, function(e) win:SetAlpha(e) end)
    end
    -- (opened now: drawn from fresh data; open already: kept as shown)
    FAC.RefreshWindow(wasShown and not moved and not host and "tab" or nil)
end

SLASH_SOLACHIEVEMENTS1 = "/solach"
SLASH_SOLACHIEVEMENTS3 = "/fach"
SLASH_SOLACHIEVEMENTS2 = "/qa" -- short alias, same commands
SlashCmdList.SOLACHIEVEMENTS = function(input)
    local msg, rest = (input or ""):match("^%s*(%S*)%s*(.-)%s*$")
    msg = (msg or ""):lower()
    if SLASH[msg] then
        SLASH[msg](rest or "")
        return
    end
    if msg == "help" or msg == "?" then
        local r, g, b = Kit.Accent()
        local accent = ("|cff%02x%02x%02x"):format(math.floor(r * 255), math.floor(g * 255), math.floor(b * 255))
        print(TAG .. " commands:")
        for _, line in ipairs({
            { "/solach", "open the window" },
            { "/fach compare Firstname Lastname", "compare with a player who runs the addon (or right-click them)" },
            { "/fach compare off", "stop comparing" },
            { "/fach scan", "list the game's own achievements and count the ones the addon does not show" },
            { "/fach debug", "debug messages for critters, pests and kills" },
            { "/fach reset", "clear this character's progress" },
            { "/fach help", "this list" },
            { "/qa", "short for /fach (works with every command above)" },
        }) do
            print("  " .. accent .. line[1] .. "|r - " .. line[2])
        end
        return
    end
    if msg == "scan" then
        -- Every achievement the game itself offers, saved for this character
        -- (SoLAchievementsCharDB.gameScan), each marked known when the
        -- addon already shows it. For finding the ones the addon is missing.
        if not (GetCategoryList and GetCategoryNumAchievements and GetAchievementInfo) then
            print(TAG .. " this client has no achievement list to scan.")
            return
        end
        -- Known: the game list the addon reads, and every achievement the
        -- addon shows itself, by the game's id or by name (the Forever zones
        -- carry their own keys, not the game's ids).
        local known, knownName = {}, {}
        for _, sec in ipairs(ns.FOREVER_ACH or {}) do
            for _, e in ipairs(sec.list) do
                for _, id in ipairs(e.ids) do known[id] = true end
                if e.name then knownName[e.name] = true end
            end
        end
        for _, a in ipairs(ALL) do
            if a.id then known[a.id] = true end
            if a.name then knownName[a.name] = true end
        end
        local list, total, done, missing = {}, 0, 0, 0
        for _, cat in ipairs(GetCategoryList() or {}) do
            local catName, parent = GetCategoryInfo(cat)
            local n = GetCategoryNumAchievements(cat, true) or 0
            for i = 1, n do
                local id, name, points, completed, _, _, _, desc, flags, icon = GetAchievementInfo(cat, i)
                if id then
                    total = total + 1
                    if completed then done = done + 1 end
                    local isKnown = known[id] or (name and knownName[name]) or false
                    if not isKnown then missing = missing + 1 end
                    -- Its criteria too (a raid's bosses, a dungeon list): { name, done }.
                    local crit = {}
                    if GetAchievementNumCriteria and GetAchievementCriteriaInfo then
                        local okN, nc = pcall(GetAchievementNumCriteria, id)
                        for c = 1, (okN and tonumber(nc) or 0) do
                            local okC, cname, _, cdone = pcall(GetAchievementCriteriaInfo, id, c)
                            if okC and cname and cname ~= "" then crit[#crit + 1] = { cname, cdone and true or false } end
                        end
                    end
                    list[#list + 1] = {
                        crit = crit,
                        id = id, name = name, cat = cat, catName = catName, parent = parent,
                        done = completed and true or false, desc = desc, pts = points,
                        icon = icon, flags = flags, known = isKnown and true or false,
                    }
                end
            end
        end
        SoLAchievementsCharDB.gameScan = { time = time(), list = list }
        print(("%s scanned %d game achievements, %d earned, %d not in the addon. /reload to save."):format(
            TAG, total, done, missing))
        return
    end
    if msg == "debug" then
        FAC.debugOn = not FAC.debugOn
        print(TAG .. " debug " .. (FAC.debugOn and "ON: /love a critter or kill a targeted pest" or "OFF"))
        return
    end
    if msg == "reset" and rest == "" then
        -- Asked first; the old progress kept (once) for /fach reset undo.
        local who = UnitName("player") or "?"
        local function Go()
            local acc = AccountDB()
            acc.resetBackup = acc.resetBackup or {}
            acc.resetBackup[who] = { t = time(), db = SoLAchievementsCharDB }
            SoLAchievementsCharDB = {}
            print(TAG .. " progress for this character cleared (the old one is kept: /fach reset undo).")
            FAC.CheckAll(true)
        end
        if Kit.Confirm then
            Kit.Confirm("Clear every achievement and all progress of " .. who .. "?\n\nThe history pass finds again what the game can tell; kills, critters, books and food seen so far are lost. /fach reset undo brings it back.", Go)
        else
            print(TAG .. " type /fach reset yes to clear this character's progress.")
        end
    elseif msg == "reset" and rest:lower() == "yes" then
        local acc = AccountDB()
        acc.resetBackup = acc.resetBackup or {}
        acc.resetBackup[UnitName("player") or "?"] = { t = time(), db = SoLAchievementsCharDB }
        SoLAchievementsCharDB = {}
        print(TAG .. " progress for this character cleared (the old one is kept: /fach reset undo).")
        FAC.CheckAll(true)
    elseif msg == "reset" and rest:lower() == "undo" then
        local b = (AccountDB().resetBackup or {})[UnitName("player") or "?"]
        if not b then print(TAG .. " nothing to bring back.") return end
        SoLAchievementsCharDB = b.db
        AccountDB().resetBackup[UnitName("player") or "?"] = nil
        print(TAG .. " progress from before the reset is back.")
        if FAC.RefreshWindow then FAC.RefreshWindow() end
    else
        Open()
    end
end

-------------------------------------------------------------------------------
--  What the other files (social, tooltips, tracker, pages) build on
-------------------------------------------------------------------------------
local ZONE_ACH = {} -- [zone name] = its exploration achievement
for _, list in ipairs({ ekZones, kalZones, otherZones }) do
    for _, a in ipairs(list) do
        local zone = a.name:gsub("^Explore ", "")
        ZONE_ACH[zone] = a
        -- The game calls "Tanaris Desert" just "Tanaris".
        ZONE_ACH[(zone:gsub(" Desert$", ""))] = a
    end
end
local BY_KEY = {}
for _, a in ipairs(ALL) do BY_KEY[a.key] = a end

local function CharacterPoints(done)
    local points, count = 0, 0
    for key, earned in pairs(done or DB().done) do
        local achievement = BY_KEY[key]
        if earned and achievement then
            points, count = points + achievement.pts, count + 1
        end
    end
    return points, count
end

-- /fach event: which events are on, where that came from, and their achievements.
SLASH.event = function()
    EV.ReadCalendar()
    for _, e in ipairs(EV.EVENTS) do
        local st = ns.eventState[e.key] or { state = "unknown", source = "-" }
        local left, total = ns.EventCounts(e.key)
        print(("%s %s: %s (%s)  ·  %d achievements here, %d to earn"):format(TAG, e.name, st.state, st.source, total, left))
    end
end
SLASH.events = SLASH.event

ns.FA = {
    TAG = TAG, Kit = Kit, secret = secret, Count = Count,
    IsDebug = function() return FAC.debugOn end, -- /fach debug, for messages in the other files
    DB = DB, Account = AccountDB, Settings = Settings,
    ALL = ALL, BY_KEY = BY_KEY, SERIES = SERIES, Available = Available, Earned = Earned,
    CATEGORIES = CATEGORIES, CATEGORY_SECTIONS = CATEGORY_SECTIONS, CATEGORY_ORDER = CATEGORY_ORDER,
    EARN_HOOKS = EARN_HOOKS, CHECK_HOOKS = CHECK_HOOKS, VIEWS = VIEWS, SLASH = SLASH, COMPARE = COMPARE, LINK = LINK,
    CheckAll = FAC.CheckAll, TotalPoints = TotalPoints, CharacterPoints = CharacterPoints,
    SeriesPoints = SeriesPoints, ToggleTrack = ToggleTrack,
    Money = Money, StatText = StatText, NpcID = NpcID, IsDrink = IsDrink,
    CRITTERS = CRITTERS, PESTS = PESTS, PEST_NAMES = PEST_NAMES, BOSS_IDS = BOSS_IDS, BOSS_BY_NAME = BOSS_BY_NAME,
    BOSS_ACH = BOSS_ACH, BOOKSET = BOOKSET, ZONE_ACH = ZONE_ACH,
    CritterZones = FAC.CritterZones, CritterHere = FAC.CritterHere, CritterNearest = FAC.CritterNearest,
    Open = Open,
    Refresh = function() if FAC.RefreshWindow then FAC.RefreshWindow() end end,
    -- Opens the window with the search box filled in.
    OpenSearch = function(text)
        Open()
        if win.searchBox then win.searchBox:SetText(text or "") end
    end,
    -- Builds the window again (a new theme): reopened on the same tab.
    RebuildWindow = function()
        if not win then return end
        local shown = win:IsShown()
        local host = win.dockHost
        win:Hide()
        win = nil
        if shown then Open(host) end
    end,
    SetScale = function(v)
        if win and win.ApplyScale then win:ApplyScale() elseif win then win:SetScale(v) end
        if win then Kit.SnapFrame(win) end
        Kit.RealignBorders()
    end,
    ToastSoundKit = function()
        local sound = Settings().soundName
        return SOUNDKIT and (SOUNDKIT[sound or "UI_ACHIEVEMENT_AWARDED"]
            or SOUNDKIT.UI_ACHIEVEMENT_AWARDED or SOUNDKIT.LEVELUP) or 888
    end,
    -- A sample toast, for the settings page.
    PreviewToast = function()
        queue[#queue + 1] = { name = "SoLAchievements", icon = 132347, pts = 10 }
        if not FAC.showing then ShowNextToast() end
    end,
    IsShown = function() return win and win:IsVisible() end,
    Hide = function()
        if not win then return end
        win:Hide()
        if win.dockHost and ns.CloseCollectionsAchievements then ns.CloseCollectionsAchievements() end
    end,
    -- The toast is built again with the next achievement.
    ResetToast = function() if not FAC.showing then FAC.toast = nil end end,
    GetToastFrame = function() return FAC.toast end,
    -- Switches the window to a tab.
    ShowTab = function(key)
        Open()
        -- (Timeline and Guild: tabs of Statistics)
        if key == "timeline" or key == "guild" then DB().statTab = key; key = "statistics"; win.viewGen = (win.viewGen or 0) + 1 end
        win.cat = key
        DB().tab = key
        for _, t in ipairs(win.tabs) do t:SetActive(t.key == key) end
        win.scrollPos = 0
        win.UpdateFooter()
        FAC.RefreshWindow("tab")
    end,
}
ns.FA.DUNGEONS, ns.FA.RAIDS = ns.DUNGEONS, ns.RAIDS
-- Quick Fish's milestones are shown (and announced) here, not by it.
ns.FA.QuickFishMilestones = true
do
    local carry = CreateFrame("Frame")
    carry:RegisterEvent("PLAYER_LOGIN")
    carry:SetScript("OnEvent", function()
        local d = DB()
        if not (d and type(d.done) == "table") then return end
        for old, new in pairs(QF.OLD_KEYS) do
            if d.done[old] and not d.done[new] then d.done[new] = d.done[old] end
        end
    end)
end

