local _, ns = ...
local FAC = ns.Split_SoLAchievements
local DB, secret = FAC.DB, FAC.secret
local WALK_ON_AIR, YARD_GOAL = 1259416, 500

local function Readable(value)
    return not secret(value) and (not canaccessvalue or canaccessvalue(value))
end

local function Skyborne()
    local _, _, raceID = UnitRace("player")
    return Readable(raceID) and (raceID == 95 or raceID == 96)
end

local function QuestAchievement(key, name, desc, icon, quests)
    return {
        key = key, name = name, desc = desc, pts = 10, icon = icon,
        tracking = "Uses completed quests on this character, including older completions.",
        progress = function()
            for _, id in ipairs(quests) do
                if FAC.IsQuestDone(id) then return 1, 1 end
            end
            return 0, 1
        end,
    }
end

local gustjumperItem = { 268109 }
local list = {
    {
        key = "foreverWalkOnAir", name = "500 Yards Above", pts = 10, icon = 132837,
        desc = "Glide a total of 500 yards using the Skyborne racial Walk on Air.",
        requires = Skyborne,
        tracking = "Counts horizontal distance while airborne with Walk on Air active, across multiple glides on this character.",
        progress = function() return math.floor(DB().walkOnAirYards or 0), YARD_GOAL end,
    },
    QuestAchievement("foreverGreatOutdoors", "A Place by the Fire",
        "Complete The Great Outdoors in any starting zone.", 135805, { 96101, 95998, 96604, 96605, 96606, 96607, 96608 }),
    {
        key = "foreverExpertFire", name = "Room for Ten", pts = 10, icon = 135805,
        desc = "Place an Expert Campfire.",
        tracking = "Tracks successful use of an Expert Campfire Kit on this character.",
        progress = function() return DB().camping and DB().camping.expertFire and 1 or 0, 1 end,
    },
    QuestAchievement("foreverZephrasFate", "Zephras Stands",
        "Complete The Fate of Zephras on Zephras Isle.", 135932, { 94369 }),
    QuestAchievement("foreverAncientHilt", "What the Torch Revealed",
        "Uncover the Ancient Hilt in the Ruins of Ban'aethal and complete The Ancient Hilt.", 135325, { 93161 }),
    {
        key = "foreverMusicalGustjumper", name = "A Frog in Your Throat", pts = 10, icon = 237579,
        desc = "Obtain the Musical Gustjumper from the singing frogs of Zephras Isle.",
        tracking = "Checks your companion collection or the companion item.",
        progress = function()
            local count = C_PetJournal and C_PetJournal.GetNumCollectedInfo and C_PetJournal.GetNumCollectedInfo(5005)
            if Readable(count) and type(count) == "number" and count > 0 then return 1, 1 end
            return ns.Owns(gustjumperItem) and 1 or 0, 1
        end,
    },
    QuestAchievement("foreverSlime", "It Followed Me Home",
        "Befriend an Excitable Slime in Undercity and complete WRIGGLE.", 134437, { 97583 }),
    QuestAchievement("foreverDarkspearVictory", "The Isles Are Ours",
        "Win a Darkspear Islands battleground and turn in The Battle for Darkspear Islands!", 441150,
        { 98903, 98904, 98905, 98906, 98907, 98908 }),
    QuestAchievement("foreverTitanRelic", "Unearthed in the Wetlands",
        "Follow up on the Titan Relic from Excavation Site: Wetlands by completing Earthen Echo or Prehistoric Prism.",
        134459, { 98823, 98824 }),
    QuestAchievement("foreverDalaranMote", "A Mote of Trouble",
        "Recover an Arcane Mote in the City of Dalaran and complete Heart of Disruption.", 132841, { 92458, 96984 }),
}
for _, section in ipairs(FAC.SECTIONS) do
    if section.title == "FOREVER ADVENTURES" then
        for _, a in ipairs(list) do section.list[#section.list + 1] = a end
        break
    end
end

table.insert(FAC.SECTIONS, { title = "FOREVER LIBRARY BOOKS", list = {
    QuestAchievement("foreverLibrary10", "Due at the Library",
        "Turn in 10 different library books and complete the first library reward quest.", 133737, { 78150 }),
    QuestAchievement("foreverLibrary20", "Return to the Stacks",
        "Turn in 20 different library books and complete the second library reward quest.", 133739, { 79536 }),
    QuestAchievement("foreverLibrary25", "Azeroth in the Margins",
        "Turn in 25 different library books and complete the third library reward quest.", 133741, { 82208 }),
} })

-- Only sample during the racial's aura. Track the horizontal path in small
-- segments so turns count, while jumps between maps or positions do not.
local ticker, auraID, expires, previous, airborne, changed
local function StopGlide()
    if ticker then ticker:Cancel() end
    ticker, auraID, expires, previous, airborne = nil, nil, nil, nil, nil
    if changed then changed = nil; FAC.CheckAll() end
end

local function SampleGlide()
    local now = GetTime()
    if now >= expires or IsInInstance() then StopGlide(); return end
    local falling = IsFalling()
    if not Readable(falling) then StopGlide(); return end
    if not falling then
        if airborne then StopGlide() end
        return
    end
    airborne = true
    local x, y, _, map = UnitPosition("player")
    if not (Readable(x) and Readable(y) and Readable(map) and type(x) == "number"
        and type(y) == "number" and type(map) == "number") then StopGlide(); return end
    local last = previous
    if last and last.map ~= map then StopGlide(); return end
    previous = { x = x, y = y, map = map, time = now }
    if not last then return end
    local dt = now - last.time
    local dx, dy = x - last.x, y - last.y
    local distanceSquared = dx * dx + dy * dy
    if dt <= 0 or dt > 0.35 or distanceSquared == 0 or distanceSquared > (55 * dt)^2 then return end
    local db = DB()
    db.walkOnAirYards = math.min(YARD_GOAL, (db.walkOnAirYards or 0) + math.sqrt(distanceSquared))
    changed = true
    if db.walkOnAirYards >= YARD_GOAL then StopGlide() end
end

local function OnAura(update)
    if not Readable(update) or type(update) ~= "table" then StopGlide(); return end
    local full, removed = update.isFullUpdate, update.removedAuraInstanceIDs
    if not Readable(full) or full then StopGlide(); return end
    if ticker and Readable(removed) and type(removed) == "table" then
        for _, id in ipairs(removed) do
            if Readable(id) and id == auraID then StopGlide(); break end
        end
    end
    local added = update.addedAuras
    if not Readable(added) or type(added) ~= "table" then return end
    if (DB().walkOnAirYards or 0) >= YARD_GOAL then return end
    for _, aura in ipairs(added) do
        if Readable(aura) and type(aura) == "table" then
            local spell, id = aura.spellId, aura.auraInstanceID
            if Readable(spell) and spell == WALK_ON_AIR and Readable(id) and type(id) == "number" and id ~= auraID then
                StopGlide()
                local ending, now = aura.expirationTime, GetTime()
                if not Readable(ending) or type(ending) ~= "number" or ending == 0 then ending = now + 10 end
                if ending <= now then return end
                auraID, expires = id, math.min(ending, now + 10)
                ticker = C_Timer.NewTicker(0.1, SampleGlide)
                SampleGlide()
                return
            end
        end
    end
end

if UnitPosition and IsFalling and C_Timer and C_Timer.NewTicker then
    local events = CreateFrame("Frame")
    events:RegisterEvent("PLAYER_LOGIN")
    events:SetScript("OnEvent", function(self, event, unit, update)
        if event == "PLAYER_LOGIN" then
            self:UnregisterEvent("PLAYER_LOGIN")
            if Skyborne() and (DB().walkOnAirYards or 0) < YARD_GOAL then
                self:RegisterUnitEvent("UNIT_AURA", "player")
                self:RegisterEvent("PLAYER_ENTERING_WORLD")
                self:RegisterEvent("PLAYER_DEAD")
            end
        elseif event == "UNIT_AURA" then
            if Readable(unit) and unit == "player" then OnAura(update) end
        else
            StopGlide()
        end
    end)
end
