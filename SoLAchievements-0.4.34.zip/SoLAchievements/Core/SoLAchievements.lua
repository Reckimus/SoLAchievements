-------------------------------------------------------------------------------
--  SoLAchievements
--
--  The WotLK General achievements that the WoW Forever world still allows,
--  tracked per character. State that the game can report (level, riding,
--  mounts, pets, tabard) is read at any time; everything that happens
--  (money looted, critters loved, pests killed, books read, food and drink,
--  falls, loot rolls) counts from the moment the addon is installed.
-------------------------------------------------------------------------------

local ADDON, ns = ...
ns.Split_SoLAchievements = ns.Split_SoLAchievements or {}
local FAC = ns.Split_SoLAchievements -- (what the parts of SoLAchievements.lua share)
local TAG = "|cff0cd29fSoLAchievements|r"

SoLAchievementsCharDB = SoLAchievementsCharDB or {}
local function DB()
    local d = SoLAchievementsCharDB
    d.done = d.done or {}          -- [key] = time completed
    d.money = d.money or 0         -- copper looted
    d.critters = d.critters or {}  -- [name] = true
    d.pests = d.pests or {}        -- [name] = true
    d.books = d.books or {}        -- [title] = true
    d.drinks = d.drinks or {}      -- [itemID] = name
    d.foods = d.foods or {}        -- [itemID] = name
    d.skills = d.skills or {}      -- [skill] = best rank
    d.fishedIn = d.fishedIn or {}  -- [zone] = true
    d.rareFish = d.rareFish or {}  -- [itemID] = true
    d.bosses = d.bosses or {}      -- [npcID or name] = time killed
    d.reps = d.reps or {}          -- [factionID] = best standing seen
    d.owned = d.owned or {}        -- [itemID] = true once owned
    d.rares = d.rares or {}        -- [name] = time killed
    d.flags = d.flags or {}        -- [key] = true (one-off feats)
    d.tracked = d.tracked or {}    -- [key] = true
    return d
end

local function Count(t)
    local n = 0
    for _ in pairs(t or {}) do n = n + 1 end
    return n
end

local secret = issecretvalue or function() return false end

-------------------------------------------------------------------------------
--  Lists (WotLK criteria; Northrend and Outland-only entries left out)
-------------------------------------------------------------------------------
local CRITTERS = { "Ram", "Squirrel", "Deer", "Crab", "Fawn", "Frog", "Gazelle", "Hare", "Parrot",
    "Rabbit", "Sheep", "Skunk", "Swine", "Toad", "Prairie Dog", "Cat", "Chicken", "Cow" }

-- Pest Control: creature IDs from the achievement's criteria.
local PESTS = {
    [4076] = "Roach", [15476] = "Scorpion", [2914] = "Snake", [3300] = "Adder", [9699] = "Fire Beetle",
    [16068] = "Larva", [16030] = "Maggot", [4953] = "Moccasin", [6271] = "Mouse", [4075] = "Rat",
    [14881] = "Spider", [1412] = "Squirrel",
}
local PEST_ORDER = {}
for _, name in pairs(PESTS) do PEST_ORDER[#PEST_ORDER + 1] = name end
table.sort(PEST_ORDER)

-------------------------------------------------------------------------------
--  Where the critters and pests live (DataCritterZones.lua), and whether
--  that is the zone you are in
-------------------------------------------------------------------------------
-- Everything is worked out once and kept (zone lists per critter, the map
-- chain per map, map centres), so the calls the objectives tracker makes
-- every second build no tables.
-- (FAC.CritterZones, FAC.CritterHere, FAC.CritterNearest: shared, set below)
do
local EMPTY = {}

local function AreaName(area)
    local a = ns.CRITTER_AREAS and ns.CRITTER_AREAS[area]
    if not a then return nil end
    local info = a[2] and C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(a[2])
    return (info and info.name) or a[1]
end

-- The zones a critter lives in, most spawns first, instances last:
-- { { area =, name =, english =, map = }, ... }; nil when not known.
-- Built on the first call and the same table after that: read only.
local zonesFor = {} -- [name] = list, or false when not known
FAC.CritterZones = function(name)
    local out = zonesFor[name]
    if out ~= nil then return out or nil end
    local list = ns.CRITTER_ZONES and ns.CRITTER_ZONES[name]
    if not list then
        if name ~= nil then zonesFor[name] = false end
        return nil
    end
    out = {}
    for _, area in ipairs(list) do
        local a = ns.CRITTER_AREAS[area]
        out[#out + 1] = { area = area, name = AreaName(area), english = a and a[1], map = a and a[2] }
    end
    zonesFor[name] = out
    return out
end

-- A map and the ones above it up to the continent (a city or a sub-zone map
-- counts as its zone too), as a set; built once per map.
local chainFor = {}
local function MapChain(m)
    if not m or m <= 0 then return EMPTY end
    local set = chainFor[m]
    if set then return set end
    set = {}
    local id = m
    for _ = 1, 6 do
        if not id or id <= 0 then break end
        set[id] = true
        local info = C_Map.GetMapInfo(id)
        if not info or (info.mapType and info.mapType <= 2) then break end
        id = info.parentMapID
    end
    chainFor[m] = set
    return set
end

-- Whether a critter lives in the zone you are in: by map in the open world,
-- by the zone text in an instance. nil when its zones are not known.
FAC.CritterHere = function(name)
    local zones = FAC.CritterZones(name)
    if not zones then return nil end
    local maps = MapChain(C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player"))
    local text = GetZoneText() or ""
    for _, z in ipairs(zones) do
        if (z.map and maps[z.map]) or z.name == text or z.english == text then return true end
    end
    return false
end

-- [uiMapID] = continent and world position of the map's centre, worked out
-- once; centreKnown[map] is false when the client gives none.
local centreKnown, centreCont, centreX, centreY = {}, {}, {}, {}
local function CentreOf(map)
    local c, w = C_Map.GetWorldPosFromMapPos(map, CreateVector2D(0.5, 0.5))
    if w then
        local x, y = w:GetXY()
        return c, x, y
    end
end
local function Centre(map)
    local known = centreKnown[map]
    if known == nil then
        local ok, c, x, y = pcall(CentreOf, map)
        known = ok and x ~= nil and y ~= nil and true or false
        if known then centreCont[map], centreX[map], centreY[map] = c, x, y end
        centreKnown[map] = known
    end
    return known
end

-- Where you stand: continent and world position (nothing when the client
-- does not say, or hides it).
local function PlayerWorld()
    local m = C_Map.GetBestMapForUnit("player")
    local pos = m and C_Map.GetPlayerMapPosition(m, "player")
    if pos then
        local cont, w = C_Map.GetWorldPosFromMapPos(m, pos)
        if w then
            local x, y = w:GetXY()
            return cont, x, y
        end
    end
end

-- The nearest zone (straight line, same continent) where one of these
-- critters lives; with no position to go by, the first one's main zone.
FAC.CritterNearest = function(names)
    local ok, cont, hx, hy = pcall(PlayerWorld)
    local here = ok and hx ~= nil and hy ~= nil and not secret(cont) and not secret(hx) and not secret(hy)
    local best, bestD, first
    for _, n in ipairs(names or EMPTY) do
        for _, z in ipairs(FAC.CritterZones(n) or EMPTY) do
            first = first or z.name
            local map = z.map
            if here and map and Centre(map) and centreCont[map] == cont then
                local d = (hx - centreX[map]) ^ 2 + (hy - centreY[map]) ^ 2
                if not bestD or d < bestD then best, bestD = z.name, d end
            end
        end
    end
    return best or first
end
end

-------------------------------------------------------------------------------
--  Collections the game can report
-------------------------------------------------------------------------------
local GetItemInfoInstant = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant

-- Mount and pet items in the bags (Classic keeps them as items).
local function BagItemsOf(classID, subclassID)
    local seen, n = {}, 0
    for bag = 0, 4 do
        for slot = 1, (C_Container.GetContainerNumSlots(bag) or 0) do
            local id = C_Container.GetContainerItemID(bag, slot)
            if id and not seen[id] then
                local _, _, _, _, _, c, s = GetItemInfoInstant(id)
                if c == classID and s == subclassID then
                    seen[id] = true
                    n = n + 1
                end
            end
        end
    end
    return n
end

local function MountCount()
    local best = 0
    if C_MountJournal and C_MountJournal.GetMountIDs and C_MountJournal.GetMountInfoByID then
        local n = 0
        for _, id in ipairs(C_MountJournal.GetMountIDs() or {}) do
            local _, _, _, _, _, _, _, _, _, _, collected = C_MountJournal.GetMountInfoByID(id)
            if collected then n = n + 1 end
        end
        best = math.max(best, n)
    end
    if GetNumCompanions then best = math.max(best, GetNumCompanions("MOUNT") or 0) end
    best = math.max(best, BagItemsOf(15, 5)) -- Miscellaneous > Mount
    local d = DB()
    d.mountsBest = math.max(d.mountsBest or 0, best) -- bank or sold mounts still counted once seen
    return d.mountsBest
end

local function PetCount(unique)
    local best = 0
    if C_PetJournal and C_PetJournal.GetNumPets then
        local total, owned = C_PetJournal.GetNumPets()
        if unique then
            if C_PetJournal.GetPetInfoByIndex then
                local species = {}
                for i = 1, total or 0 do
                    local _, speciesID, collected = C_PetJournal.GetPetInfoByIndex(i)
                    if collected and speciesID then species[speciesID] = true end
                end
                best = Count(species)
            end
        else
            best = owned or 0
        end
    end
    if GetNumCompanions then best = math.max(best, GetNumCompanions("CRITTER") or 0) end
    best = math.max(best, BagItemsOf(15, 2)) -- Miscellaneous > Companion Pets
    local d = DB()
    local key = unique and "uniquePetsBest" or "petsBest"
    d[key] = math.max(d[key] or 0, best)
    return d[key]
end

local crimsonWhelplingItems, crimsonWhelplingSpells = { 8499 }, { 10697 }
local function CrimsonWhelplingProgress()
    local count = C_PetJournal and C_PetJournal.GetNumCollectedInfo and C_PetJournal.GetNumCollectedInfo(58)
    if not secret(count) and type(count) == "number" and count > 0 then return 1, 1 end
    return ns.Owns(crimsonWhelplingItems, crimsonWhelplingSpells) and 1 or 0, 1
end

-- Classic riding: the Riding skill (75 apprentice, 150 journeyman), or the
-- riding spells on clients that have them.
local function RidingRank()
    if IsPlayerSpell then
        if IsPlayerSpell(33391) then return 150 end
        if IsPlayerSpell(33388) then return 75 end
    end
    if GetNumSkillLines and GetSkillLineInfo then
        for i = 1, (GetNumSkillLines() or 0) do
            local name, isHeader, _, rank = GetSkillLineInfo(i)
            if not isHeader and name == "Riding" then return rank or 0 end
        end
    end
    return 0
end

-------------------------------------------------------------------------------
--  Achievements: progress() returns current, needed (and optional text)
-------------------------------------------------------------------------------
local function LevelAch(key, id, lvl)
    return { key = key, id = id, series = "level", name = "Level " .. lvl, desc = "Reach level " .. lvl .. ".", pts = 10,
             progress = function() return math.min(UnitLevel("player"), lvl), lvl end }
end

local SECTIONS = {
    { title = "LEVELS", list = {
        LevelAch("lvl10", 6, 10), LevelAch("lvl20", 7, 20), LevelAch("lvl30", 8, 30),
        LevelAch("lvl40", 9, 40), LevelAch("lvl50", 10, 50), LevelAch("lvl60", 11, 60),
    } },
    { title = "RIDING", list = {
        { key = "riding75", id = 891, series = "riding", name = "Giddy Up!", desc = "Learn the apprentice riding skill.", pts = 10,
          progress = function() return math.min(RidingRank(), 75), 75 end },
        { key = "riding150", id = 889, series = "riding", name = "Fast and Furious", desc = "Learn the journeyman riding skill (epic mounts).", pts = 10,
          progress = function() return math.min(RidingRank(), 150), 150 end },
    } },
    { title = "MONEY", list = {
        { key = "gold100", series = "gold", id = 1176, name = "Got My Mind On My Money", desc = "Loot 100 gold.", pts = 10, money = true,
          progress = function() return math.min(DB().money, 1000000), 1000000 end },
        { key = "gold1000", series = "gold", id = 1177, name = "Got My Mind On My Money", desc = "Loot 1,000 gold.", pts = 10, money = true,
          progress = function() return math.min(DB().money, 10000000), 10000000 end },
        { key = "gold5000", series = "gold", id = 1178, name = "Got My Mind On My Money", desc = "Loot 5,000 gold.", pts = 10, money = true,
          progress = function() return math.min(DB().money, 50000000), 50000000 end },
    } },
    { title = "COLLECTIONS", list = {
        { key = "pet1", id = 1017, series = "pets", name = "Can I Keep Him?", desc = "Obtain a companion pet.", pts = 10,
          progress = function() return math.min(PetCount(), 1), 1 end },
        { key = "pet15", id = 15, series = "pets", name = "Plenty of Pets", desc = "Collect 15 unique companion pets.", pts = 10,
          progress = function() return math.min(PetCount(), 15), 15 end },
        { key = "pet50", series = "pets", name = "Pet Collector", desc = "Collect 50 unique companion pets.", pts = 10,
          icon = ns.ICONS[15], title = "%s, Keeper of Fifty",
          progress = function() return math.min(PetCount(true), 50), 50 end },
        { key = "crimsonWhelpling", name = "A Little Red Menace", desc = "Obtain the Crimson Whelpling companion.", pts = 10,
          icon = "Interface\\Icons\\INV_Misc_Head_Dragon_01", title = "%s, Keeper of Embers",
          tracking = "Counts the learned companion or the Tiny Crimson Whelpling item, including ones you already have.",
          progress = CrimsonWhelplingProgress },
        { key = "mount10", id = 2141, name = "Stable Keeper", desc = "Obtain 10 mounts.", pts = 10, title = "%s of Ten Saddles",
          progress = function() return math.min(MountCount(), 10), 10 end },
        { key = "tabard", id = 621, name = "Represent", desc = "Equip a tabard.", pts = 10, title = "Standard-Bearer %s",
          progress = function() return GetInventoryItemID("player", 19) and 1 or 0, 1 end },
    } },
    { title = "AROUND AZEROTH", list = {
        { key = "fall", title = "%s the Groundbreaker", id = 964, name = "Going Down?", desc = "Fall 65 yards without dying.", pts = 10,
          titleRequires = function() return DB().fallVerified end,
          progress = function() return DB().fall and 1 or 0, 1 end },
        { key = "critters", id = 1206, name = "To All The Squirrels I've Loved Before",
          desc = "Show the critters of Azeroth how much you /love them.", pts = 10, list = CRITTERS,
          has = function(n) return DB().critters[n] end,
          -- (whether it lives in this zone: the list dims the ones that do not)
          here = function(n) return FAC.CritterHere(n) end,
          progress = function() return Count(DB().critters), #CRITTERS end },
        { key = "pests", id = 2556, name = "Pest Control", desc = "Slay the following pests.", pts = 10, title = "%s, Scourge of Small Things",
          list = PEST_ORDER, has = function(n) return DB().pests[n] end, kill = true,
          here = function(n) return FAC.CritterHere(n) end,
          progress = function() return Count(DB().pests), #PEST_ORDER end },
        { key = "books", id = 1244, name = "Well Read", desc = "Read the books listed below.", pts = 10, title = "Archivist %s",
          list = ns.BOOKS, has = function(n) return DB().books[n] end,
          progress = function() return Count(DB().books), #ns.BOOKS end },
    } },
    { title = "FOOD & DRINK", list = {
        { key = "drinks", title = "%s the Tavern Regular", id = 1833, name = "It's Happy Hour Somewhere", desc = "Drink 25 different types of beverages.", pts = 10,
          seen = function() return DB().drinks end,
          progress = function() return math.min(Count(DB().drinks), 25), 25 end },
        { key = "foods", id = 1832, name = "Tastes Like Chicken", desc = "Sample 50 different kinds of Azeroth's delectable dishes.", pts = 10,
          title = "%s, Second Helpings",
          seen = function() return DB().foods end,
          progress = function() return math.min(Count(DB().foods), 50), 50 end },
    } },
    { title = "LOOT ROLLS", list = {
        { key = "greedy", id = 558, name = "Greedy", desc = "Win a greed roll on a superior or better item by rolling 100.", pts = 10,
          progress = function() return DB().greedy and 1 or 0, 1 end },
        { key = "needy", id = 559, name = "Needy", desc = "Win a need roll on a superior or better item by rolling 100.", pts = 10,
          progress = function() return DB().needy and 1 or 0, 1 end },
    } },
}

-------------------------------------------------------------------------------
--  Quests and Exploration (WotLK categories, the parts the Forever world has)
-------------------------------------------------------------------------------

-- Character statistics the client keeps (the WotLK Statistics page): a
-- number, or a money string with coin icons.
local function StatText(id)
    local text = GetStatistic and GetStatistic(id)
    if type(text) ~= "string" or secret(text) then return nil end
    return text
end

local function StatNumber(id)
    local text = StatText(id)
    if not text then return nil end
    return tonumber((text:gsub("%D", "")))
end

local function StatCopper(id)
    local text = StatText(id)
    if not text then return nil end
    local total, found = 0, false
    for n, coin in text:gmatch("(%d+)%s*|T[^|]-UI%-(%a+)Icon") do
        local v = tonumber(n) or 0
        coin = coin:lower()
        if coin == "gold" then total = total + v * 10000
        elseif coin == "silver" then total = total + v * 100
        else total = total + v end
        found = true
    end
    if found then return total end
    return tonumber((text:gsub("%D", "")))
end

local STAT_QUESTS, STAT_DAILIES, STAT_QUEST_GOLD = 98, 97, 326

local function CompletedIDs()
    if C_QuestLog and C_QuestLog.GetAllCompletedQuestIDs then return C_QuestLog.GetAllCompletedQuestIDs() or {} end
    local t, out = {}, {}
    if GetQuestsCompleted then GetQuestsCompleted(t) end
    for id in pairs(t) do out[#out + 1] = id end
    return out
end

local function QuestCount()
    local n = StatNumber(STAT_QUESTS)
    if n and n > 0 then return n end
    return #CompletedIDs()
end

local function IsQuestDone(id)
    if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then return C_QuestLog.IsQuestFlaggedCompleted(id) end
    return IsQuestFlaggedCompleted and IsQuestFlaggedCompleted(id) or false
end

-- A Simple Re-Quest: days on which the daily counter went up.
local function TrackDailies()
    local n = StatNumber(STAT_DAILIES)
    if not n then return end
    local d = DB()
    d.dailyDays = d.dailyDays or {}
    if d.dailyLast and n > d.dailyLast then d.dailyDays[date("%Y-%m-%d")] = true end
    d.dailyLast = n
end

local function DailyStreak()
    local days = DB().dailyDays or {}
    local best, run = 0, 0
    for i = 0, 60 do
        if days[date("%Y-%m-%d", time() - i * 86400)] then
            run = run + 1
            if run > best then best = run end
        else
            run = 0
        end
    end
    return best
end

-- Loremaster: completed quests whose QuestieDB zone is in the continent's
-- area list. Needs QuestieDB (asked through Questie.lua's adapter only);
-- counted again when quests are turned in.
local loreCount = {}
local function CountLore()
    wipe(loreCount)
    local Q = ns.Questie
    if not (Q and Q.Ready()) then return end
    local ek, kal = {}, {}
    for _, a in ipairs(ns.LORE_EK_A.areas) do ek[a] = true end
    for _, a in ipairs(ns.LORE_KAL_A.areas) do kal[a] = true end
    local nEK, nKal = 0, 0
    for _, id in ipairs(CompletedIDs()) do
        local z = Q.QuestZone(id)
        if z then
            if ek[z] then nEK = nEK + 1 elseif kal[z] then nKal = nKal + 1 end
        end
    end
    loreCount.ek, loreCount.kal = nEK, nKal
end

local function Faction() return UnitFactionGroup("player") == "Horde" and "H" or "A" end

local function LoreNeed(key)
    local t = ns["LORE_" .. key .. "_" .. Faction()]
    return t and t.need or 700
end

-- Exploration: a zone's subzones count when the world map shows them
-- uncovered (matched by the map overlay's position) or when you have
-- stood in them since installing.
local zoneMaps -- [zone name] = uiMapID, built on first use
local function NormZone(s)
    return (s or ""):lower():gsub("^the ", ""):gsub(" desert$", "")
end

local function ZoneMaps()
    if zoneMaps then return zoneMaps end
    zoneMaps = {}
    if not (C_Map and C_Map.GetBestMapForUnit and C_Map.GetMapChildrenInfo) then return zoneMaps end
    local m = C_Map.GetBestMapForUnit("player")
    local top = m
    while m do
        local info = C_Map.GetMapInfo(m)
        if not info then break end
        top = m
        if not info.parentMapID or info.parentMapID == 0 then break end
        m = info.parentMapID
    end
    if not top then zoneMaps = nil return {} end
    for _, child in ipairs(C_Map.GetMapChildrenInfo(top, Enum.UIMapType.Zone, true) or {}) do
        zoneMaps[NormZone(child.name)] = zoneMaps[NormZone(child.name)] or child.mapID
    end
    return zoneMaps
end

local exploredCache, exploredAt = {}, 0
local function ExploredOffsets(mapID)
    if GetTime() - exploredAt > 5 then
        wipe(exploredCache)
        exploredAt = GetTime()
    end
    local c = exploredCache[mapID]
    if c then return c end
    c = {}
    if C_MapExplorationInfo and C_MapExplorationInfo.GetExploredMapTextures then
        for _, tex in ipairs(C_MapExplorationInfo.GetExploredMapTextures(mapID) or {}) do
            c[#c + 1] = { tex.offsetX or 0, tex.offsetY or 0 }
        end
    end
    exploredCache[mapID] = c
    return c
end

local function ZoneKey(z) return z.key or ("explore" .. z.id) end

local function AreaExplored(zone, area)
    local ex = DB().explored
    local seen = ex and (ex[ZoneKey(zone)] or (zone.id and ex[zone.id])) -- older saves used the ID
    if seen and seen[area[1]] then return true end
    local mapID = zone.map or ZoneMaps()[NormZone(zone.zone)]
    -- 0, 0 in the data is "offset not known", not the map's corner (0 is
    -- true in Lua): such an area counts by its subzone name only.
    if not mapID or not area[2] or not area[3] or (area[2] == 0 and area[3] == 0) then return false end
    for _, o in ipairs(ExploredOffsets(mapID)) do
        if math.abs(o[1] - area[2]) <= 2 and math.abs(o[2] - area[3]) <= 2 then return true end
    end
    return false
end

local function NoteSubzone()
    local zoneText = NormZone(GetRealZoneText() or GetZoneText())
    local sub = GetSubZoneText()
    if not sub or sub == "" or secret(sub) then return end
    for _, z in ipairs(ns.EXPLORE) do
        if NormZone(z.zone) == zoneText then
            for _, area in ipairs(z.areas) do
                if area[1] == sub then
                    local d = DB()
                    local zk = ZoneKey(z)
                    d.explored = d.explored or {}
                    d.explored[zk] = d.explored[zk] or {}
                    if not d.explored[zk][sub] then
                        d.explored[zk][sub] = true
                        return true
                    end
                end
            end
        end
    end
end

local function QuestAch(key, id, n, pts, title)
    return { key = key, id = id, series = "quests", name = n .. " Quests Completed",
             desc = "Complete " .. n .. " quests.", pts = pts or 10, title = title,
             progress = function() return math.min(QuestCount(), n), n end }
end

local function DailyAch(key, id, n)
    return { key = key, id = id, series = "dailies", name = n .. " Daily Quests Complete",
             desc = "Complete " .. n .. " daily quests.", pts = 10,
             progress = function() return math.min(StatNumber(STAT_DAILIES) or 0, n), n end }
end

local GREEN_HILLS_NAMES = { [338] = "The Green Hills of Stranglethorn", [208] = "Big Game Hunter" }
local greenHillsList = {}
for _, q in ipairs(ns.GREEN_HILLS) do greenHillsList[#greenHillsList + 1] = GREEN_HILLS_NAMES[q] or ("Quest " .. q) end

local loreEK = { key = "loreEK", id = 1676, name = "Loremaster of Eastern Kingdoms", pts = 10,
    progress = function() local n = LoreNeed("EK"); return math.min(loreCount.ek or 0, n), n end }
local loreKal = { key = "loreKal", id = 1678, name = "Loremaster of Kalimdor", pts = 10,
    progress = function() local n = LoreNeed("KAL"); return math.min(loreCount.kal or 0, n), n end }
loreEK.desc = "Complete quests in Eastern Kingdoms (counted with QuestieDB)."
loreKal.desc = "Complete quests in Kalimdor (counted with QuestieDB)."

-- The Bread Winner is quest gold, not a quest line: it joins General > Money.
for _, sec in ipairs(SECTIONS) do
    if sec.title == "MONEY" then
        table.insert(sec.list, {
            key = "breadwinner", id = 1182, name = "The Bread Winner", pts = 10, money = true,
            desc = "Make 10,000 gold from quest rewards.",
            progress = function() return math.min(StatCopper(STAT_QUEST_GOLD) or 0, 100000000), 100000000 end,
        })
    end
end

local QUEST_SECTIONS = {
    { title = "QUESTS COMPLETED", list = {
        QuestAch("q50", 503, 50), QuestAch("q100", 504, 100), QuestAch("q250", 505, 250),
        QuestAch("q500", 506, 500), QuestAch("q1000", 507, 1000), QuestAch("q1500", 508, 1500),
        QuestAch("q2000", 32, 2000), QuestAch("q3000", 978, 3000, 50, "%s, No Errand Too Small"),
    } },
    { title = "DAILY QUESTS", list = {
        DailyAch("d5", 973, 5), DailyAch("d50", 974, 50), DailyAch("d200", 975, 200),
        DailyAch("d500", 976, 500), DailyAch("d1000", 977, 1000),
        { key = "request", id = 31, name = "A Simple Re-Quest", pts = 10,
          desc = "Complete a daily quest every day for five consecutive days.",
          progress = function() return math.min(DailyStreak(), 5), 5 end },
    } },
    { title = "QUEST LINES", list = {
        { key = "greenhills", id = 940, name = "The Green Hills of Stranglethorn", pts = 10,
          desc = "Complete all of Hemet Nesingwary quests in Stranglethorn Vale.",
          list = greenHillsList,
          has = function(n)
              for q, name in pairs(GREEN_HILLS_NAMES) do if name == n then return IsQuestDone(q) end end
          end,
          progress = function()
              local n = 0
              for _, q in ipairs(ns.GREEN_HILLS) do if IsQuestDone(q) then n = n + 1 end end
              return n, #ns.GREEN_HILLS
          end },
    } },
    { title = "LOREMASTER", list = {
        loreEK, loreKal,
        { key = "loremaster", id = 1681, name = "The Loremaster", pts = 10,
          desc = "Complete Loremaster of Eastern Kingdoms and Loremaster of Kalimdor.",
          list = { "Loremaster of Eastern Kingdoms", "Loremaster of Kalimdor" },
          has = function(n)
              if n:find("Eastern", 1, true) then return DB().done.loreEK end
              return DB().done.loreKal
          end,
          progress = function()
              return (DB().done.loreEK and 1 or 0) + (DB().done.loreKal and 1 or 0), 2
          end },
    } },
}

-- Exploration: one achievement per zone, then the continents and the world.
local function ZoneAch(z)
    local names = {}
    for _, area in ipairs(z.areas) do names[#names + 1] = area[1] end
    return { key = ZoneKey(z), id = z.id, icon = z.icon, name = "Explore " .. z.zone, pts = 10,
             desc = "Explore " .. z.zone .. ", revealing the covered areas of the world map.",
             list = names,
             has = function(n)
                 for _, area in ipairs(z.areas) do if area[1] == n then return AreaExplored(z, area) end end
             end,
             progress = function()
                 local n = 0
                 for _, area in ipairs(z.areas) do if AreaExplored(z, area) then n = n + 1 end end
                 return n, #z.areas
             end }
end

local ekZones, kalZones, otherZones = {}, {}, {}
for _, z in ipairs(ns.EXPLORE) do
    local a = ZoneAch(z)
    if z.cont == "ek" then ekZones[#ekZones + 1] = a
    elseif z.cont == "kal" then kalZones[#kalZones + 1] = a
    else otherZones[#otherZones + 1] = a end
end

local function ContinentAch(key, id, name, zones)
    local names = {}
    for _, a in ipairs(zones) do names[#names + 1] = (a.name:gsub("^Explore ", "")) end
    return { key = key, id = id, name = name, pts = 25,
             desc = "Explore the regions of " .. name:gsub("^Explore ", "") .. ".",
             list = names,
             has = function(n)
                 for _, a in ipairs(zones) do if a.name == "Explore " .. n then return DB().done[a.key] end end
             end,
             progress = function()
                 local n = 0
                 for _, a in ipairs(zones) do if DB().done[a.key] then n = n + 1 end end
                 return n, #zones
             end }
end

local exploreEK = ContinentAch("exploreEK", 42, "Explore Eastern Kingdoms", ekZones)
local exploreKal = ContinentAch("exploreKal", 43, "Explore Kalimdor", kalZones)

local EXPLORE_SECTIONS = {
    { title = "AZEROTH", list = {
        exploreEK, exploreKal,
        { key = "worldexplorer", id = 46, name = "World Explorer", pts = 50,
          desc = "Explore Eastern Kingdoms and Kalimdor.",
          list = { "Eastern Kingdoms", "Kalimdor" },
          has = function(n) return n == "Kalimdor" and DB().done.exploreKal or DB().done.exploreEK end,
          progress = function()
              return (DB().done.exploreEK and 1 or 0) + (DB().done.exploreKal and 1 or 0), 2
          end },
    } },
    { title = "EASTERN KINGDOMS", list = ekZones },
    { title = "KALIMDOR", list = kalZones },
    { title = "ZEPHRAS ISLE", list = otherZones },
}

-- Shared with the next parts.
FAC.TAG = TAG
FAC.DB = DB
FAC.Count = Count
FAC.secret = secret
FAC.CRITTERS = CRITTERS
FAC.PESTS = PESTS
FAC.PEST_ORDER = PEST_ORDER
FAC.GetItemInfoInstant = GetItemInfoInstant
FAC.SECTIONS = SECTIONS
FAC.StatText = StatText
FAC.StatNumber = StatNumber
FAC.IsQuestDone = IsQuestDone
FAC.TrackDailies = TrackDailies
FAC.CountLore = CountLore
FAC.NoteSubzone = NoteSubzone
FAC.QUEST_SECTIONS = QUEST_SECTIONS
FAC.ekZones = ekZones
FAC.kalZones = kalZones
FAC.otherZones = otherZones
FAC.EXPLORE_SECTIONS = EXPLORE_SECTIONS
