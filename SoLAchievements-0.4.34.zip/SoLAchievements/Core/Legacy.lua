local _, ns = ...
local FAC = ns.Split_SoLAchievements
local secret = FAC.secret
local challenges, challengeIDs = {}, {}

-- The Forever catalogue has one point per challenge. Explorer's supporting
-- continent records and the beta participation record do not award points.
local supporting = {
    ["Explore Azeroth"] = true, ["Explore Eastern Kingdoms"] = true, ["Explore Kalimdor"] = true,
}
for _, section in ipairs(ns.FOREVER_ACH) do
    for _, entry in ipairs(section.list) do
        if entry.group ~= "Beta" and not supporting[entry.name] then
            challenges[#challenges + 1] = entry
            for _, id in ipairs(entry.ids) do challengeIDs[id] = true end
        end
    end
end
FAC.LEGACY_CHALLENGE_IDS = challengeIDs

local snapshot
local function ReadChallenges()
    if snapshot then return snapshot end
    local data = { earned = 0, rows = {}, available = false }
    if not GetAchievementInfo then return data end
    for _, entry in ipairs(challenges) do
        local done = false
        for _, id in ipairs(entry.ids) do
            local ok, found, _, _, completed = pcall(GetAchievementInfo, id)
            if ok and not secret(found) and found and id ~= 684 then data.available = true end
            if ok and not secret(found) and found and not secret(completed) and completed == true then
                done = true
                break
            end
        end
        if done then data.earned = data.earned + 1 end
        data.rows[#data.rows + 1] = { entry.name, done }
    end
    snapshot = data
    return data
end

local function IsAvailable()
    return ReadChallenges().available
end

local function Milestone(key, name, target)
    return {
        key = key, name = name, desc = ("Earn %d Legacy %s."):format(target, target == 1 and "Point" or "Points"),
        pts = 10, icon = 236679, requires = IsAvailable,
        tracking = "Counts Legacy Points earned by your account, including points already spent.",
        progress = function() return math.min(ReadChallenges().earned, target), target end,
    }
end

FAC.LEGACY_SECTIONS = {
    { title = "LEGACY POINTS", list = {
        Milestone("foreverLegacy1", "A Legacy Begins", 1),
        Milestone("foreverLegacy5", "Something to Build On", 5),
        Milestone("foreverLegacy15", "A Legacy Takes Shape", 15),
    } },
    { title = "LEGACY MASTERY", list = {
        {
            key = "foreverLegacyAll", name = "A Legacy Without Equal",
            desc = "Complete every point-awarding Forever Legacy Challenge across your account.",
            pts = 50, icon = 236679, title = "%s, Heir to Azeroth", requires = IsAvailable,
            tracking = "Uses Blizzard's account-wide Legacy Challenge completions.",
            progress = function() return ReadChallenges().earned, #challenges end,
            dynamicList = function() return ReadChallenges().rows end,
        },
    } },
}

local events = CreateFrame("Frame")
local function Changed()
    snapshot = nil
    if FAC.CheckAll then FAC.CheckAll() end
end
for _, event in ipairs({ "PLAYER_ENTERING_WORLD", "ACHIEVEMENT_EARNED", "CURRENCY_DISPLAY_UPDATE" }) do
    pcall(events.RegisterEvent, events, event)
end
events:SetScript("OnEvent", function(_, event, id)
    if event == "PLAYER_ENTERING_WORLD" or (not secret(id) and
        ((event == "ACHIEVEMENT_EARNED" and challengeIDs[id])
        or (event == "CURRENCY_DISPLAY_UPDATE" and (id == 4225 or id == nil)))) then
        Changed()
    end
end)
