local _, ns = ...
local FAC = ns.Split_SoLAchievements

local groups = {
    { key = "adventures", label = "World & Quests" },
    { key = "camping", label = "Camping" },
    { key = "library", label = "Library Books" },
    { key = "dungeons", label = "Dungeons & Raids" },
    { key = "reputation", label = "Reputation" },
    { key = "pvp", label = "PvP" },
    { key = "legacy", label = "Legacy" },
}
FAC.FOREVER_GROUPS = groups

local function SectionsIn(category, group)
    if category == "general" then
        return group == "FOREVER ADVENTURES" and { "adventures", "FOREVER ADVENTURES" }
            or group == "FOREVER LIBRARY BOOKS" and { "library", "LIBRARY BOOKS" }
    elseif category == "exploration" and group == "ZEPHRAS ISLE" then return { "adventures", "ZEPHRAS ISLE" }
    elseif category == "dungeons" and group == "FOREVER DUNGEONS" then return { "dungeons", "FOREVER DUNGEONS" }
    elseif category == "reputation" and group == "FOREVER FACTIONS" then return { "reputation", "FOREVER FACTIONS" }
    end
end

local byKey = {
    foreverCampBenefits = { "camping", "CAMPING" }, foreverCampfires = { "camping", "CAMPING" },
    foreverCampFeatures = { "camping", "CAMPING" }, foreverCampVariety = { "camping", "CAMPING" },
    foreverExpertFire = { "camping", "CAMPING" }, foreverGreatOutdoors = { "camping", "CAMPING" },
    foreverTitanRelic = { "dungeons", "DUNGEON QUESTS" }, foreverDalaranMote = { "dungeons", "DUNGEON QUESTS" },
    dungeonDelver = { "dungeons", "DUNGEON META" },
    foreverDarkspearVictory = { "pvp", "DARKSPEAR ISLANDS" }, diWin = { "pvp", "DARKSPEAR ISLANDS" },
    diVet = { "pvp", "DARKSPEAR ISLANDS" }, battlemaster = { "pvp", "BATTLEGROUND META" },
    repRaiders = { "pvp", "BATTLEGROUND REPUTATION" }, repTheramore = { "pvp", "BATTLEGROUND REPUTATION" },
}

function FAC.MoveForeverCategories(categories)
    local destinations = {}
    local function Add(route, achievement)
        local key, title = route[1], route[2]
        local bucket = destinations[key]
        if not bucket then bucket = {}; destinations[key] = bucket end
        for _, section in ipairs(bucket) do
            if section.title == title then section.list[#section.list + 1] = achievement; return end
        end
        bucket[#bucket + 1] = { group = key, title = title, list = { achievement } }
    end

    for _, section in ipairs(FAC.LEGACY_SECTIONS) do
        for _, achievement in ipairs(section.list) do Add({ "legacy", section.title }, achievement) end
    end
    local order = { "general", "quests", "exploration", "professions", "dungeons", "reputation", "pvp", "feats" }
    for _, category in ipairs(order) do
        local sections = categories[category]
        local keep = {}
        for _, section in ipairs(sections) do
            local all = SectionsIn(category, section.title)
            local remaining = {}
            for _, achievement in ipairs(section.list) do
                local route = byKey[achievement.key]
                if not route and achievement.nativeIDs then
                    route = section.title == "FOREVER BETA" and { "adventures", "FOREVER BETA" }
                        or { "legacy", "LEGACY CHALLENGES: " .. section.title }
                end
                route = route or all
                if route then
                    Add(route, achievement)
                else
                    remaining[#remaining + 1] = achievement
                end
            end
            section.list = remaining
            if #remaining > 0 then keep[#keep + 1] = section end
        end
        categories[category] = keep
    end

    local forever = {}
    for _, group in ipairs(groups) do
        for _, section in ipairs(destinations[group.key] or {}) do forever[#forever + 1] = section end
    end
    categories.forever = forever
end
