local _, ns = ...
local FAC = ns.Split_SoLAchievements
local DB, secret = FAC.DB, FAC.secret

local CAMP_BENEFITS = 1229741
local NIGHT_WATCH_QUEST, NIGHT_WATCH_TORCH = 99267, { 280612 }

-- Item-use spell IDs from the Forever camping catalogue. The recipe spells
-- have different IDs and must not award placement credit.
local campfires = { [1307227] = true, [1307252] = true, [1307237] = true }
local features = {
    [1307259] = "manaWell", [1307242] = "fermenter", [1307172] = "alchemyLab",
    [1307392] = "sharpeningWheel", [1307175] = "anvil", [1307261] = "masterForge",
    [1307257] = "cookiesFeast", [1307226] = "ironOven",
    [1307234] = "enchantedLute", [1307223] = "arcaneSalvager", [1307176] = "arcaneForge",
    [1307266] = "reagentBot", [1307385] = "repairBot", [1307174] = "anarchistsWorkbench",
    [1307244] = "firstAidKit", [1307396] = "toxinStudy", [1307265] = "plagueDoctorsLab",
    [1307245] = "fishBowl", [1307247] = "fishingRack", [1307246] = "fishingHut",
    [1307251] = "incenseCandle", [1307248] = "greenhouse", [1307387] = "seedHybridizer",
    [1307230] = "campTent", [1307395] = "tanningRack", [1307391] = "sewingMachine",
    [1307254] = "lodestone", [1307386] = "rockGarden", [1307264] = "moltenFoundry",
    [1307229] = "campChair", [1307243] = "fieldGuide", [1307397] = "trappersWorkbench",
    [1307239] = "factionBanner", [1307240] = "factionBanner",
    [1307393] = "spinningWheel", [1307255] = "loom",
}

local function Camps()
    local db = DB()
    db.camping = db.camping or { distinct = {} }
    return db.camping
end

local function CampAchievement(key, name, desc, countKey, goal, icon)
    return {
        key = key, name = name, desc = desc, pts = 10, icon = icon,
        tracking = "Tracked on this character from the time SoLAchievements sees it.",
        progress = function() return math.min(Camps()[countKey] or 0, goal), goal end,
    }
end

table.insert(FAC.SECTIONS, { title = "FOREVER ADVENTURES", list = {
    CampAchievement("foreverCampBenefits", "Fireside Regular", "Gain the Camp Benefits buff 20 times.", "benefits", 20, 135805),
    CampAchievement("foreverCampfires", "Keep the Fire Burning", "Place 25 campfires using campfire kits.", "fires", 25, 135805),
    CampAchievement("foreverCampFeatures", "Make Yourself at Home", "Place 10 profession camp features at campfires.", "features", 10, 134329),
    CampAchievement("foreverCampVariety", "Something for the Campsite", "Place 3 different profession camp features.", "variety", 3, 134329),
    {
        key = "foreverNightwatch", name = "A Light in Duskwood", pts = 10, icon = 135432,
        desc = "Obtain the Night Watchman's Torch from the fallen Night Watch Guard in Duskwood.",
        title = "%s of the Nightwatch",
        tracking = "Counts the torch or completion of An Unfortunate End on this character.",
        progress = function() return (FAC.IsQuestDone(NIGHT_WATCH_QUEST) or ns.Owns(NIGHT_WATCH_TORCH)) and 1 or 0, 1 end,
    },
} })

local function Readable(value)
    return not secret(value) and (not canaccessvalue or canaccessvalue(value))
end

local lastCast, lastBenefit
local function OnCast(cast, spell)
    if not Readable(spell) or type(spell) ~= "number" then return end
    local feature = features[spell]
    if not (campfires[spell] or feature) then return end
    if Readable(cast) and type(cast) == "string" and cast ~= "" then
        if lastCast == cast then return end
        lastCast = cast
    end
    local camps = Camps()
    if campfires[spell] then
        camps.fires = math.min((camps.fires or 0) + 1, 25)
        if spell == 1307237 then camps.expertFire = true end
    else
        camps.features = math.min((camps.features or 0) + 1, 10)
        if not camps.distinct[feature] then
            camps.distinct[feature] = true
            camps.variety = (camps.variety or 0) + 1
        end
    end
    FAC.CheckAll()
end

local function OnAura(update)
    -- Incremental events describe actual applications. Full snapshots (login,
    -- reload, zoning) are not awards. No queries of protected aura data.
    if (C_Secrets and C_Secrets.ShouldAurasBeSecret and C_Secrets.ShouldAurasBeSecret())
        or not Readable(update) or type(update) ~= "table" then return end
    local full, added = update.isFullUpdate, update.addedAuras
    if not Readable(full) or full or not Readable(added) or type(added) ~= "table" then return end
    for _, aura in ipairs(added) do
        if Readable(aura) and type(aura) == "table" then
            local spell, instance = aura.spellId, aura.auraInstanceID
            if Readable(spell) and spell == CAMP_BENEFITS and Readable(instance)
                and type(instance) == "number" and instance ~= lastBenefit then
                lastBenefit = instance
                local camps = Camps()
                camps.benefits = math.min((camps.benefits or 0) + 1, 20)
                FAC.CheckAll()
            end
        end
    end
end

local events = CreateFrame("Frame")
events:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", "player")
events:RegisterUnitEvent("UNIT_AURA", "player")
events:SetScript("OnEvent", function(_, event, unit, arg1, arg2)
    if not Readable(unit) or unit ~= "player" then return end
    if event == "UNIT_SPELLCAST_SUCCEEDED" then OnCast(arg1, arg2) else OnAura(arg1) end
end)
