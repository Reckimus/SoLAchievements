local _, ns = ...
local FAC = ns.Split_SoLAchievements
local DB, secret = FAC.DB, FAC.secret

local bossByName, bossByID = {}, {}
local achievements = {}
local dungeonNames = { [644] = "Dire Maul" }

local function RegisterDungeon(dungeon)
    local name = dungeonNames[dungeon.id] or dungeon.name
    local key = "guild" .. (dungeon.key or ("dungeon" .. dungeon.id))
    local criteria = {}
    for _, boss in ipairs(dungeon.bosses) do
        local criterion = { key = key, name = boss[1] }
        criteria[#criteria + 1] = criterion
        bossByName[boss[1]] = criterion
        if boss[2] then bossByID[boss[2]] = criterion end
        if not dungeon.all then break end
    end

    local function HasBoss(bossName)
        local kills = DB().guildDungeonBosses
        return kills and kills[bossName]
    end

    local achievement = {
        key = key, name = "Guild Run: " .. name, instance = name,
        desc = "Complete " .. name .. " in a full party from your guild.",
        tracking = "Checks for you and four online guildmates at each required boss kill.",
        icon = dungeon.icon or ns.ICONS[dungeon.id], pts = 10, kill = true,
        progress = function()
            local count = 0
            for _, criterion in ipairs(criteria) do
                if HasBoss(criterion.name) then count = count + 1 end
            end
            return count, #criteria
        end,
    }
    if #criteria > 1 then
        achievement.list, achievement.has = {}, HasBoss
        for _, criterion in ipairs(criteria) do
            achievement.list[#achievement.list + 1] = criterion.name
        end
    end
    achievements[#achievements + 1] = achievement
end

for _, dungeon in ipairs(ns.DUNGEONS) do
    -- Upper Blackrock Spire is designed for ten players.
    if dungeon.id ~= 1307 then RegisterDungeon(dungeon) end
end
for _, dungeon in ipairs(FAC.FOREVER_DUNGEONS) do RegisterDungeon(dungeon) end
-- The encounter list and the quest use different names for the same boss.
bossByName["Overseer Mugg"] = bossByName["Overlord Mugg"]
table.insert(FAC.DUNGEON_SECTIONS, { title = "GUILD DUNGEONS", list = achievements })

local function Readable(value)
    return not secret(value) and (not canaccessvalue or canaccessvalue(value))
end

local function FullGuildParty()
    if not (GetNumGroupMembers and IsInGuild and IsInRaid) then return false end
    local count, inGuild, inRaid = GetNumGroupMembers(), IsInGuild(), IsInRaid()
    if not (Readable(count) and count == 5 and Readable(inGuild) and inGuild == true
        and Readable(inRaid) and inRaid == false) then return false end

    local guild, realm
    for i = 1, 4 do
        local unit = "party" .. i
        if UnitIsConnected then
            local connected = UnitIsConnected(unit)
            if not Readable(connected) or connected ~= true then return false end
        end
        local ok, member
        if UnitIsInMyGuild then ok, member = pcall(UnitIsInMyGuild, unit) end
        if ok and Readable(member) and type(member) == "boolean" then
            if not member then return false end
        else
            if not GetGuildInfo then return false end
            if not guild then
                local read, name, _, _, server = pcall(GetGuildInfo, "player")
                if not (read and Readable(name) and type(name) == "string" and Readable(server)) then return false end
                guild, realm = name, server
            end
            local read, name, _, _, server = pcall(GetGuildInfo, unit)
            if not (read and Readable(name) and Readable(server) and name == guild and server == realm) then return false end
        end
    end
    return true
end

function FAC.RecordGuildDungeonBoss(id, name)
    local boss = (id and bossByID[id]) or (name and bossByName[name])
    if not boss or not GetInstanceInfo then return false end
    local d = DB()
    local kills = d.guildDungeonBosses
    if d.done[boss.key] or (kills and kills[boss.name]) then return false end
    local _, instanceType = GetInstanceInfo()
    if not (Readable(instanceType) and instanceType == "party" and FullGuildParty()) then return false end
    if not kills then
        kills = {}
        d.guildDungeonBosses = kills
    end
    kills[boss.name] = true
    return true
end
