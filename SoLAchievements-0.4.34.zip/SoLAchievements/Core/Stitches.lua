local _, ns = ...
local FAC = ns.Split_SoLAchievements
local STITCHES, FEMUR = 412, 3360
local ASSIST, SAVIOR = "stitchesAssist", "stitchesSavior"
local report = {}

local function Report()
    print("|cff0cd29fSoLAchievements|r Stitches: " .. table.concat({
        report.unit or "unit not seen", report.death or "death not seen",
        report.tap or "tag unknown", report.damage or "damage not checked",
        report.loot or "no matching loot seen",
    }, " / "))
end
ns.StitchesReport = Report

local function NightwatchAchievement(key, name, desc, tracking)
    return {
        key = key, name = name, desc = desc, pts = 10, icon = 135432, kill = true, tracking = tracking,
        zone = "Duskwood",
        progress = function() return FAC.DB().flags[key] and 1 or 0, 1 end,
    }
end

table.insert(FAC.SECTIONS, { title = "DUSKWOOD", list = {
    NightwatchAchievement(ASSIST, "Assisting the Nightwatch!",
        "Damage Stitches in Duskwood and witness his death.",
        "Awards participation when your damage is confirmed and your own kill credit isn't confirmed."),
    NightwatchAchievement(SAVIOR, "Nightwatch Savior!",
        "Defeat Stitches in Duskwood with loot credit.",
        "Checks your damage and tag at death, or verifies that you could open Stitches' loot."),
} })

local function Readable(value)
    return not FAC.secret(value) and (not canaccessvalue or canaccessvalue(value))
end

local function IsStitches(guid)
    return Readable(guid) and type(guid) == "string" and tonumber(guid:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")) == STITCHES
end

local function Award(key)
    local flags = FAC.DB().flags
    if flags[key] then return end
    flags[key] = true
    FAC.CheckAll(nil, true)
end

local function CheckLoot()
    if not GetNumLootItems or FAC.DB().flags[SAVIOR] then return end
    local slots = GetNumLootItems()
    if not Readable(slots) or type(slots) ~= "number" then return end
    if slots > 0 and not report.loot then report.loot = "loot opened without matching source" end
    for slot = 1, slots do
        if GetLootSourceInfo then
            local sources = { GetLootSourceInfo(slot) }
            for i = 1, #sources, 2 do
                if IsStitches(sources[i]) then report.loot = "Stitches loot source"; Award(SAVIOR); return end
            end
        end
        -- The Femur only drops from Stitches. Check the actual loot slot,
        -- since a bag item could have been purchased or traded.
        local link = GetLootSlotLink and GetLootSlotLink(slot)
        if Readable(link) and type(link) == "string" and tonumber(link:match("item:(%d+)")) == FEMUR then
            report.loot = "Stitches' Femur in loot"
            Award(SAVIOR)
            return
        end
    end
end

local seen, lastLiveTap, candidate, queued, knownSessions
local plateUnit
local lastSessionID, lastSessionAt

local function AvailableSessions()
    local get = C_DamageMeter and C_DamageMeter.GetAvailableCombatSessions
    if not get then return {} end
    local ok, rows = pcall(get)
    return ok and Readable(rows) and type(rows) == "table" and rows or {}
end

local function SessionID(row)
    local id = Readable(row) and type(row) == "table" and row.sessionID
    if Readable(id) and type(id) == "number" and id > 0 then return id end
end

local function Remember(guid)
    if guid == seen then return end
    seen, lastLiveTap, knownSessions = guid, nil, {}
    for _, row in ipairs(AvailableSessions()) do
        local id = SessionID(row)
        if id then knownSessions[id] = true end
    end
end

local function PlayerNameKey(name)
    if Readable(name) and type(name) == "string" and name ~= "" then
        return name:lower():gsub("[%s%-]+", "-"):gsub("%-+$", "")
    end
end

local function MeterShowsDamage(getEnemies, getDetails, session, kind, fight, player)
    local ok, data = pcall(getEnemies, session, kind)
    if not ok or not Readable(data) or type(data) ~= "table" then report.damage = "meter session unavailable"; return end
    local enemies = data.combatSources
    if not Readable(enemies) or type(enemies) ~= "table" then return end
    local matched
    for _, enemy in ipairs(enemies) do
        if Readable(enemy) and type(enemy) == "table" then
            local guid, id, name = enemy.sourceGUID, enemy.sourceCreatureID, enemy.name
            if (Readable(guid) and IsStitches(guid))
                or (Readable(id) and id == STITCHES)
                or (Readable(name) and name == "Stitches") then
                -- EnemyDamageTaken can group its targets by creature ID and
                -- omit the GUID. If a real spawn GUID exists, it must match.
                if not Readable(guid) or not IsStitches(guid) or guid == fight.guid then
                    matched = true
                    break
                end
            end
        end
    end
    if not matched then report.damage = "Stitches missing from meter"; return end

    -- In this meter view, each 'spell' row is one attacker's damage on
    -- the enemy. The source argument is the creature ID, with no GUID.
    local read, details = pcall(getDetails, session, kind, nil, STITCHES)
    if not read or not Readable(details) or type(details) ~= "table" then return end
    local attackers = details.combatSpells
    if not Readable(attackers) or type(attackers) ~= "table" then report.damage = "attacker rows unavailable"; return end
    for _, attacker in ipairs(attackers) do
        if Readable(attacker) and type(attacker) == "table" then
            local info, amount = attacker.combatSpellDetails, attacker.totalAmount
            if Readable(info) and type(info) == "table" then
                local isPet = info.isPet
                if not Readable(amount) or type(amount) ~= "number" then amount = info.amount end
                if Readable(isPet) and not isPet and PlayerNameKey(info.unitName) == player
                    and Readable(amount) and type(amount) == "number" and amount > 0 then return true end
            end
        end
    end
    report.damage = "no readable personal damage on Stitches"
end

local function PlayerDamagedStitches(fight)
    local meter = C_DamageMeter
    local kind = Enum and Enum.DamageMeterType and Enum.DamageMeterType.EnemyDamageTaken
    local sessions = Enum and Enum.DamageMeterSessionType
    if not (meter and kind) then report.damage = "enemy damage meter unavailable"; return end
    local first, last
    if UnitFullName then first, last = UnitFullName("player") end
    if not PlayerNameKey(first) and UnitName then first, last = UnitName("player") end
    local player = PlayerNameKey(first)
    if not player then return end
    local surname = PlayerNameKey(last)
    if surname then player = player .. "-" .. surname end
    if lastSessionID and lastSessionAt >= fight.when - 8
        and meter.GetCombatSessionFromID and meter.GetCombatSessionSourceFromID
        and MeterShowsDamage(meter.GetCombatSessionFromID, meter.GetCombatSessionSourceFromID, lastSessionID, kind, fight, player) then
        return true
    end
    if sessions and sessions.Current and meter.GetCombatSessionFromType and meter.GetCombatSessionSourceFromType
        and MeterShowsDamage(meter.GetCombatSessionFromType, meter.GetCombatSessionSourceFromType, sessions.Current, kind, fight, player) then
        return true
    end
    if meter.GetCombatSessionFromID and meter.GetCombatSessionSourceFromID then
        local checked = 0
        for _, row in ipairs(AvailableSessions()) do
            local id = SessionID(row)
            if id and not fight.previousSessions[id] and id ~= lastSessionID then
                checked = checked + 1
                if MeterShowsDamage(meter.GetCombatSessionFromID, meter.GetCombatSessionSourceFromID, id, kind, fight, player) then
                    return true
                end
                if checked == 3 then break end
            end
        end
    end
end

local function CheckDamage(retry)
    if not candidate or GetTime() - candidate.when > 30 then candidate = nil; return end
    if InCombatLockdown and InCombatLockdown() then return end
    if PlayerDamagedStitches(candidate) then
        local denied = candidate.denied
        report.damage = "personal damage confirmed"
        candidate = nil
        if denied == false then Award(SAVIOR) else Award(ASSIST) end
    elseif retry then
        C_Timer.After(0.7, function() CheckDamage(false) end)
    end
end

local function QueueDamage()
    if queued then return end
    queued = true
    C_Timer.After(0.2, function()
        queued = nil
        CheckDamage(true)
    end)
end

local function Observe(unit)
    if not (UnitGUID and UnitIsDead and UnitIsTapDenied) then return end
    if not unit then return end
    local guid = UnitGUID(unit)
    if not IsStitches(guid) then
        local name = UnitName and UnitName(unit)
        if not report.unit and Readable(name) and name == "Stitches" then report.unit = "Stitches name seen; NPC ID unavailable" end
        return
    end
    report.unit = "Stitches seen via " .. unit
    local flags = FAC.DB().flags
    if flags[ASSIST] and flags[SAVIOR] then return end
    local dead = UnitIsDead(unit)
    local health = UnitHealth and UnitHealth(unit)
    if seen == guid and Readable(health) and type(health) == "number" and health == 0 then dead = true end
    if not Readable(dead) then Remember(guid); return end
    if dead == false then
        Remember(guid)
        local denied = UnitIsTapDenied(unit)
        if Readable(denied) and type(denied) == "boolean" then lastLiveTap = denied end
        return
    end
    if dead ~= true then return end
    report.death = "death seen"
    if seen ~= guid then return end

    local denied = UnitIsTapDenied(unit)
    if Readable(denied) and type(denied) == "boolean" then
        -- Require two readable allowed states to infer a credited kill
        -- without loot evidence.
        if denied == false and lastLiveTap ~= false then denied = nil end
    else
        denied = lastLiveTap == true and true or nil
    end
    report.tap = denied == true and "external tag" or denied == false and "your tag eligible" or "tag unavailable"
    candidate = { guid = guid, when = GetTime(), denied = denied, previousSessions = knownSessions }
    seen, lastLiveTap, knownSessions = nil, nil, nil
    QueueDamage()
end

local plateWatch = CreateFrame("Frame")
plateWatch:SetScript("OnEvent", function() Observe(plateUnit) end)

local frame = CreateFrame("Frame")
for _, event in ipairs({ "LOOT_READY", "LOOT_OPENED", "PLAYER_TARGET_CHANGED", "PLAYER_FOCUS_CHANGED",
    "UPDATE_MOUSEOVER_UNIT", "PLAYER_REGEN_ENABLED", "PLAYER_ENTERING_WORLD", "DAMAGE_METER_COMBAT_SESSION_UPDATED",
    "NAME_PLATE_UNIT_ADDED", "NAME_PLATE_UNIT_REMOVED" }) do
    pcall(frame.RegisterEvent, frame, event)
end
pcall(frame.RegisterUnitEvent, frame, "UNIT_HEALTH", "target", "focus")
pcall(frame.RegisterUnitEvent, frame, "UNIT_FLAGS", "target", "focus")
frame:SetScript("OnEvent", function(_, event, unit, sessionID)
    if event == "LOOT_READY" or event == "LOOT_OPENED" then
        CheckLoot()
    elseif event == "PLAYER_ENTERING_WORLD" then
        seen, lastLiveTap, candidate, lastSessionID, lastSessionAt = nil, nil, nil, nil, nil
        plateUnit, knownSessions, report = nil, nil, {}
        plateWatch:UnregisterAllEvents()
    elseif event == "NAME_PLATE_UNIT_ADDED" then
        if Readable(unit) and UnitGUID and IsStitches(UnitGUID(unit)) then
            plateUnit = unit
            pcall(plateWatch.RegisterUnitEvent, plateWatch, "UNIT_HEALTH", unit)
            pcall(plateWatch.RegisterUnitEvent, plateWatch, "UNIT_FLAGS", unit)
            Observe(unit)
        end
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        if Readable(unit) and unit == plateUnit then
            Observe(plateUnit)
            plateUnit = nil
            plateWatch:UnregisterAllEvents()
        end
    elseif event == "DAMAGE_METER_COMBAT_SESSION_UPDATED" then
        if (seen or candidate) and Readable(sessionID) and type(sessionID) == "number"
            and sessionID > 0 then
            lastSessionID, lastSessionAt = sessionID, GetTime()
            if candidate and not (InCombatLockdown and InCombatLockdown()) then QueueDamage() end
        end
    elseif event == "PLAYER_REGEN_ENABLED" then
        Observe("target")
        Observe("focus")
        Observe("mouseover")
        Observe(plateUnit)
        if candidate then QueueDamage() end
    elseif event == "PLAYER_TARGET_CHANGED" then
        Observe("target")
    elseif event == "PLAYER_FOCUS_CHANGED" then
        Observe("focus")
    elseif event == "UPDATE_MOUSEOVER_UNIT" then
        Observe("mouseover")
    elseif Readable(unit) and (unit == "target" or unit == "focus") then
        Observe(unit)
    end
end)
