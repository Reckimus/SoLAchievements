-------------------------------------------------------------------------------
--  Pages that are not achievement lists: Summary, Statistics and Settings.
--  Each draws into the scroll child and returns the height it used.
-------------------------------------------------------------------------------
local _, ns = ...
local FA = ns.FA
local Kit = FA.Kit
local W = Kit.W
local C = Kit.COLORS

local CLASS_COLORS = RAID_CLASS_COLORS or {}

local function Line(child, y, height)
    local f = CreateFrame("Frame", nil, child)
    f:SetSize(child:GetWidth() - 40, height or 26)
    f:SetPoint("TOPLEFT", 20, y)
    return f
end

local function CardBg(f, hover)
    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(C.card[1], C.card[2], C.card[3], C.card[4])
    Kit.MakeBorder(f, unpack(C.edge))
    if hover then
        f:SetScript("OnEnter", function() bg:SetColorTexture(C.cardHover[1], C.cardHover[2], C.cardHover[3], C.cardHover[4]) end)
        f:SetScript("OnLeave", function() bg:SetColorTexture(C.card[1], C.card[2], C.card[3], C.card[4]) end)
    end
end

local function Bar(parent, x, width, frac)
    local r, g, b = Kit.Accent()
    local track = parent:CreateTexture(nil, "ARTWORK")
    track:SetColorTexture(1, 1, 1, 0.1)
    track:SetSize(width, 3)
    track:SetPoint("LEFT", x, 0)
    local fill = parent:CreateTexture(nil, "OVERLAY")
    fill:SetColorTexture(r, g, b, 1)
    fill:SetSize(math.max(1, width * math.min(1, frac)), 3)
    fill:SetPoint("LEFT", track, "LEFT")
end

-------------------------------------------------------------------------------
--  Summary
-------------------------------------------------------------------------------
local function CategoryCounts(key)
    local n, all = 0, 0
    for _, sec in ipairs(FA.CATEGORY_SECTIONS[key]) do
        for _, a in ipairs(sec.list) do
            if FA.Available(a) then
                all = all + 1
                if FA.Earned(a.key) then n = n + 1 end
            end
        end
    end
    return n, all
end

-- What can be done where you stand: unexplored areas, bosses of the
-- instance you are in, critters still waiting for /love.
local function Suggestions()
    local out = {}
    local zone = GetRealZoneText()
    local zoneAch = zone and FA.ZONE_ACH[zone]
    if zoneAch and not FA.Earned(zoneAch.key) then
        local missing = {}
        for _, n in ipairs(zoneAch.list) do if not zoneAch.has(n) then missing[#missing + 1] = n end end
        if #missing > 0 then out[#out + 1] = { zoneAch, "Unexplored: " .. table.concat(missing, ", ") } end
    end
    local inInstance = IsInInstance()
    if inInstance then
        local name = GetInstanceInfo()
        for _, key in ipairs({ "dungeons", "forever" }) do
            for _, sec in ipairs(FA.CATEGORY_SECTIONS[key]) do
                if key == "dungeons" or sec.group == "dungeons" then
                    for _, a in ipairs(sec.list) do
                        if name and a.name and (name:find(a.name, 1, true) or a.name:find(name, 1, true)) and not FA.Earned(a.key) then
                            out[#out + 1] = { a, a.desc }
                        end
                    end
                end
            end
        end
    end
    local crit = FA.BY_KEY.critters
    if crit and not FA.Earned("critters") then
        local missing = {}
        for _, n in ipairs(FA.CRITTERS) do if not FA.DB().critters[n] then missing[#missing + 1] = n end end
        out[#out + 1] = { crit, "Still to /love: " .. table.concat(missing, ", ") }
    end
    local pests = FA.BY_KEY.pests
    if pests and not FA.Earned("pests") then
        local missing = {}
        for _, n in pairs(FA.PESTS) do if not FA.DB().pests[n] then missing[#missing + 1] = n end end
        table.sort(missing)
        out[#out + 1] = { pests, "Still to slay: " .. table.concat(missing, ", ") }
    end
    return out, zone
end

FA.VIEWS.summary = function(child, width)
    local r, g, b = Kit.Accent()
    local y = 0
    local _, h

    -- Title
    local titles = FA.AvailableTitles()
    local character = FA.FullName("player")
    character = character and character:gsub("-", " ") or UnitName("player")
    local values, order = { none = "No title" }, { "none" }
    for _, a in ipairs(titles) do
        values[a.key] = a.title:format(character) .. (a.gameTitle and " (WoW)" or "")
        order[#order + 1] = a.key
    end
    _, h = W:SectionHeader(child, "OVERVIEW", y)
    y = y - h
    _, h = W:Dropdown(child, "Player title", y, values,
        function()
            local _, titleKey = FA.CurrentTitle()
            return titleKey or "none"
        end,
        function(v) FA.SetPlayerTitle(v ~= "none" and v or nil) end, order,
        "WoW titles are equipped in-game. Class and achievement titles are shared with other SoLAchievements users.")
    y = y - h

    -- Recently earned
    local recent = {}
    for key, t in pairs(FA.DB().done) do
        local a = FA.BY_KEY[key]
        -- (only those with a known date: the history pass has none)
        local m = FA.DB().doneMeta and FA.DB().doneMeta[key]
        if a and not (m and m.exact == false) then recent[#recent + 1] = { a, t } end
    end
    table.sort(recent, function(p, q) return p[2] > q[2] end)
    if #recent > 0 then
        _, h = W:SectionHeader(child, "RECENTLY EARNED", y)
        y = y - h
        for i = 1, math.min(5, #recent) do
            local a, t = recent[i][1], recent[i][2]
            local row = CreateFrame("Button", nil, child)
            row:SetSize(width - 40, 36)
            row:SetPoint("TOPLEFT", 20, y)
            CardBg(row, true)
            local box = ns.FramedIcon(row, 26, r, g, b, 0.8)
            box:SetPoint("LEFT", 8, 0)
            local icon = box.icon
            icon:SetTexture(a.icon or ns.ICONS[a.id] or 236376)
            local name = Kit.MakeFont(row, 13, nil, r, g, b, 1)
            name:SetPoint("LEFT", icon, "RIGHT", 10, 0)
            name:SetText(a.name)
            local when = Kit.MakeFont(row, 12, nil, C.dim[1], C.dim[2], C.dim[3], 1)
            when:SetPoint("RIGHT", -12, 0)
            when:SetText(date("%m-%d-%Y", t))
            row:SetScript("OnClick", function() FA.OpenSearch(a.name) end)
            y = y - 42
        end
        y = y - 6
    end

    -- Recently progressed (the journal): what moved lately.
    local prog = ns.RecentProgress and ns.RecentProgress(5) or {}
    if #prog > 0 then
        _, h = W:SectionHeader(child, "RECENTLY PROGRESSED", y)
        y = y - h
        for _, p in ipairs(prog) do
            local row = CreateFrame("Button", nil, child)
            row:SetSize(width - 40, 30)
            row:SetPoint("TOPLEFT", 20, y)
            CardBg(row, true)
            local label = Kit.MakeFont(row, 12, nil, C.text[1], C.text[2], C.text[3], 1)
            label:SetPoint("LEFT", 12, 0)
            label:SetText(p.a.name)
            local v = Kit.MakeFont(row, 12, nil, C.dim[1], C.dim[2], C.dim[3], 1)
            v:SetPoint("RIGHT", -12, 0)
            v:SetText(("%s -> %s"):format(ns.ProgressValue(p.a, p.from), ns.ProgressText(p.a, p.to, p.need)))
            label:SetPoint("RIGHT", v, "LEFT", -12, 0)
            label:SetJustifyH("LEFT")
            label:SetWordWrap(false)
            row:SetScript("OnClick", function() FA.OpenSearch(p.a.name) end)
            y = y - 36
        end
        y = y - 6
    end

    -- An event on now: what is left of it.
    local onNow = {}
    for _, e in ipairs(ns.EVENTS or {}) do
        if ns.EventActive and ns.EventActive(e.key) then
            local left, total = ns.EventCounts(e.key)
            if total > 0 then onNow[#onNow + 1] = { e = e, left = left, total = total } end
        end
    end
    if #onNow > 0 then
        _, h = W:SectionHeader(child, "AVAILABLE NOW", y)
        y = y - h
        for _, x in ipairs(onNow) do
            local row = CreateFrame("Button", nil, child)
            row:SetSize(width - 40, 30)
            row:SetPoint("TOPLEFT", 20, y)
            CardBg(row, true)
            local label = Kit.MakeFont(row, 12, nil, r, g, b, 1)
            label:SetPoint("LEFT", 12, 0)
            label:SetText(x.e.name)
            local v = Kit.MakeFont(row, 12, nil, C.dim[1], C.dim[2], C.dim[3], 1)
            v:SetPoint("RIGHT", -12, 0)
            v:SetText(("%d of %d to earn  ·  View"):format(x.left, x.total))
            row:SetScript("OnClick", function() FA.ShowTab("events") end)
            y = y - 36
        end
        y = y - 6
    end

    -- Progress per category
    _, h = W:SectionHeader(child, "PROGRESS", y)
    y = y - h
    for _, cat in ipairs(FA.CATEGORIES) do
        if FA.CATEGORY_SECTIONS[cat.key] then
            local n, all = CategoryCounts(cat.key)
            local row = CreateFrame("Button", nil, child)
            row:SetSize(width - 40, 30)
            row:SetPoint("TOPLEFT", 20, y)
            CardBg(row, true)
            local label = Kit.MakeFont(row, 12, nil, C.text[1], C.text[2], C.text[3], 1)
            label:SetPoint("LEFT", 12, 0)
            label:SetText(cat.label)
            Bar(row, 190, width - 360, all > 0 and n / all or 0)
            local v = Kit.MakeFont(row, 12, nil, C.dim[1], C.dim[2], C.dim[3], 1)
            v:SetPoint("RIGHT", -12, 0)
            v:SetText(n .. " / " .. all)
            row:SetScript("OnClick", function() FA.ShowTab(cat.key) end)
            y = y - 36
        end
    end
    y = y - 6

    -- Where you stand
    local tips, zone = Suggestions()
    if #tips > 0 then
        _, h = W:SectionHeader(child, "SUGGESTIONS" .. (zone and zone ~= "" and (" IN " .. zone:upper()) or ""), y)
        y = y - h
        for _, tip in ipairs(tips) do
            local a, text = tip[1], tip[2]
            local row = CreateFrame("Button", nil, child)
            row:SetSize(width - 40, 46)
            row:SetPoint("TOPLEFT", 20, y)
            CardBg(row, true)
            local name = Kit.MakeFont(row, 13, nil, C.text[1], C.text[2], C.text[3], 1)
            name:SetPoint("TOPLEFT", 12, -8)
            name:SetText(a.name)
            local desc = Kit.MakeFont(row, 11, nil, C.dim[1], C.dim[2], C.dim[3], 1)
            desc:SetPoint("TOPLEFT", name, "BOTTOMLEFT", 0, -4)
            desc:SetPoint("RIGHT", -12, 0)
            desc:SetJustifyH("LEFT")
            desc:SetWordWrap(false)
            desc:SetText(text)
            row:SetScript("OnClick", function() FA.OpenSearch(a.name) end)
            y = y - 52
        end
        y = y - 6
    end

    -- Easy wins: closest to done (this zone and events on now first).
    local wins = ns.EasyWins and ns.EasyWins(5) or {}
    if #wins > 0 then
        _, h = W:SectionHeader(child, "EASY WINS", y)
        y = y - h
        for _, w in ipairs(wins) do
            local a, rr = w[1], w[2]
            local row = CreateFrame("Button", nil, child)
            row:SetSize(width - 40, 30)
            row:SetPoint("TOPLEFT", 20, y)
            CardBg(row, true)
            local label = Kit.MakeFont(row, 12, nil, C.text[1], C.text[2], C.text[3], 1)
            label:SetPoint("LEFT", 12, 0)
            label:SetPoint("RIGHT", row, "LEFT", 180, 0)
            label:SetJustifyH("LEFT")
            label:SetWordWrap(false)
            label:SetText(a.name)
            local v = Kit.MakeFont(row, 12, nil, C.dim[1], C.dim[2], C.dim[3], 1)
            v:SetPoint("RIGHT", -12, 0)
            v:SetText(ns.ProgressText(a, rr.current, rr.required))
            Bar(row, 190, math.max(1, width - 254 - v:GetStringWidth()), rr.percent)
            row:SetScript("OnClick", function() FA.OpenSearch(a.name) end)
            y = y - 36
        end
        y = y - 6
    end

    -- Characters on this account
    local chars = {}
    for _, c in pairs(FA.Account().chars) do
        -- Older snapshots can have account-wide points in their cached totals.
        local points, count = FA.CharacterPoints(c.done or {})
        chars[#chars + 1] = { character = c, points = points, count = count }
    end
    table.sort(chars, function(p, q) return p.points > q.points end)
    if #chars > 0 then
        _, h = W:SectionHeader(child, "CHARACTERS", y)
        y = y - h
        local total = 0
        for _, entry in ipairs(chars) do
            local c = entry.character
            total = total + entry.points
            local row = Line(child, y, 30)
            CardBg(row)
            local col = CLASS_COLORS[c.class or ""]
            local name = Kit.MakeFont(row, 12, nil, col and col.r or 1, col and col.g or 1, col and col.b or 1, 1)
            name:SetPoint("LEFT", 12, 0)
            name:SetText((c.title and c.title:format(c.name) or c.name) .. "  |cff9aa5b1" .. (c.realm or "") .. "|r")
            local info = Kit.MakeFont(row, 12, nil, C.dim[1], C.dim[2], C.dim[3], 1)
            info:SetPoint("RIGHT", -12, 0)
            info:SetText(("level %d   |   %d earned   |   %d points   |   %s"):format(c.level or 0, entry.count,
                entry.points, c.last and date("%m-%d-%Y", c.last) or "-"))
            y = y - 34
        end
        local sum = Kit.MakeFont(child, 13, nil, r, g, b, 1)
        sum:SetPoint("TOPRIGHT", -32, y - 4)
        sum:SetText(("Account: %d points"):format(total))
        y = y - 30
    end
    return -y + 10
end

-------------------------------------------------------------------------------
--  Statistics
-------------------------------------------------------------------------------
local function StatRows(child, width, y, title, rows)
    local _, h = W:SectionHeader(child, title, y)
    y = y - h
    local colW = math.floor((width - 46) / 2)
    for i, row in ipairs(rows) do
        local col = (i - 1) % 2
        if col == 0 and i > 1 then y = y - 28 end
        local f = CreateFrame("Frame", nil, child)
        f:SetSize(colW, 24)
        f:SetPoint("TOPLEFT", 20 + col * (colW + 6), y)
        CardBg(f)
        local label = Kit.MakeFont(f, 11, nil, C.text[1], C.text[2], C.text[3], 0.9)
        label:SetPoint("LEFT", 10, 0)
        label:SetJustifyH("LEFT")
        label:SetWordWrap(false)
        label:SetText(row[1])
        local value = Kit.MakeFont(f, 11, nil, C.dim[1], C.dim[2], C.dim[3], 1)
        value:SetPoint("RIGHT", -10, 0)
        value:SetText(row[2] or "--")
        value:SetWidth(math.max(1, math.min(math.ceil(value:GetStringWidth()), math.floor(colW * 0.45))))
        value:SetJustifyH("RIGHT")
        value:SetWordWrap(false)
        label:SetPoint("RIGHT", value, "LEFT", -10, 0)
    end
    return y - 34
end

FA.VIEWS.statistics = function(child, width)
    local d = FA.DB()
    local Count = FA.Count
    local y = StatRows(child, width, 0, "SoLAchievements", {
        { "Critters loved", tostring(Count(d.critters)) },
        { "Pests slain", tostring(Count(d.pests)) },
        { "Books read", tostring(Count(d.books)) },
        { "Different dishes eaten", tostring(Count(d.foods)) },
        { "Different drinks", tostring(Count(d.drinks)) },
        { "Rare enemies slain", tostring(Count(d.rares)) },
        { "Bosses seen slain", tostring(Count(d.bosses)) },
        { "Fishing catches seen", tostring(d.fished or 0) },
    })
    for _, sec in ipairs(ns.STATS) do
        local rows = {}
        for _, s in ipairs(sec.list) do rows[#rows + 1] = { s[2], FA.StatText(s[1]) } end
        y = StatRows(child, width, y, sec.title, rows)
    end
    return -y
end

-------------------------------------------------------------------------------
--  Settings
-------------------------------------------------------------------------------
local function Toggle(child, y, text, key, default, tooltip, after)
    local S = FA.Settings()
    local _, h = W:Toggle(child, text, y,
        function()
            if S[key] == nil then return default end
            return S[key]
        end,
        function(v)
            S[key] = v
            if after then after(v) end
            for _, fn in ipairs(FA.CHECK_HOOKS) do pcall(fn) end
        end, tooltip)
    return y - h
end

local function Slider(child, y, text, min, max, step, get, set, tooltip)
    local _, h = W:Slider(child, text, y, min, max, step, get, set, tooltip)
    return y - h
end

local function Choice(child, y, text, key, default, values, order, tooltip, after)
    local S = FA.Settings()
    local _, h = W:Dropdown(child, text, y, values,
        function() return S[key] or default end,
        function(v)
            S[key] = v
            if after then after(v) end
        end, order, tooltip)
    return y - h
end

-- A change made with a slider, done once the mouse button is let go (done
-- while dragging, the page under the cursor is rebuilt and the slider jumps).
local releasing = {}
function FA.WhenReleased(key, fn)
    releasing[key] = fn
    if releasing.__waiting then return end
    releasing.__waiting = true
    local function Try()
        if IsMouseButtonDown and IsMouseButtonDown("LeftButton") then C_Timer.After(0.05, Try) return end
        releasing.__waiting = nil
        for k, f in pairs(releasing) do
            releasing[k] = nil
            pcall(f)
        end
    end
    Try()
end

-- The window's size, about its centre (it stays where it is on the screen).
-- The new place is worked out here, not read back from the frame (right
-- after a new scale the frame still reports its old place), kept on the
-- screen and saved; the pixel snap waits a frame.
local function Rescale()
    local win = _G.SoLAchievementsWindow
    if win and win.dockHost then return end
    if not (win and win.ApplyScale) then FA.SetScale(FA.Settings().scale or 1) return end
    local L, T = win:GetLeft(), win:GetTop()
    local w, h = win:GetWidth(), win:GetHeight()
    local before = win:GetEffectiveScale()
    win:ApplyScale()
    local after = win:GetEffectiveScale()
    if not (L and T and w and h and before and after and after > 0) then return end
    -- The middle stays where it was on the screen.
    local sx, sy = (L + w / 2) * before, (T - h / 2) * before
    local x, y = sx / after - w / 2, sy / after + h / 2
    -- On the screen, in the window's own units.
    local ue = UIParent:GetEffectiveScale()
    local sw, sh = UIParent:GetWidth() * ue / after, UIParent:GetHeight() * ue / after
    x = math.max(0, math.min(x, sw - w))
    y = math.max(math.min(h, sh), math.min(y, sh))
    win:ClearAllPoints()
    win:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x, y)
    FA.Settings().winPos = { x = x, y = y }
    C_Timer.After(0, function()
        FA.Kit.SnapFrame(win)
        local l, t = win:GetLeft(), win:GetTop()
        if l and t then FA.Settings().winPos = { x = l, y = t } end
        FA.Kit.RealignBorders()
        if ns.RefitIcons then ns.RefitIcons() end
    end)
end
FA.RescaleWindow = Rescale

-- New text sizes: the pages drawn again to fit them.
local function Relayout()
    FA.ApplyFontSizes()
    if FA.Refresh then FA.Refresh() end
    if FA.UpdateTracker then FA.UpdateTracker() end
end
FA.RelayoutFonts = Relayout

FA.VIEWS.settings = function(child, width)
    local S = FA.Settings()
    local y = 0
    local h
    -- Give dropdowns and sliders the full width. Pair only simple toggles.
    local function Row(a, b)
        local function Place(left, right)
            local _, height = W:DualRow(child, y, left, right)
            y = y - height
        end
        if a and b and a.type == "toggle" and b.type == "toggle" then
            a.group, b.group = false, false
            Place(a, b)
        else
            if a then a.group = false; Place(a) end
            if b then b.group = false; Place(b) end
        end
    end
    local function Head(text) _, h = W:SectionHeader(child, text, y); y = y - h end
    local function Get(key, default) return function() if S[key] == nil then return default end return S[key] end end
    local function T(text, key, default, tip, after)
        return { type = "toggle", text = text, tooltip = tip, getValue = Get(key, default),
                 setValue = function(v)
                     S[key] = v
                     if after then after(v) end
                     for _, fn in ipairs(FA.CHECK_HOOKS) do pcall(fn) end
                 end }
    end
    local function Sl(text, lo, hi, step, get, set, tip)
        return { type = "slider", text = text, min = lo, max = hi, step = step, tooltip = tip, getValue = get, setValue = set }
    end
    local function D(text, key, default, values, order, tip, after)
        return { type = "dropdown", text = text, values = values, order = order, tooltip = tip, getValue = Get(key, default),
                 setValue = function(v) S[key] = v; if after then after(v) end end }
    end
    local function TrackerRedraw() if FA.UpdateTracker then FA.UpdateTracker() end end

    Head("APPEARANCE")
    local themes, order = {}, {}
    for _, t in ipairs(FA.THEMES) do themes[t.key] = t.label; order[#order + 1] = t.key end
    Row(D("Theme", "theme", "wrath", themes, order, "Accent colours for the summary, tracker, and controls.", function(v) FA.ApplyTheme(v) end),
        D("Order inside a section", "sort", "default", { default = "As in WotLK", name = "By name", progress = "Closest to done first" },
          { "default", "name", "progress" }))
    Row(Sl("Window size (%)", 70, 130, 5, function() return (S.scale or 1) * 100 end,
           function(v) S.scale = v / 100; FA.WhenReleased("scale", Rescale) end, "Sets the size of the standalone window. The Collections tab fits its panel."),
        T("Compact achievement rows", "compact", false, "Fit more achievements in the list.", FA.Refresh))
    Row(T("Animations", "animations", true, "Toasts sliding in, cards opening, bars filling.", function(on) Kit.animate = on end),
        T("Account-wide view", "accountView", false, "Show achievements earned by any of your characters.", FA.Refresh))

    Head("TOASTS")
    local sounds = { UI_ACHIEVEMENT_AWARDED = "Achievement", LEVELUP = "Level up", IG_QUEST_LIST_COMPLETE = "Quest complete",
          READY_CHECK = "Ready check", RAID_WARNING = "Raid warning", AUCTION_WINDOW_OPEN = "Auction house" }
    local soundOrder = { "UI_ACHIEVEMENT_AWARDED", "LEVELUP", "IG_QUEST_LIST_COMPLETE", "READY_CHECK", "RAID_WARNING", "AUCTION_WINDOW_OPEN" }
    local soundDefault = "UI_ACHIEVEMENT_AWARDED"
    Row(Sl("Toast time on screen (s)", 2, 10, 1, function() return S.toastTime or 4 end, function(v) S.toastTime = v end),
        Sl("Toast height from bottom", 60, 500, 10, function() return S.toastBottom or 158 end, function(v) S.toastBottom = v end))
    Row(D("Sound", "soundName", soundDefault, sounds, soundOrder),
        T("Screenshot when earning", "screenshot", false, "Like the old achievement screenshot addons."))
    _, h = W:WideDualButton(child, "Show a test toast", "Play the sound", y,
        function() FA.PreviewToast() end,
        function()
            local kit = FA.ToastSoundKit and FA.ToastSoundKit()
            if kit then PlaySound(kit, "Master") end
        end)
    y = y - h

    Head("ON SCREEN")
    Row(T("Achievement toasts", "toasts", true, "The banner near the bottom of the screen when you earn one."),
        T("Play a sound when earning", "sound", true))
    Row(D("Progress toasts", "progressToasts", "off",
          { off = "Off", pinned = "Pinned (on the tracker)", watch = "Watch list and pinned", milestones = "Milestones (25, 50, 75, 90 %)" },
          { "off", "pinned", "watch", "milestones" }, "A small toast when an achievement moves on: which ones."),
        T("Hints in tooltips", "tooltips", true, "Critters to /love, pests and bosses to slay, food not yet tasted, books not yet read."))
    Row(T("Minimap button", "minimapShown", true, nil, function(v) if FA.SetMinimapShown then FA.SetMinimapShown(v) end end),
        T("Event reminders", "eventReminder", false, "During a world event (Hallow's End, Winter Veil...), once a day: how many of its achievements are left."))

    Head("TRACKER")
    Row(T("Show the tracker", "trackerShown", true, "Right-click an achievement: Pin to the tracker.", TrackerRedraw),
        T("Lock the tracker", "trackerLocked", false, "Unlocked, drag the tracker by its title."))
    Row(Sl("Tracker size (%)", 70, 150, 5, function() return (S.trackerScale or 1) * 100 end, function(v) S.trackerScale = v / 100; FA.StyleTracker() end),
        Sl("Tracker background (%)", 0, 100, 5, function() return (S.trackerAlpha or 0.72) * 100 end, function(v) S.trackerAlpha = v / 100; FA.StyleTracker() end))
    Row(Sl("Most shown", 1, 15, 1, function() return tonumber(S.trackerMax) or 8 end, function(v) S.trackerMax = v; TrackerRedraw() end,
           "More than this: +N in the tracker's title."),
        D("Order", "trackerSort", "name", { name = "By name", progress = "Closest to done first" }, { "name", "progress" }, nil, TrackerRedraw))
    Row(T("Progress bars", "trackerBars", true, nil, TrackerRedraw),
        T("Numbers", "trackerNumbers", true, "8/12 on each line.", TrackerRedraw))
    Row(T("Missing criteria", "trackerMissing", false, "A second line with what is still missing (the first three).", TrackerRedraw),
        Sl("Opacity in combat (%)", 10, 100, 5, function() return (tonumber(S.trackerCombatAlpha) or 1) * 100 end,
           function(v) S.trackerCombatAlpha = v / 100 end, "100: the tracker stays as it is in a fight."))
    Row(T("Instance achievements on it", "instanceTrack", true,
          "Inside a dungeon or raid its achievements show on the tracker (marked here), until you leave. Your pinned list is not changed."),
        T("Instance hint", "instanceHint", false, "On entering a dungeon or raid: a chat line with its achievements still to earn."))
    Row(T("Event achievements on it", "eventTrack", true,
          "While a world event is on: its three achievements closest to done show on the tracker (marked here). Your pinned list is not changed.", TrackerRedraw),
        T("This zone's exploration on it", "zoneTrack", false,
          "The exploration achievement of the zone you are in, while it is not done (marked here). Your pinned list is not changed.", TrackerRedraw))

    Head("SHARING")
    Row(T("Share achievements and title", "share", true,
        "Share achievements with your guild and group. Nearby addon users can look up your equipped title."),
        T("Show what others earn", "showOthers", true, "A chat line when a guild or group member earns one."))
    Row(T("Titles on friendly nameplates", "nameplateTitles", true,
        "Show shared titles on other players’ friendly nameplates in the open world.",
        function()
            if FA.ApplyFriendlyNameplateStyle then FA.ApplyFriendlyNameplateStyle() end
            if FA.RefreshNameplateTitles then FA.RefreshNameplateTitles() end
        end),
        T("Title in character pane", "characterPaneTitle", true, "Show your equipped title next to your name in the character pane.", FA.RefreshCharacterTitle))
    Row(T("Names only on friendly plates", "friendlyTitleNamesOnly", true,
        "Use WoW’s names-only style for friendly player nameplates while shared titles are enabled.", FA.ApplyFriendlyNameplateStyle))
    Row(T("Announce in guild chat", "announce", false, "A guild chat message with the achievement for everyone."),
        T("Tell me about a newer version", "versionNotice", true, "When a guild or group member runs a newer version of the addon, one chat line says so."))

    Head("PROGRESS")
    Row(T("Show keys and IDs in tooltips", "showIDs", false, "For reporting a problem with an achievement."))
    _, h = W:WideDualButton(child, "Reset window position", "Reset tracker position", y,
        function() if FA.SLASH.resetpos then FA.SLASH.resetpos() end end,
        function() if FA.ResetTracker then FA.ResetTracker() end end)
    y = y - h

    -- Every kind of text on its own size (the window, settings,
    -- achievement cards and the tracker), two to a row.
    Head("TEXT SIZE")
    S.fontSizes = S.fontSizes or {}
    local roles = FA.FONT_ROLES or {}
    for i = 1, #roles, 2 do
        local cells = {}
        for k = i, math.min(i + 1, #roles) do
            local r = roles[k]
            cells[#cells + 1] = Sl(r.label, r.size - 4, r.size + 8, 1,
                function() return S.fontSizes[r.key] or r.size end,
                function(v)
                    S.fontSizes[r.key] = (v ~= r.size) and v or nil
                    FA.ApplyFontSizes()
                    FA.WhenReleased("fonts", Relayout)
                end, ("Default %d."):format(r.size))
        end
        Row(cells[1], cells[2])
    end
    local reset = Kit.PrimaryButton(child, "Reset text sizes", 170, function() S.fontSizes = {}; Relayout() end)
    reset:SetPoint("TOPLEFT", child, "TOPLEFT", 20, y)
    h = reset:GetHeight() + 8
    y = y - h
    return -y + 10
end
