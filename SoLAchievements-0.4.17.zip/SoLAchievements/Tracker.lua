-------------------------------------------------------------------------------
--  Tracker: the pinned achievements (right-click a card: Pin), with their
--  progress, in a small frame you can move (Settings locks it). Also:
--    context  the achievements of the instance you are in, for as long as
--             you are in it (marked "here"); your pinned list stays as it is
--    done     a pinned one just earned stays a few seconds with a check
--  Settings: max shown, bars, numbers, the missing criteria, the sort,
--  the opacity in combat, the scale, the opacity.
-------------------------------------------------------------------------------
local _, ns = ...
local FA = ns.FA
local Kit = FA.Kit
local C = Kit.COLORS

local WIDTH, ROW, ROW_MISSING = 250, 30, 44
local DONE_SHOW = 4
local tracker = CreateFrame("Frame", "SoLAchievementsTracker", UIParent)
tracker:SetSize(WIDTH, 30)
tracker:SetFrameStrata("LOW")
tracker:SetClampedToScreen(true)
tracker:SetMovable(true)
tracker:Hide()

local bg = tracker:CreateTexture(nil, "BACKGROUND")
bg:SetAllPoints()
bg:SetColorTexture(C.bg[1], C.bg[2], C.bg[3], 0.72)
Kit.MakeBorder(tracker, 1, 1, 1, 0.08)

local header = CreateFrame("Button", nil, tracker)
header:SetPoint("TOPLEFT")
header:SetPoint("TOPRIGHT")
header:SetHeight(24)
header:RegisterForDrag("LeftButton")
local title = Kit.RoleFont(header, "tracker", 12, nil, Kit.Accent())
title:SetPoint("LEFT", 10, 0)
title:SetText("Achievements")
local more = Kit.RoleFont(header, "tracker", 10, nil, C.dim[1], C.dim[2], C.dim[3], 1)
more:SetPoint("RIGHT", -10, 0)
header:SetScript("OnDragStart", function()
    if not FA.Settings().trackerLocked then tracker:StartMoving() end
end)
header:SetScript("OnDragStop", function()
    tracker:StopMovingOrSizing()
    Kit.RealignBorders()
    local point, _, rel, x, y = tracker:GetPoint()
    FA.Settings().trackerPos = { point, rel, x, y }
end)
header:SetScript("OnClick", function() FA.Open() end)

local function Place()
    tracker:ClearAllPoints()
    local pos = FA.Settings().trackerPos
    if pos then
        tracker:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    else
        tracker:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -250, -260)
    end
end

function FA.ResetTracker()
    FA.Settings().trackerPos = nil
    Place()
end

-- The context: the instance's achievements (set by Instance.lua), and the
-- pinned ones just earned (key -> time).
ns.contextKeys = ns.contextKeys or {}
ns.justDone = ns.justDone or {}
table.insert(FA.EARN_HOOKS, function(a)
    ns.justDone[a.key] = GetTime()
    C_Timer.After(DONE_SHOW + 0.1, function() if FA.UpdateTracker then FA.UpdateTracker() end end)
end)

local rows = {}
local function Row(i)
    if rows[i] then return rows[i] end
    local r, g, b = Kit.Accent()
    local row = CreateFrame("Button", nil, tracker)
    row:SetSize(WIDTH - 16, ROW)
    row:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    row.name = Kit.RoleFont(row, "tracker", 11, nil, C.text[1], C.text[2], C.text[3], 1)
    row.name:SetPoint("TOPLEFT", 2, -2)
    row.name:SetPoint("RIGHT", -60, 0)
    row.name:SetJustifyH("LEFT")
    row.name:SetWordWrap(false)
    row.value = Kit.RoleFont(row, "tracker", 11, nil, C.dim[1], C.dim[2], C.dim[3], 1)
    row.value:SetPoint("TOPRIGHT", -2, -2)
    row.missing = Kit.RoleFont(row, "tracker", 10, nil, C.dim[1], C.dim[2], C.dim[3], 1)
    row.missing:SetPoint("TOPLEFT", row.name, "BOTTOMLEFT", 0, -2)
    row.missing:SetPoint("RIGHT", -2, 0)
    row.missing:SetJustifyH("LEFT")
    row.missing:SetWordWrap(false)
    row.track = row:CreateTexture(nil, "ARTWORK")
    row.track:SetColorTexture(1, 1, 1, 0.1)
    row.track:SetHeight(2)
    row.track:SetPoint("BOTTOMLEFT", 2, 7)
    row.track:SetPoint("BOTTOMRIGHT", -2, 7)
    row.fill = row:CreateTexture(nil, "OVERLAY")
    row.fill:SetColorTexture(r, g, b, 1)
    row.fill:SetHeight(2)
    row.fill:SetPoint("LEFT", row.track, "LEFT")
    row:SetScript("OnClick", function(self, button)
        if not self.a then return end
        if button == "RightButton" then
            if ns.CardMenu then ns.CardMenu(self, self.a) else FA.ToggleTrack(self.a) end
        else
            FA.OpenSearch(self.a.name)
        end
    end)
    rows[i] = row
    return row
end

-- The criteria not done yet ("Mouse, Rat +2"), when the achievement lists them.
local function Missing(a)
    if not (a.list and a.has) then return nil end
    local out = {}
    for _, n in ipairs(a.list) do
        local ok, have = pcall(a.has, n)
        if ok and not have then out[#out + 1] = n end
    end
    if #out == 0 then return nil end
    local shown = {}
    for i = 1, math.min(3, #out) do shown[i] = out[i] end
    return table.concat(shown, ", ") .. (#out > 3 and (" +" .. (#out - 3)) or "")
end

local function Update()
    local d, S = FA.DB(), FA.Settings()
    local list, seen = {}, {}
    local now = GetTime()
    for key in pairs(d.tracked or {}) do
        local a = FA.BY_KEY[key]
        if a and not d.done[key] then list[#list + 1] = { a = a }; seen[key] = true
        else d.tracked[key] = nil end
    end
    -- Just earned (pinned before): a few seconds with a check.
    for key, t in pairs(ns.justDone) do
        local a = FA.BY_KEY[key]
        if a and now - t < DONE_SHOW and not seen[key] then list[#list + 1] = { a = a, done = true }; seen[key] = true
        elseif now - t >= DONE_SHOW then ns.justDone[key] = nil end
    end
    -- The context (this instance), not done, not pinned already.
    for key in pairs(ns.contextKeys) do
        local a = FA.BY_KEY[key]
        if a and not seen[key] and not FA.Earned(key) then list[#list + 1] = { a = a, here = true }; seen[key] = true end
    end
    -- More context (never written to the pinned list): an event on now, its
    -- three closest to done; this zone's exploration while it is not done.
    local function Open(a)
        return a and not seen[a.key] and not FA.Earned(a.key) and FA.Available(a) and not (ns.IsExcluded and ns.IsExcluded(a.key))
    end
    if S.eventTrack ~= false and ns.EVENT_SECTIONS and ns.EventActive then
        local picks, pct = {}, {}
        for _, sec in ipairs(ns.EVENT_SECTIONS) do
            if sec.event and ns.EventActive(sec.event) then
                for _, a in ipairs(sec.list or {}) do
                    if Open(a) and not pct[a] then picks[#picks + 1] = a; pct[a] = ns.Evaluate(a).percent end
                end
            end
        end
        table.sort(picks, function(p, q) return pct[p] > pct[q] end)
        for i = 1, math.min(3, #picks) do
            list[#list + 1] = { a = picks[i], here = true }
            seen[picks[i].key] = true
        end
    end
    if S.zoneTrack then
        local zone = GetRealZoneText and GetRealZoneText() or ""
        local ex = not FA.secret(zone) and FA.ZONE_ACH and FA.ZONE_ACH[zone]
        if Open(ex) then list[#list + 1] = { a = ex, here = true }; seen[ex.key] = true end
    end
    for _, e in ipairs(list) do e.ev = ns.Evaluate(e.a) end
    local sort = S.trackerSort or "name"
    table.sort(list, function(p, q)
        if (p.done and 1 or 0) ~= (q.done and 1 or 0) then return p.done and true or false end
        if sort == "progress" and p.ev.percent ~= q.ev.percent then return p.ev.percent > q.ev.percent end
        return p.a.name < q.a.name
    end)
    if #list == 0 or S.trackerShown == false then
        tracker:Hide()
        return
    end
    local max = math.max(1, tonumber(S.trackerMax) or 8)
    local bars, numbers, showMissing = S.trackerBars ~= false, S.trackerNumbers ~= false, S.trackerMissing == true
    local r, g, b = Kit.Accent()
    local y = -24
    local shown = math.min(#list, max)
    for i = 1, shown do
        local e = list[i]
        local a, ev = e.a, e.ev
        local row = Row(i)
        row.a = a
        local miss = (showMissing and not e.done) and Missing(a) or nil
        local h = miss and ROW_MISSING or ROW
        row:SetHeight(h)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", 8, y)
        y = y - h
        row.name:SetText((e.done and "|TInterface\\RaidFrame\\ReadyCheck-Ready:12:12|t " or "") .. a.name .. (e.here and "  |cff888888here|r" or ""))
        row.missing:SetText(miss or "")
        row.missing:SetShown(miss ~= nil)
        if e.done then
            row.value:SetText("Done")
            row.value:SetTextColor(r, g, b, 1)
        else
            row.value:SetTextColor(C.dim[1], C.dim[2], C.dim[3], 1)
            -- (an attempt running: its own count and clock, e.g. Leeeeeeeeeeeeeroy!)
            local live = numbers and a.liveText and a.liveText()
            if not numbers then row.value:SetText("")
            elseif live then row.value:SetText(live)
            elseif a.money then row.value:SetText(math.floor(ev.current / 10000) .. "/" .. math.floor(ev.required / 10000) .. "g")
            else row.value:SetText(ev.current .. "/" .. ev.required) end
        end
        row.track:SetShown(bars)
        row.fill:SetShown(bars)
        row.fill:SetWidth(math.max(1, (WIDTH - 20) * (e.done and 1 or ev.percent)))
        row:Show()
    end
    for i = shown + 1, #rows do rows[i]:Hide() end
    more:SetText(#list > shown and ("+" .. (#list - shown)) or "")
    tracker:SetHeight(-y + 4)
    tracker:Show()
end
FA.UpdateTracker = Update

-- Theme colours, size and opacity from the settings.
function FA.StyleTracker()
    local S = FA.Settings()
    local r, g, b = Kit.Accent()
    bg:SetColorTexture(C.bg[1], C.bg[2], C.bg[3], S.trackerAlpha or 0.72)
    title:SetTextColor(r, g, b, 1)
    for _, row in ipairs(rows) do
        row.fill:SetColorTexture(r, g, b, 1)
        row.name:SetTextColor(C.text[1], C.text[2], C.text[3], 1)
        row.value:SetTextColor(C.dim[1], C.dim[2], C.dim[3], 1)
    end
    tracker:SetScale(S.trackerScale or 1)
end

table.insert(FA.CHECK_HOOKS, Update)
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_REGEN_DISABLED")
ev:RegisterEvent("PLAYER_REGEN_ENABLED")
ev:RegisterEvent("ZONE_CHANGED_NEW_AREA")
ev:SetScript("OnEvent", function(_, event)
    -- (another zone: its context on the tracker)
    if event == "ZONE_CHANGED_NEW_AREA" then C_Timer.After(1, Update) return end
    if event == "PLAYER_LOGIN" then
        Place()
        C_Timer.After(4, Update)
        return
    end
    -- Fainter in combat (Settings: opacity in combat; 1 keeps it as it is).
    local a = tonumber(FA.Settings().trackerCombatAlpha) or 1
    tracker:SetAlpha(event == "PLAYER_REGEN_DISABLED" and a or 1)
end)
-- (the backup refresh runs only while the tracker shows)
do
    local ticker
    tracker:HookScript("OnShow", function()
        if not ticker then ticker = C_Timer.NewTicker(3, function() Update() end) end
    end)
    tracker:HookScript("OnHide", function() if ticker then ticker:Cancel(); ticker = nil end end)
    if tracker:IsShown() and not ticker then ticker = C_Timer.NewTicker(3, function() Update() end) end
end
