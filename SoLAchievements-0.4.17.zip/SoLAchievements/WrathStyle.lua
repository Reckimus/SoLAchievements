-- Artwork comes from the running client. This module only styles this addon.
local _, ns = ...
local Skin = {}
ns.WrathStyle = Skin
local ACH = "Interface\\AchievementFrame\\"
local DIALOG = "Interface\\DialogFrame\\"

local function Texture(parent, layer, sublevel)
    return parent:CreateTexture(nil, layer, nil, sublevel or 0)
end

local function Backdrop(parent, edge, size, background, tint)
    local border = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    border:SetAllPoints()
    border:SetBackdrop({
        bgFile = background,
        edgeFile = edge, edgeSize = size,
        tile = background ~= nil, tileSize = 32,
        insets = {left = 5, right = 5, top = 5, bottom = 5},
    })
    if tint then border:SetBackdropColor(unpack(tint)) end
    return border
end

local function Art(parent, layer, file, coords)
    local texture = Texture(parent, layer)
    if texture:SetTexture(ACH .. file) == false then
        texture:SetColorTexture(0.35, 0.24, 0.14, 1)
    elseif coords then
        texture:SetTexCoord(unpack(coords))
    end
    return texture
end

function Skin.Chrome(parent, closeWindow, kit)
    local win = CreateFrame("Frame", nil, parent)
    win:SetAllPoints()

    local edge = ACH .. "UI-Achievement-WoodBorder"
    if GetFileIDFromPath and not GetFileIDFromPath(edge .. ".blp") then
        edge = DIALOG .. "UI-DialogBox-Gold-Border"
    end
    local wood = Backdrop(win, edge, edge == ACH .. "UI-Achievement-WoodBorder" and 64 or 24)
    wood:SetFrameLevel(win:GetFrameLevel())

    local function Rail(point, file, coords)
        local rail = Art(win, "ARTWORK", file, coords)
        if point == "LEFT" or point == "RIGHT" then
            local x = point == "LEFT" and 12 or -12
            rail:SetPoint("TOP" .. point, x, -23)
            rail:SetPoint("BOTTOM" .. point, x, 23)
            rail:SetWidth(14)
        else
            local y = point == "TOP" and -11 or 11
            rail:SetPoint(point .. "LEFT", 24, y)
            rail:SetPoint(point .. "RIGHT", -24, y)
            rail:SetHeight(14)
        end
    end
    Rail("LEFT", "UI-Achievement-MetalBorder-Left", {0, 1, 0, 0.87})
    Rail("RIGHT", "UI-Achievement-MetalBorder-Left", {1, 0, 0, 0.87})
    Rail("TOP", "UI-Achievement-MetalBorder-Top", {0, 0.87, 0, 1})
    Rail("BOTTOM", "UI-Achievement-MetalBorder-Top", {0, 0.87, 1, 0})

    for _, corner in ipairs({
        {"TOPLEFT", 8, -7, {1, 0, 1, 0}},
        {"TOPRIGHT", -8, -7, {0, 1, 1, 0}},
        {"BOTTOMLEFT", 8, 7, {1, 0, 0, 1}},
        {"BOTTOMRIGHT", -8, 7, {0, 1, 0, 1}},
    }) do
        local joint = Art(win, "OVERLAY", "UI-Achievement-MetalBorder-Joint", corner[4])
        joint:SetPoint(corner[1], corner[2], corner[3])
        joint:SetSize(29, 29)
    end

    local left = Art(win, "ARTWORK", "UI-Achievement-Header", {0, 1, 0, 0.4140625})
    left:SetPoint("TOPLEFT", 23, 16)
    left:SetSize(512, 106)
    local right = Art(win, "ARTWORK", "UI-Achievement-Header", {0, 0.419921875, 0.4140625, 0.8046875})
    right:SetPoint("BOTTOMLEFT", left, "BOTTOMRIGHT", 0, -6)
    right:SetPoint("TOPRIGHT", win, "TOPRIGHT", -23, 4)

    local plaque = Art(win, "OVERLAY", "UI-Achievement-Header", {0.419921875, 0.6796875, 0.4140625, 0.56640625})
    plaque:SetPoint("TOP", 0, -32)
    plaque:SetSize(133, 39)
    local title = kit.RoleFont(win, "title", 15, nil, 1, 0.82, 0.35, 1)
    title:SetPoint("BOTTOM", plaque, "TOP", 0, -3)
    title:SetText("Achievement Points")
    title:SetShadowColor(0, 0, 0, 1)
    title:SetShadowOffset(1, -1)
    local close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -9, -8)
    close:SetFrameLevel(win:GetFrameLevel() + 3)
    close:SetScript("OnClick", closeWindow)
    return win, plaque
end

function Skin.Sidebar(side)
    local paper = Art(side, "BORDER", "UI-Achievement-Parchment", {0, 0.5, 0, 1})
    paper:SetAllPoints()
    local watermark = Texture(side, "ARTWORK")
    watermark:SetPoint("BOTTOMLEFT", 4, 8)
    watermark:SetPoint("BOTTOMRIGHT", -4, 8)
    watermark:SetHeight(165)
    watermark:SetTexture(ACH .. "UI-Achievement-AchievementWatermark")
    watermark:SetAlpha(0.65)
end

function Skin.FooterTab(win, title, offset, kit, action)
    local tab = CreateFrame("Button", nil, win)
    tab:SetSize(126, 26)
    tab:SetPoint("TOPLEFT", win, "BOTTOMLEFT", offset, 5)
    for _, part in ipairs({
        {0, 21, 0.47265625, 0.513671875},
        {21, 87, 0.513671875, 0.685546875},
        {108, 18, 0.685546875, 0.720703125},
    }) do
        local art = Art(tab, "BACKGROUND", "UI-Achievement-Header", {part[3], part[4], 0.76953125, 1})
        art:SetPoint("TOPLEFT", part[1], 11)
        art:SetSize(part[2], 42)
    end
    local label = kit.RoleFont(tab, "tab", 13, nil, 1, 0.82, 0.35, 1)
    label:SetPoint("CENTER", 0, 2)
    label:SetText(title)
    function tab:SetActive(active)
        label:SetTextColor(active and 1 or 0.84, active and 0.94 or 0.68, active and 0.70 or 0.39)
    end
    tab:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
    tab:SetScript("OnClick", action)
    return tab
end

function Skin.Category(item, bg, label, count, active)
    if not item.wrathSelected then
        local bar = Art(item, "BACKGROUND", "UI-Achievement-Category-Background", {0, 0.6640625, 0, 1})
        bar:SetPoint("TOPLEFT", 0, -2)
        bar:SetPoint("BOTTOMRIGHT", 0, 2)
        local highlight = Texture(item, "BORDER")
        highlight:SetPoint("TOPLEFT", bar, "TOPLEFT")
        highlight:SetPoint("BOTTOMRIGHT", bar, "BOTTOMRIGHT")
        if highlight:SetTexture(ACH .. "UI-Achievement-Category-Highlight") == false then
            highlight:SetColorTexture(0.72, 0.45, 0.16, 0.33)
        else
            highlight:SetTexCoord(0, 0.6640625, 0, 1)
            highlight:SetDesaturated(true)
            highlight:SetVertexColor(1, 0.74, 0.32, 0.88)
        end
        highlight:SetBlendMode("ADD")
        item.wrathSelected = highlight
        item:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
    end
    bg:SetColorTexture(0.23, 0.145, 0.082, active and 0.9 or 0)
    item.wrathSelected:SetShown(active)
    if active then
        label:SetTextColor(1, 0.87, 0.54, 1)
        count:SetTextColor(1, 0.82, 0.38, 1)
    else
        label:SetTextColor(0.87, 0.78, 0.64, 1)
        count:SetTextColor(0.75, 0.68, 0.56, 1)
    end
end

function Skin.Card(card)
    local paper = Texture(card, "BACKGROUND", 1)
    paper:SetPoint("TOPLEFT", 1, -1)
    paper:SetPoint("BOTTOMRIGHT", -1, 1)
    if paper:SetTexture(ACH .. "UI-Achievement-Parchment-Horizontal") == false then
        paper:SetTexture("Interface\\QuestFrame\\QuestBG")
        paper:SetTexCoord(0.08, 0.91, 0.23, 0.49)
    end
    card.wrathPaper = paper
    card.wrathShade = Texture(card, "BACKGROUND", 2)
    card.wrathShade:SetAllPoints(paper)

    local badge = card.badge
    local medallion = Art(badge, "ARTWORK", "UI-Achievement-Shields", {0, 0.5, 0, 0.5})
    medallion:SetPoint("CENTER")
    medallion:SetSize(52, 50)
    badge:SetSize(52, 42)
    local iconFrame = Texture(card.iconBox, "OVERLAY")
    iconFrame:SetPoint("CENTER", -1, 0)
    iconFrame:SetSize(55, 55)
    iconFrame:SetTexture(ACH .. "UI-Achievement-IconFrame")
    iconFrame:SetTexCoord(0, 0.5625, 0, 0.5625)
    local trim = Backdrop(card, "Interface\\Tooltips\\UI-Tooltip-Border", 12)
    trim:SetFrameLevel(card:GetFrameLevel())
    card.wrathTrim = trim
    card.wrathMedal = medallion
    card.pts:SetShadowColor(0, 0, 0, 1)
    card.pts:SetShadowOffset(1, -1)
    card.track:SetHeight(4)
end

function Skin.PaintCard(card, earned, hovered)
    local r, g, b = 0.80, 0.68, 0.48
    if earned then r, g, b = 1, 0.88, 0.61 end
    card.bg:SetColorTexture(r * 0.86, g * 0.86, b * 0.86, 1)
    card.wrathPaper:SetDesaturated(not earned)
    card.wrathPaper:SetVertexColor(r, g, b, earned and 0.86 or 0.50)
    card.wrathShade:SetColorTexture(1, 0.79, 0.42, hovered and 0.24 or 0)
    card.edge:SetColor(0.34, 0.22, 0.11, 0.9)
    if earned or hovered then
        card.wrathTrim:SetBackdropBorderColor(0.82, 0.64, 0.34, 1)
    else
        card.wrathTrim:SetBackdropBorderColor(0.52, 0.48, 0.40, 1)
    end
    card.wrathMedal:SetDesaturated(not earned)
    card.wrathMedal:SetAlpha(earned and 1 or 0.75)
    card.bbg:SetColorTexture(0.20, 0.12, 0.06, 0)
    card.name:SetTextColor(0.17, 0.085, 0.035, 1)
    card.desc:SetTextColor(0.24, 0.15, 0.08, 1)
    card.right:SetTextColor(0.25, 0.15, 0.07, 1)
    card.tr:SetTextColor(0.28, 0.15, 0.06, 1)
    card.cmp:SetTextColor(0.30, 0.19, 0.08, 1)
    card.pts:SetTextColor(1, 0.91, 0.66, 1)
    card.track:SetColorTexture(0.30, 0.20, 0.11, 0.42)
    card.sep:SetColorTexture(0.30, 0.20, 0.11, 0.42)
end

function Skin.Scrollbar(scroll)
    local slider = CreateFrame("Slider", nil, scroll)
    slider:SetPoint("TOPRIGHT", -10, -18)
    slider:SetPoint("BOTTOMRIGHT", -10, 18)
    slider:SetWidth(16)
    slider:SetOrientation("VERTICAL")
    slider:SetMinMaxValues(0, 0)
    slider:SetValueStep(1)
    slider:SetObeyStepOnDrag(true)
    local gutter = Texture(slider, "BACKGROUND")
    gutter:SetAllPoints()
    gutter:SetColorTexture(0.04, 0.025, 0.015, 0.95)
    local thumb = Texture(slider, "OVERLAY")
    thumb:SetSize(16, 24)
    thumb:SetTexture("Interface\\Buttons\\UI-ScrollBar-Knob")
    slider:SetThumbTexture(thumb)
    local function Arrow(direction, position, step)
        local button = CreateFrame("Button", nil, slider)
        button:SetSize(16, 18)
        button:SetPoint(position, slider, position == "BOTTOM" and "TOP" or "BOTTOM")
        button:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-Scroll" .. direction .. "Button-Up")
        button:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-Scroll" .. direction .. "Button-Down")
        button:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-Scroll" .. direction .. "Button-Highlight", "ADD")
        button:SetScript("OnClick", function() slider:SetValue(slider:GetValue() + step) end)
    end
    Arrow("Up", "BOTTOM", -54)
    Arrow("Down", "TOP", 54)
    slider:SetScript("OnValueChanged", function(_, value)
        if not slider.syncing then scroll:SetVerticalScroll(value) end
    end)
    function scroll:SyncWrathScroll()
        slider.syncing = true
        local range = math.max(0, self:GetVerticalScrollRange())
        slider:SetMinMaxValues(0, range)
        slider:SetValue(math.min(range, self:GetVerticalScroll()))
        slider:SetShown(range > 0)
        slider.syncing = false
    end
    scroll:HookScript("OnScrollRangeChanged", scroll.SyncWrathScroll)
    scroll:HookScript("OnShow", scroll.SyncWrathScroll)
end

function Skin.Toast(frame)
    local banner = Texture(frame, "BORDER")
    banner:SetPoint("TOPLEFT", 4, -4)
    banner:SetPoint("BOTTOMRIGHT", -4, 4)
    if banner:SetTexture(ACH .. "UI-Achievement-Alert-Background") == false then
        banner:SetColorTexture(0.16, 0.085, 0.035, 1)
    else
        banner:SetTexCoord(0, 0.60546875, 0, 0.703125)
    end
    local border = Backdrop(frame, DIALOG .. "UI-DialogBox-Gold-Border", 19)
    border:SetFrameLevel(frame:GetFrameLevel())
    local crest = Texture(frame, "ARTWORK")
    crest:SetPoint("RIGHT", -7, 0)
    crest:SetSize(28, 28)
    crest:SetTexture("Interface\\Icons\\Achievement_General")
    crest:SetVertexColor(0.44, 0.32, 0.17, 0.8)
    local glow = Texture(frame, "BORDER")
    glow:SetPoint("TOPLEFT", 7, -7)
    glow:SetPoint("TOPRIGHT", -7, -7)
    glow:SetHeight(22)
    glow:SetColorTexture(0.70, 0.40, 0.13, 0.21)
end
