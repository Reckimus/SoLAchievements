local _, ns = ...
local FA = ns.FA
local title = ACHIEVEMENTS or "Achievements"

local function Attach()
    local journal = CollectionsJournal
    local container = journal and journal.TabContainer
    if not (container and container.Tabs and EventRegistry and CollectionsJournal_UpdateSelectedTab
        and CollectionsJournal_GetTab and CollectionsJournal_SetTab_Internal and CollectionsJournal_CheckAndDisplayTabs
        and BLIZZARD_COLLECTIONS_TAB_STYLE_SIDE
        and BLIZZARD_COLLECTIONS_TAB_STYLE == BLIZZARD_COLLECTIONS_TAB_STYLE_SIDE) then return end

    local page = CreateFrame("Frame", nil, journal)
    page:SetAllPoints(journal)
    page:SetFrameLevel(journal:GetFrameLevel() + 10)
    page:Hide()

    local chrome = { "NineSlice", "PortraitContainer", "TitleContainer", "CloseButton",
        "Bg", "TopTileStreaks", "FrameGlow" }
    local hiddenChrome = {}
    local function HideChrome()
        for _, key in ipairs(chrome) do
            local region = journal[key]
            if region and region:IsShown() then
                hiddenChrome[#hiddenChrome + 1] = region
                region:Hide()
            end
        end
    end

    -- Use the same art and input handling as the native side tabs. Keep the
    -- addon tab out of Blizzard's saved tab index and availability checks.
    local tab = CreateFrame("Frame", nil, container, "LargeSideTabButtonTemplate")
    tab:EnableMouse(true)
    tab.tooltipText = title
    tab.Icon:SetTexture("Interface\\Icons\\Achievement_General")
    tab:SetFillToInterior(true)
    tab:SetChecked(false)

    local function PositionTab()
        local last
        for _, nativeTab in ipairs(container.Tabs) do
            if nativeTab:IsShown() then last = nativeTab end
        end
        tab:ClearAllPoints()
        if last then
            tab:SetPoint("TOPLEFT", last, "BOTTOMLEFT", 0, -2)
        else
            tab:SetPoint("TOPLEFT", container, "TOPLEFT", 0, -60)
        end
    end

    local function ClearSelection()
        if not page:IsShown() then return end
        page:Hide()
        for _, region in ipairs(hiddenChrome) do region:Show() end
        wipe(hiddenChrome)
        tab:SetChecked(false)
        CollectionsJournal_SetTab_Internal(container, CollectionsJournal_GetTab(journal))
    end
    function ns.CloseCollectionsAchievements(closeJournal)
        if not page:IsShown() then return end
        if closeJournal then
            HideUIPanel(journal)
            return
        end
        ClearSelection()
        if journal:IsShown() then CollectionsJournal_UpdateSelectedTab(journal) end
    end

    tab:SetCustomOnMouseUpHandler(function(_, button, upInside)
        if button ~= "LeftButton" or not upInside or page:IsShown() then return end
        for _, nativeTab in ipairs(container.Tabs) do nativeTab:SetChecked(false) end
        for _, name in ipairs({ "MountJournal", "PetJournal", "ToyBox", "HeirloomsJournal",
            "WardrobeCollectionFrame", "WarbandSceneJournal" }) do
            local panel = _G[name]
            if panel and panel:IsShown() then panel:Hide() end
        end
        journal:SetTitle(title)
        HideChrome()
        tab:SetChecked(true)
        page:Show()
        FA.Open(page)
    end)

    EventRegistry:RegisterCallback("CollectionsJournal.TabSet", function(_, changedContainer)
        if changedContainer == container then ClearSelection(); PositionTab() end
    end, page)
    journal:HookScript("OnHide", ClearSelection)
    hooksecurefunc("CollectionsJournal_CheckAndDisplayTabs", PositionTab)
    PositionTab()
    return true
end

if not Attach() then
    local loader = CreateFrame("Frame")
    loader:RegisterEvent("ADDON_LOADED")
    loader:SetScript("OnEvent", function(self, _, name)
        if name ~= "Blizzard_Collections" then return end
        self:UnregisterEvent("ADDON_LOADED")
        Attach()
    end)
end
