-------------------------------------------------------------------------------
--  SoLAchievements: the browser's extras.
--    Right-click a card: Pin to the tracker, Watch, Link in chat, Exclude
--      (or Restore), Explain tracking, Copy key.
--    Watch list (per character): achievements you care about, not on the
--      screen; Pinned stays the on-screen tracker.
--    Excluded (account): hidden everywhere until restored (the filter
--      Excluded lists them).
--    The filter: All, Completed, Incomplete, Near completion, Watch list,
--      Excluded.
--    Current Zone (sidebar): what this zone has for you.
-------------------------------------------------------------------------------
local _, ns = ...
local FA = ns.FA
local TAG = FA.TAG

local Row -- (set with Current Zone, below)
local function Watch() local d = FA.DB(); d.watch = d.watch or {}; return d.watch end
local function Excluded() local a = FA.Account(); a.excluded = a.excluded or {}; return a.excluded end
function ns.IsWatched(key) return Watch()[key] and true or false end
function ns.IsExcluded(key) return Excluded()[key] and true or false end

-------------------------------------------------------------------------------
--  Easy wins: the achievements closest to done, a little ahead when they are
--  for this zone or an event on now, or need only one or two more. Shared
--  by the Summary and Current Zone pages. Returns { { a, r }, ... }.
-------------------------------------------------------------------------------
function ns.EasyWins(n)
    local zone = GetRealZoneText and GetRealZoneText() or ""
    if FA.secret(zone) then zone = "" end
    local here = FA.ZONE_ACH and FA.ZONE_ACH[zone]
    local out, score = {}, {}
    for _, a in ipairs(FA.ALL) do
        if FA.Available(a) and not FA.Earned(a.key) and not ns.IsExcluded(a.key) then
            local r = ns.Evaluate(a)
            if not r.blocked and r.required > 1 and r.percent >= 0.6 then
                local s = r.percent
                if r.remaining <= 2 then s = s + 0.1 end
                if a == here then s = s + 0.15 end
                if a.event and ns.EventActive and ns.EventActive(a.event) then s = s + 0.15 end
                out[#out + 1] = { a, r }
                score[a] = s
            end
        end
    end
    table.sort(out, function(p, q) return score[p[1]] > score[q[1]] end)
    for i = #out, (n or 5) + 1, -1 do out[i] = nil end
    return out
end

-------------------------------------------------------------------------------
--  Explain tracking: where the progress comes from, as text
-------------------------------------------------------------------------------
local function Explain(a)
    local r = ns.Evaluate and ns.Evaluate(a) or {}
    local c = ns.Completion and ns.Completion(a.key)
    local lines = {
        a.name .. "  (key " .. a.key .. (a.id and (", WotLK ID " .. a.id) or "") .. ")",
        ("Progress: %s / %s%s"):format(tostring(r.current), tostring(r.required), r.blocked and "  (blocked: cannot be read now)" or ""),
        "Available here: " .. (r.available and "yes" or "no"),
        "Tracking: " .. (a.tracking or (a.kill and "observed kills (from the day the addon saw them)")
            or (a.list and "each criterion as it happens") or "read from the game when checked"),
        "Reliability: " .. (({ exact = "exact (the game's own numbers)", integration = "from another addon's data",
            observed = "observed only (what this addon saw)" })[r.reliability or ""] or "?"),
        "Historical recovery: " .. (({ full = "full (rebuilt from the game at any time)",
            partial = "partial (only what is still in your bags or seen since)",
            none = "unavailable (what happened before the addon saw it is lost)" })[r.recoverability or ""] or "?"),
    }
    -- The last step the journal noted.
    for _, e in ipairs(ns.RecentProgress and ns.RecentProgress(50) or {}) do
        if e.a == a then
            lines[#lines + 1] = ("Last progress: %s -> %s (%s)"):format(tostring(e.from), tostring(e.to), date("%d.%m %H:%M", e.t or 0))
            break
        end
    end
    if c then
        lines[#lines + 1] = ("Earned: %s, %s%s"):format(c.exact and date("%d.%m.%Y %H:%M", c.time) or "date not known",
            c.source or "observed", (c.character and c.character ~= UnitName("player")) and (" by " .. c.character) or "")
    end
    if r.error then lines[#lines + 1] = "Error: " .. r.error end
    return lines
end

-------------------------------------------------------------------------------
--  Manual corrections: criteria the addon could not have seen (a critter
--  loved, a pest killed, a book read before it was installed) marked by
--  hand, kept apart as manual (and undone the same way).
-------------------------------------------------------------------------------
local MANUAL = {
    critters = function(n, on) FA.DB().critters[n] = on or nil end,
    pests = function(n, on) FA.DB().pests[n] = on or nil end,
    books = function(n, on) FA.DB().books[n] = on or nil end,
}
local function Manual() local d = FA.DB(); d.manual = d.manual or {}; return d.manual end
function ns.ManualMark(a, n, on)
    local set = MANUAL[a.key]
    if not set then return end
    set(n, on)
    local m = Manual()
    m[a.key] = m[a.key] or {}
    m[a.key][n] = on or nil
    local before = FA.DB().done[a.key]
    if FA.CheckAll then FA.CheckAll() end
    -- Earned because of a hand mark: said so.
    if not before and FA.DB().done[a.key] then ns.NoteEarned(a.key, "manual", true) end
end
function ns.IsManual(a, n) return (Manual()[a.key] or {})[n] and true or false end

-- An achievement's reward: { type = "title" | "mount" | "item" | "other", ... } or nil.
function ns.Reward(a)
    if a.reward then return a.reward end
    if a.title then return { type = "title", title = a.title } end
    return nil
end

-------------------------------------------------------------------------------
--  Timeline: earned achievements by day (exact dates only); the ones whose
--  date is not known in a bucket of their own.
-------------------------------------------------------------------------------
FA.VIEWS.timeline = function(child, width)
    local W = FA.Kit.W
    local y = 0
    local exact, unknown = {}, 0
    for key, t in pairs(FA.DB().done) do
        local a = FA.BY_KEY[key]
        if a then
            local c = ns.Completion(key)
            if c and c.exact then exact[#exact + 1] = { a = a, t = t } else unknown = unknown + 1 end
        end
    end
    table.sort(exact, function(p, q) return p.t > q.t end)
    local day
    for i, e in ipairs(exact) do
        if i > 60 then break end
        local d = date("%d %b %Y", e.t)
        if d ~= day then
            day = d
            local _, h = W:SectionHeader(child, d, y)
            y = y - h
        end
        y = Row(child, y, width, e.a, e.a.name, date("%H:%M", e.t), e.a.pts > 0 and ("+" .. e.a.pts) or nil)
    end
    if unknown > 0 then
        local _, h = W:SectionHeader(child, "PREVIOUSLY EARNED", y)
        y = y - h
        y = Row(child, y, width, nil, ("%d achievements"):format(unknown), "Found in your history: the day each was earned is not known.")
    end
    if #exact == 0 and unknown == 0 then
        local e = FA.Kit.MakeFont(child, 13, nil, 0.7, 0.7, 0.7, 1)
        e:SetPoint("TOPLEFT", 30, -10)
        e:SetText("Nothing earned yet.")
        y = -40
    end
    return -y + 10
end

-------------------------------------------------------------------------------
--  The tooltip's extra lines
-------------------------------------------------------------------------------
-- The achievements whose explicit parts list this key (built once).
local requiredBy
function ns.RequiredBy(key)
    if not requiredBy then
        requiredBy = {}
        for _, m in ipairs(FA.ALL) do
            if type(m.parts) == "table" then
                for _, k in ipairs(m.parts) do
                    requiredBy[k] = requiredBy[k] or {}
                    table.insert(requiredBy[k], m)
                end
            end
        end
    end
    return requiredBy[key]
end

function ns.TooltipExtra(tt, a)
    local c = ns.Completion and ns.Completion(a.key)
    if c then
        local when = c.exact and date("%d.%m.%Y", c.time) or "date not known"
        local who = (c.character and c.character ~= UnitName("player")) and (" by " .. c.character) or ""
        tt:AddLine("Earned " .. when .. who .. (c.source == "manual" and " (marked by hand)" or ""), 0.55, 0.85, 0.55)
    else
        local r = ns.Evaluate(a)
        if r.blocked then tt:AddLine("Progress cannot be read right now.", 1, 0.6, 0.3, true)
        elseif r.required > 1 then tt:AddLine(("Progress %s / %s (%d%%)"):format(r.current, r.required, math.floor(r.percent * 100)), 0.8, 0.8, 0.8) end
    end
    if a.series and FA.SERIES[a.series] then
        local parts = {}
        for _, t in ipairs(FA.SERIES[a.series]) do
            parts[#parts + 1] = (FA.Earned(t.key) and "|cff55dd77" or (t == a and "|cffffffff" or "|cff888888")) .. t.name .. "|r"
        end
        tt:AddLine("Series: " .. table.concat(parts, " > "), 0.8, 0.8, 0.8, true)
    end
    if a.event and ns.EVENT_BY_KEY and ns.EVENT_BY_KEY[a.event] then
        local st = ns.eventState and ns.eventState[a.event]
        tt:AddLine(("%s%s"):format(ns.EVENT_BY_KEY[a.event].name, (st and st.state == "active") and ": on now" or ""), 0.9, 0.7, 0.3)
        -- Related: the event's other achievements.
        local left, total = ns.EventCounts and ns.EventCounts(a.event)
        if total and total > 1 then tt:AddLine(("Related: %d of the event's %d still to earn"):format(left, total), 0.7, 0.7, 0.7) end
    end
    -- Meta and Required By: only from explicit keys (a.parts), never names.
    if type(a.parts) == "table" and #a.parts > 0 then
        local have = 0
        for _, k in ipairs(a.parts) do if FA.Earned(k) then have = have + 1 end end
        tt:AddLine(("Meta: %d of %d achievements"):format(have, #a.parts), 0.8, 0.8, 0.8)
    end
    if ns.RequiredBy then
        local by = ns.RequiredBy(a.key)
        if by and by[1] then
            local names = {}
            for _, m in ipairs(by) do names[#names + 1] = m.name end
            tt:AddLine("Required by: " .. table.concat(names, ", "), 0.8, 0.8, 0.8, true)
        end
    end
    local rw = ns.Reward(a)
    if rw and rw.type ~= "title" then tt:AddLine("Reward: " .. rw.type, 0.9, 0.8, 0.4) end
    if a.tracking then tt:AddLine("Tracking: " .. a.tracking, 0.6, 0.6, 0.6, true)
    elseif a.kill then tt:AddLine("Tracking: kills seen since the addon was installed.", 0.6, 0.6, 0.6, true) end
    if ns.IsWatched(a.key) then tt:AddLine("On your watch list", 0.6, 0.8, 1) end
end

-------------------------------------------------------------------------------
--  The card's menu
-------------------------------------------------------------------------------
function ns.CardMenu(owner, a)
    local K = FA.Kit
    if not (K and K.ContextMenu) then if FA.ToggleTrack then FA.ToggleTrack(a) end return end
    K.ContextMenu(owner, function(_, root)
        root:CreateTitle(a.name)
        local pinned = FA.DB().tracked[a.key]
        if not FA.Earned(a.key) then
            root:CreateButton(pinned and "Unpin from the tracker" or "Pin to the tracker", function() FA.ToggleTrack(a) end)
        end
        root:CreateButton(ns.IsWatched(a.key) and "Remove from the watch list" or "Add to the watch list", function()
            Watch()[a.key] = not ns.IsWatched(a.key) or nil
            if ns.FireAPI then ns.FireAPI("WATCH_CHANGED", a.key, ns.IsWatched(a.key)) end
            FA.Refresh()
        end)
        root:CreateButton("Link in chat", function()
            local box = ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()
            if not box and ChatFrame_OpenChat then ChatFrame_OpenChat("") ; box = ChatEdit_GetActiveWindow() end
            if box then box:Insert("[ach:" .. a.name .. "]") end
        end)
        root:CreateDivider()
        if ns.IsExcluded(a.key) then
            root:CreateButton("Restore (show it again)", function() Excluded()[a.key] = nil; FA.Refresh() end)
        else
            root:CreateButton("Exclude (hide it)", function()
                Excluded()[a.key] = true
                FA.DB().tracked[a.key] = nil
                print(TAG .. " " .. a.name .. " hidden. The filter Excluded lists it, to restore.")
                FA.Refresh()
            end)
        end
        -- Criteria the addon may have missed: marked by hand (and undone).
        if MANUAL[a.key] and a.list and a.has and not FA.Earned(a.key) then
            local fix = root:CreateButton("Correct criteria")
            for _, n in ipairs(a.list) do
                fix:CreateCheckbox(n .. (ns.IsManual(a, n) and " (by hand)" or ""),
                    function() local ok, v = pcall(a.has, n); return ok and v and true or false end,
                    function()
                        local ok, v = pcall(a.has, n)
                        ns.ManualMark(a, n, not (ok and v))
                    end)
            end
        end
        root:CreateDivider()
        root:CreateButton("Explain tracking", function()
            for _, l in ipairs(Explain(a)) do print(TAG .. " " .. l) end
        end)
        root:CreateButton("Copy key", function()
            if K.CopyWindow then K.CopyWindow("Achievement key", a.key) else print(TAG .. " " .. a.key) end
        end)
    end)
end

-------------------------------------------------------------------------------
--  The filter: is an achievement shown (beyond All / Completed / Incomplete)?
--  nil: not one of these filters.
-------------------------------------------------------------------------------
function ns.SmartFilter(filter, a, done)
    if filter == "excluded" then return ns.IsExcluded(a.key) end
    if ns.IsExcluded(a.key) then return false end
    if filter == "watch" then return ns.IsWatched(a.key) or (FA.DB().tracked[a.key] and true or false) end
    if filter == "rewards" then return ns.Reward(a) ~= nil end
    if filter == "near" then
        if done then return false end
        local r = ns.Evaluate(a)
        if r.blocked or r.required <= 1 then return false end
        return r.percent >= 0.5 or r.remaining <= 3
    end
    return nil
end

-------------------------------------------------------------------------------
--  Current Zone: exploration here, critters and pests here, events on now
-------------------------------------------------------------------------------
-- right: a short value at the row's end (the Timeline's +points).
Row = function(child, y, width, a, text, sub, right)
    local Kit = FA.Kit
    local C = Kit.COLORS
    local r, g, b = Kit.Accent()
    local row = CreateFrame("Button", nil, child)
    row:SetSize(width - 40, 40)
    row:SetPoint("TOPLEFT", 20, y)
    local bg = row:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(C.card[1], C.card[2], C.card[3], C.card[4])
    local box = ns.FramedIcon(row, 28, r, g, b, 0.8)
    box:SetPoint("LEFT", 8, 0)
    local icon = box.icon
    icon:SetTexture(a and (a.icon or ns.ICONS[a.id]) or 236376)
    local name = Kit.RoleFont(row, "achName", 13, nil, r, g, b, 1)
    name:SetPoint("TOPLEFT", icon, "TOPRIGHT", 10, 1)
    name:SetText(text)
    local s = Kit.RoleFont(row, "achDesc", 11, nil, C.dim[1], C.dim[2], C.dim[3], 1)
    s:SetPoint("BOTTOMLEFT", icon, "BOTTOMRIGHT", 10, -1)
    s:SetPoint("RIGHT", -12, 0)
    s:SetJustifyH("LEFT")
    s:SetWordWrap(false)
    s:SetText(sub or "")
    if right then
        local rt = Kit.RoleFont(row, "achName", 13, nil, r, g, b, 1)
        rt:SetPoint("RIGHT", -14, 0)
        rt:SetText(right)
        s:SetPoint("RIGHT", rt, "LEFT", -12, 0)
    end
    if a then
        row:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        row:SetScript("OnClick", function(self, button)
            if button == "RightButton" then ns.CardMenu(self, a) else FA.OpenSearch(a.name) end
        end)
    end
    return y - 46
end

-- A zone with exploration data (the names the view knows).
local function KnownZone(name)
    if not name or name == "" then return nil end
    if FA.ZONE_ACH and FA.ZONE_ACH[name] then return name end
    for _, z in ipairs(ns.EXPLORE or {}) do if z.zone == name then return name end end
    local low = name:lower()
    for key in pairs(FA.ZONE_ACH or {}) do if key:lower() == low then return key end end
    return nil
end
-- The world map's zone while it shows another zone than yours.
local function MapZone()
    local wm = _G.WorldMapFrame
    if not (wm and wm:IsShown() and wm.GetMapID and C_Map and C_Map.GetMapInfo) then return nil end
    local id = wm:GetMapID()
    if type(id) ~= "number" or FA.secret(id) then return nil end
    local info = C_Map.GetMapInfo(id)
    return info and type(info.name) == "string" and not FA.secret(info.name) and KnownZone(info.name) or nil
end
-- Another zone shown (the map's, or /fach zone Name); nil: where you are.
function ns.PickZone(name)
    ns.zonePick = KnownZone(name)
    FA.ShowTab("zone")
    FA.Refresh() -- (another zone: the page drawn anew, not the kept one)
    if ns.zonePick == nil and name and name ~= "" then print(FA.TAG .. " no zone called " .. name .. " (its exploration name).") end
end
FA.SLASH.zone = function(rest) ns.PickZone(rest ~= "" and rest or nil) end
-- The map opened or closed on the Current Zone page: its button follows.
if _G.WorldMapFrame then
    local function Follow()
        local w = _G.SoLAchievementsWindow
        if w and w:IsShown() and FA.DB().tab == "zone" then FA.Refresh() end
    end
    WorldMapFrame:HookScript("OnShow", Follow)
    WorldMapFrame:HookScript("OnHide", Follow)
end

-- Current Zone: the zone's achievements as cards (the same cards as every
-- category: progress, points, a list to open), only the ones still to
-- earn: the instance you are in, this zone's exploration, critters and
-- pests that live here, every achievement that names the zone or has it on
-- its list (Explore Eastern Kingdoms for Elwynn Forest), closest to done
-- first; then a world event on now. /fach zone Name shows another zone.
function ns.ZoneSections()
    local here = GetRealZoneText and GetRealZoneText() or ""
    if FA.secret(here) then here = "" end
    local picked = ns.zonePick and ns.zonePick ~= here and ns.zonePick or nil
    local zone = picked or here
    local list, seen = {}, {}
    local function Add(a)
        if a and not seen[a.key] and not FA.Earned(a.key) and FA.Available(a)
            and not (ns.IsExcluded and ns.IsExcluded(a.key)) then
            seen[a.key] = true
            list[#list + 1] = a
        end
    end
    -- The instance you are in (where you are only).
    local inst = not picked and ns.CurrentInstance and ns.CurrentInstance()
    if inst then for _, a in ipairs(ns.InstanceAchievements(inst)) do Add(a) end end
    -- This zone's exploration.
    local exploration = FA.ZONE_ACH and FA.ZONE_ACH[zone]
    Add(exploration)
    -- Critters and pests with one still to do here (where you are only).
    if not picked and FA.CritterHere then
        for _, key in ipairs({ "critters", "pests" }) do
            local a = FA.BY_KEY[key]
            if a and a.list and a.has then
                for _, n in ipairs(a.list) do
                    local okH, have = pcall(a.has, n)
                    local okW, lives = pcall(FA.CritterHere, n)
                    if okH and not have and okW and lives then Add(a) break end
                end
            end
        end
    end
    -- Everything else that belongs to the zone, closest to done first.
    if zone ~= "" then
        local more = {}
        for _, a in ipairs(FA.ALL) do
            local duplicateExploration = exploration and a.nativeID and a.name == exploration.name
            if not seen[a.key] and not duplicateExploration then
                local hit = type(a.name) == "string" and a.name:find(zone, 1, true)
                -- A continent's exploration description lists many zones;
                -- keep that meta in Exploration or Game Records.
                if not hit and not (a.nativeID and a.name:match("^Explore ")) then
                    hit = type(a.desc) == "string" and a.desc:find(zone, 1, true)
                end
                if not hit and a.list then
                    for _, n in ipairs(a.list) do if n == zone then hit = true break end end
                end
                if hit then more[#more + 1] = a end
            end
        end
        local pct = {}
        for _, a in ipairs(more) do pct[a] = ns.Evaluate(a).percent or 0 end
        table.sort(more, function(p, q)
            if pct[p] ~= pct[q] then return pct[p] > pct[q] end
            return p.name < q.name
        end)
        for _, a in ipairs(more) do Add(a) end
    end
    local sections = { { title = (zone ~= "" and zone:upper() or "THIS ZONE"), list = list } }
    -- A world event on now: its achievements still to earn.
    for _, sec in ipairs(ns.EVENT_SECTIONS or {}) do
        if sec.event and ns.EventActive and ns.EventActive(sec.event) then
            local evList = {}
            for _, a in ipairs(sec.list or {}) do
                if not FA.Earned(a.key) and FA.Available(a) then evList[#evList + 1] = a end
            end
            if #evList > 0 then sections[#sections + 1] = { title = sec.title, event = sec.event, list = evList } end
        end
    end
    return sections
end

-------------------------------------------------------------------------------
--  Statistics: three tabs on one page (General, the numbers; Timeline;
--  Guild), so the side menu keeps only the categories.
-------------------------------------------------------------------------------
do
    local STAT_TABS = {
        { key = "general", label = "General", view = FA.VIEWS.statistics },
        { key = "timeline", label = "Timeline", view = FA.VIEWS.timeline },
        { key = "guild", label = "Guild", view = FA.VIEWS.guild },
    }
    FA.VIEWS.statistics = function(child, width)
        local pick = FA.DB().statTab or "general"
        local current = STAT_TABS[1]
        for _, t in ipairs(STAT_TABS) do if t.key == pick then current = t end end
        -- Equal tabs across the page (the cards' width, one gap between).
        local GAP = 6
        local tabW = math.floor((width - 40 - GAP * (#STAT_TABS - 1)) / #STAT_TABS)
        local x = 20
        for _, t in ipairs(STAT_TABS) do
            local tab = FA.Kit.MakeTab(child, t.label)
            tab:SetPoint("TOPLEFT", x, -2)
            tab:SetHeight(26)
            -- (after the tab's own fit, which runs once more a frame later)
            tab:SetWidth(tabW)
            C_Timer.After(0, function() tab:SetWidth(tabW) end)
            tab:SetActive(t == current)
            tab:SetScript("OnClick", function()
                if FA.DB().statTab == t.key then return end
                FA.DB().statTab = t.key
                FA.Refresh()
            end)
            x = x + tabW + GAP
        end
        local page = CreateFrame("Frame", nil, child)
        page:SetPoint("TOPLEFT", 0, -40)
        page:SetSize(width, 1)
        local h = (current.view and current.view(page, width)) or 0
        return h + 40
    end
end
