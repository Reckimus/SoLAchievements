local _, ns = ...
local FA = ns.FA
local MAX_ROWS, VISIBLE_ROWS, HISTORY_AGE, REPLY_LIMIT = 60, 12, 14 * 86400, 5
local REFRESH_INTERVAL, RESPONSE_WINDOW = 30 * 60, 10
local requestedGuild, requestedToken, requestAt, replyAt
local lastSentAt
local memberGuild, memberStats

local function Guild()
    if not (IsInGuild and IsInGuild() and GetGuildInfo) then return end
    local name, _, _, realm = GetGuildInfo("player")
    if type(name) ~= "string" or FA.secret(name) or name == "" then return end
    if FA.secret(realm) or type(realm) ~= "string" or realm == "" then realm = GetRealmName() end
    return (realm or "") .. ":" .. name
end

local function Feed(guild)
    local db = FA.DB()
    if not db.guildActivity or db.guildActivity.guild ~= guild then
        db.guildActivity = { guild = guild, rows = {}, own = {} }
    end
    return db.guildActivity
end

local function SortAndTrim(rows, now, max)
    table.sort(rows, function(a, b)
        if a.when ~= b.when then return a.when > b.when end
        if a.name ~= b.name then return a.name < b.name end
        return a.key < b.key
    end)
    for i = #rows, 1, -1 do
        if i > max or rows[i].when < now - HISTORY_AGE then rows[i] = nil end
    end
end

local function Add(rows, sender, key, when, exact, max)
    local now = time()
    if type(sender) ~= "string" or #sender > 120 or sender:find("[%c|]")
        or not FA.BY_KEY[key] or not when or when < now - HISTORY_AGE or when > now + 300 then return false end
    for _, row in ipairs(rows) do
        if row.name == sender and row.key == key then
            if exact and not row.exact then
                row.when, row.exact = when, true
                SortAndTrim(rows, now, max)
                return true
            end
            return false
        end
    end
    rows[#rows + 1] = { name = sender, key = key, when = when, exact = exact }
    SortAndTrim(rows, now, max)
    return true
end

local function WatchRequest(guild, token, now)
    requestedGuild, requestedToken, requestAt = guild, token, now
end

function ns.GuildActivityMembers()
    if memberGuild == Guild() then return memberStats end
end

local function UpdateMember(guild, sender, points, count)
    points, count = tonumber(points), tonumber(count)
    if not (points and count and points >= 0 and points <= 10000000 and count >= 0 and count <= 100000) then return end
    if memberGuild ~= guild then memberGuild, memberStats = guild, {} end
    memberStats[sender] = { pts = math.floor(points), count = math.floor(count), time = time() }
    return true
end

function ns.RequestGuildActivity(automatic)
    local guild = Guild()
    if not guild or FA.Settings().share == false then return end
    local now = GetTime()
    if requestedGuild == guild and (now - requestAt < RESPONSE_WINDOW
        or (automatic and now - requestAt < REFRESH_INTERVAL)
        or (not automatic and lastSentAt and now - lastSentAt < 30)) then return end
    local token = ("%d%06d"):format(math.floor(now) % 100000, math.random(0, 999999))
    WatchRequest(guild, token, now)
    lastSentAt = now
    ns.SendGuildActivity("GFEED_REQ\t" .. token)
end

function ns.ReceiveGuildActivity(kind, sender, key, payload, points, count)
    local guild = Guild()
    if not guild then return end
    local now = GetTime()
    if kind == "EARN" then
        if not FA.BY_KEY[key or ""] then return end
        local changed = Add(Feed(guild).rows, sender, key, time(), false, MAX_ROWS)
        local updated = UpdateMember(guild, sender, points, count)
        if (changed or updated) and FA.OnPeers then FA.OnPeers() end
    elseif kind == "GFEED_REQ" then
        local token = key
        if not (type(token) == "string" and #token <= 12 and token:match("^%d+$"))
            or FA.Settings().share == false then return end
        -- Guild replies are visible to everyone. Listen to a guildmate's check
        -- instead of sending our own request for the same information.
        if requestedGuild ~= guild or now - requestAt >= RESPONSE_WINDOW then WatchRequest(guild, token, now) end
        if requestedToken ~= token or (replyAt and now - replyAt < 15) then return end
        local rows = Feed(guild).own
        SortAndTrim(rows, time(), REPLY_LIMIT)
        replyAt = now
        C_Timer.After(0.5 + math.random() * 4, function()
            if Guild() ~= guild or FA.Settings().share == false then return end
            local entries, size = {}, 0
            for _, row in ipairs(rows) do
                local entry = row.key .. ":" .. row.when
                if #entry + size + 1 > 200 then break end
                entries[#entries + 1] = entry
                size = size + #entry + 1
            end
            local pts, earned = FA.CharacterPoints()
            ns.SendGuildActivity(("GFEED_DATA\t%s\t%s\t%d\t%d"):format(token, table.concat(entries, ","), pts, earned))
        end)
    elseif kind == "GFEED_DATA" and FA.Settings().share ~= false
        and requestedGuild == guild and key == requestedToken and now - requestAt < RESPONSE_WINDOW then
        local rows, received = Feed(guild).rows, 0
        local changed = UpdateMember(guild, sender, points, count)
        for entry in (payload or ""):gmatch("[^,]+") do
            received = received + 1
            if received > REPLY_LIMIT then break end
            local achievement, stamp = entry:match("^([%w_]+):(%d+)$")
            if achievement and Add(rows, sender, achievement, tonumber(stamp), true, MAX_ROWS) then changed = true end
        end
        if changed and FA.OnPeers then FA.OnPeers() end
    end
end

local function CheckGuild()
    ns.RequestGuildActivity(true)
    local guild = Guild()
    local delay = REFRESH_INTERVAL
    if guild and guild == requestedGuild then
        delay = math.max(1, REFRESH_INTERVAL - (GetTime() - requestAt))
    end
    C_Timer.After(delay + math.random(0, 30), CheckGuild)
end

function ns.StartGuildActivityChecks()
    -- Spread initial login requests across a short window.
    C_Timer.After(math.random(15, 45), CheckGuild)
end

table.insert(FA.EARN_HOOKS, function(a)
    local guild = Guild()
    local name = FA.FullName("player") or UnitName("player")
    if not (guild and name and not FA.secret(name)) then return end
    local feed = Feed(guild)
    local when = FA.DB().done[a.key]
    Add(feed.rows, name, a.key, when, true, MAX_ROWS)
    if FA.Settings().share ~= false then Add(feed.own, name, a.key, when, true, REPLY_LIMIT) end
    if FA.OnPeers then FA.OnPeers() end
end)

function ns.DrawGuildActivity(child, width, y)
    local kit = FA.Kit
    local _, height = kit.W:SectionHeader(child, "RECENT GUILD ACHIEVEMENTS", y)
    y = y - height
    local guild = Guild()
    local rows = guild and Feed(guild).rows or {}
    SortAndTrim(rows, time(), MAX_ROWS)
    if #rows == 0 then
        local text = kit.MakeFont(child, 12, nil, 1, 1, 1, 0.6)
        text:SetPoint("TOPLEFT", 20, y - 2)
        text:SetWidth(width - 40)
        text:SetJustifyH("LEFT")
        text:SetWordWrap(true)
        text:SetText(guild and "No guild achievements recorded yet." or "Join a guild to see recent achievements here.")
        return y - text:GetStringHeight() - 14
    end
    local colors = kit.COLORS
    local r, g, b = kit.Accent()
    local shown = 0
    for _, row in ipairs(rows) do
        local a = FA.BY_KEY[row.key]
        if a then
            local card = CreateFrame("Button", nil, child)
            card:SetSize(width - 40, 36)
            card:SetPoint("TOPLEFT", 20, y)
            local bg = card:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints()
            bg:SetColorTexture(unpack(colors.card))
            local icon = ns.FramedIcon(card, 25, r, g, b, 0.8)
            icon:SetPoint("LEFT", 8, 0)
            icon.icon:SetTexture(a.icon or ns.ICONS[a.id] or 236376)
            local when = kit.MakeFont(card, 11, nil, unpack(colors.dim))
            when:SetPoint("RIGHT", -10, 0)
            when:SetText(date("%m-%d-%Y", row.when))
            local title = kit.MakeFont(card, 13, nil, r, g, b, 1)
            title:SetPoint("TOPLEFT", 42, -4)
            title:SetPoint("RIGHT", when, "LEFT", -10, 0)
            title:SetJustifyH("LEFT")
            title:SetWordWrap(false)
            title:SetText(a.name)
            local name = kit.MakeFont(card, 11, nil, unpack(colors.text))
            name:SetPoint("BOTTOMLEFT", 42, 4)
            name:SetPoint("RIGHT", when, "LEFT", -10, 0)
            name:SetJustifyH("LEFT")
            name:SetWordWrap(false)
            name:SetText((row.name:gsub("-", " ")))
            card:SetScript("OnClick", function() FA.OpenSearch(a.name) end)
            y = y - 40
            shown = shown + 1
            if shown == VISIBLE_ROWS then break end
        end
    end
    return y - 8
end
