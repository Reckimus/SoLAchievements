local _, ns = ...
local FAC = ns.Split_SoLAchievements
local STITCHES = 412
local ASSIST, SAVIOR = "stitchesAssist", "stitchesSavior"

local function NightwatchAchievement(key, name, desc, tracking)
    return {
        key = key, name = name, desc = desc, pts = 10, icon = 135432, kill = true, tracking = tracking,
        zone = "Duskwood",
        progress = function() return FAC.DB().flags[key] and 1 or 0, 1 end,
    }
end

table.insert(FAC.SECTIONS, { title = "DUSKWOOD", list = {
    NightwatchAchievement(ASSIST, "Assisting the Nightwatch!",
        "Damage Stitches in Duskwood and witness his death with another player's tag.",
        "Checks your damage against Stitches and a witnessed death with loot credit belonging to someone else."),
    NightwatchAchievement(SAVIOR, "Nightwatch Savior!",
        "Defeat Stitches in Duskwood with loot credit and open his loot.",
        "Uses the loot window's source to verify that you or your group had loot credit for Stitches."),
} })

local function Readable(value)
    return not FAC.secret(value) and (not canaccessvalue or canaccessvalue(value))
end

local function IsStitches(guid)
    return Readable(guid) and type(guid) == "string" and tonumber(guid:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")) == STITCHES
end

local function Award(key)
    local flags = FAC.DB().flags
    if flags[key] then return end
    flags[key] = true
    FAC.CheckAll(nil, true)
end

local function CheckLoot()
    if not (GetNumLootItems and GetLootSourceInfo) or FAC.DB().flags[SAVIOR] then return end
    local slots = GetNumLootItems()
    if not Readable(slots) or type(slots) ~= "number" then return end
    for slot = 1, slots do
        local sources = { GetLootSourceInfo(slot) }
        for i = 1, #sources, 2 do
            if IsStitches(sources[i]) then Award(SAVIOR); return end
        end
    end
end

local seen, candidate, queued
local function PlayerDamagedStitches(guid)
    local meter = C_DamageMeter
    local types = Enum and Enum.DamageMeterType
    local sessions = Enum and Enum.DamageMeterSessionType
    if not (meter and meter.GetCombatSessionFromType and meter.GetCombatSessionSourceFromType
        and types and types.EnemyDamageTaken and sessions and sessions.Current) then return end
    local me = UnitGUID("player")
    if not Readable(me) or type(me) ~= "string" then me = nil end
    local ok, data = pcall(meter.GetCombatSessionFromType, sessions.Current, types.EnemyDamageTaken)
    if not ok or not Readable(data) or type(data) ~= "table" then return end
    local enemies = data.combatSources
    if not Readable(enemies) or type(enemies) ~= "table" then return end
    for _, enemy in ipairs(enemies) do
        if Readable(enemy) and type(enemy) == "table" then
            local enemyGUID, id = enemy.sourceGUID, enemy.sourceCreatureID
            if (Readable(enemyGUID) and enemyGUID == guid)
                or (Readable(id) and id == STITCHES and (not Readable(enemyGUID) or enemyGUID == nil)) then
                local sourceGUID = Readable(enemyGUID) and enemyGUID or nil
                local creatureID = Readable(id) and id or nil
                local read, details = pcall(meter.GetCombatSessionSourceFromType, sessions.Current, types.EnemyDamageTaken, sourceGUID, creatureID)
                local attackers = read and Readable(details) and type(details) == "table" and details.combatSources
                if Readable(attackers) and type(attackers) == "table" then
                    for _, attacker in ipairs(attackers) do
                        if Readable(attacker) and type(attacker) == "table" then
                            local attackerGUID, amount = attacker.sourceGUID, attacker.totalAmount
                            local isLocal = attacker.isLocalPlayer
                            local ours = (Readable(isLocal) and isLocal == true)
                                or (me and Readable(attackerGUID) and attackerGUID == me)
                            if ours and Readable(amount)
                                and type(amount) == "number" and amount > 0 then return true end
                        end
                    end
                end
            end
        end
    end
end

local function CheckDamage(retry)
    if not candidate or GetTime() - candidate.when > 30 then candidate = nil; return end
    if InCombatLockdown and InCombatLockdown() then return end
    if PlayerDamagedStitches(candidate.guid) then
        candidate = nil
        Award(ASSIST)
    elseif retry then
        C_Timer.After(0.7, function() CheckDamage(false) end)
    end
end

local function QueueDamage()
    if queued then return end
    queued = true
    C_Timer.After(0.2, function()
        queued = nil
        CheckDamage(true)
    end)
end

local function Observe(unit)
    if not (UnitGUID and UnitIsDead and UnitIsTapDenied) then return end
    local guid = UnitGUID(unit)
    if not IsStitches(guid) or FAC.DB().flags[ASSIST] then return end
    local dead = UnitIsDead(unit)
    if not Readable(dead) then return end
    if dead == false then
        seen = guid
    elseif dead == true and seen == guid then
        local denied = UnitIsTapDenied(unit)
        if not Readable(denied) or denied == nil then return end
        seen = nil
        if denied == true then
            candidate = { guid = guid, when = GetTime() }
            QueueDamage()
        end
    end
end

local frame = CreateFrame("Frame")
for _, event in ipairs({ "LOOT_READY", "LOOT_OPENED", "PLAYER_TARGET_CHANGED", "PLAYER_FOCUS_CHANGED",
    "UPDATE_MOUSEOVER_UNIT", "PLAYER_REGEN_ENABLED", "PLAYER_ENTERING_WORLD" }) do
    pcall(frame.RegisterEvent, frame, event)
end
pcall(frame.RegisterUnitEvent, frame, "UNIT_HEALTH", "target", "focus")
pcall(frame.RegisterUnitEvent, frame, "UNIT_FLAGS", "target", "focus")
frame:SetScript("OnEvent", function(_, event, unit)
    if event == "LOOT_READY" or event == "LOOT_OPENED" then
        CheckLoot()
    elseif event == "PLAYER_ENTERING_WORLD" then
        seen, candidate = nil, nil
    elseif event == "PLAYER_REGEN_ENABLED" then
        Observe("target")
        Observe("focus")
        if candidate then QueueDamage() end
    elseif event == "PLAYER_TARGET_CHANGED" then
        Observe("target")
    elseif event == "PLAYER_FOCUS_CHANGED" then
        Observe("focus")
    elseif event == "UPDATE_MOUSEOVER_UNIT" then
        Observe("mouseover")
    elseif Readable(unit) and (unit == "target" or unit == "focus") then
        Observe(unit)
    end
end)
